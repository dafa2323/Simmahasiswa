<?php
/*
 * ===== EDIT BAGIAN INI SESUAI DATA DI PANEL INFINITYFREE =====
 * Client Area > MySQL Databases
 */
$DB_HOST = 'sql204.infinityfree.com';        // MySQL Host Name
$DB_NAME = 'if0_43025082_simdosen';          // nama database lengkap (dengan awalan)
$DB_USER = 'if0_43025082';                   // MySQL Username
$DB_PASS = 'Dafa12354'; // password akun hosting
/* ============================================================ */

// BASE_URL otomatis: '' jika di root htdocs, '/nama-folder' jika di subfolder
$_root = realpath($_SERVER['DOCUMENT_ROOT'] ?? '');
$_app  = realpath(__DIR__ . '/..');
$_base = ($_root && $_app && strpos($_app, $_root) === 0)
    ? str_replace('\\', '/', substr($_app, strlen($_root))) : '';
define('BASE_URL', rtrim($_base, '/'));

try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    die('Koneksi database gagal. Periksa config/koneksi.php (host, nama database, user, password).');
}
