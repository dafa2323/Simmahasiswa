<?php
declare(strict_types=1);

/*
 * Koneksi database.
 * Sesuaikan username/password MySQL dengan XAMPP/Laragon/server Anda.
 */
const DB_HOST = 'sql204.infinityfree.com';
const DB_USER = 'if0_43025082';
const DB_PASS = 'Dafa12354';
const DB_NAME = 'if0_43025082_universitas_semantik';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');
} catch (Throwable $e) {
    http_response_code(500);
    exit('Koneksi database gagal. Periksa konfigurasi db.php.');
}
