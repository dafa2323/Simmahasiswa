<?php
require_once __DIR__ . '/includes/auth.php';
$judul = 'Beranda';
$total = $pdo->query("SELECT COUNT(*) FROM dosen")->fetchColumn();
$aktif = $pdo->query("SELECT COUNT(*) FROM dosen d JOIN status_aktivitas s ON s.id=d.aktivitas_id WHERE s.nama='Aktif'")->fetchColumn();
$prodi = $pdo->query("SELECT COUNT(*) FROM prodi")->fetchColumn();
require __DIR__ . '/includes/header.php';
?>
<style> body{background:linear-gradient(rgba(0,0,0,.55),rgba(0,0,0,.55)),url('<?= BASE_URL ?>/assets/jadul.jpg') center/cover no-repeat fixed;min-height:100vh} .hero{background:transparent!important;box-shadow:none!important;color:#fff} .card:not(.hero){background:rgba(255,255,255,.93)} body > p{color:#eee!important} </style> <div class="card hero" style="text-align:center;padding:20px 20px 120px"><h1>Sistem Informasi Manajemen Dosen</h1> <p>Universitas Muhammadiyah Bengkulu</p> <p>Kelola data dosen, jabatan fungsional, kepangkatan, sertifikasi, dan laporan daftar dosen aktif dalam satu aplikasi.</p> <a class="btn" style="margin-top:120px" href="<?= BASE_URL ?>/<?= user() ? 'dashboard.php' : 'login.php' ?>"><?= user() ? 'Ke Dashboard' : 'Masuk ke Sistem' ?></a>
</div>
<div class="grid">
  <div class="card stat"><b><?= $total ?></b>Total Dosen</div>
  <div class="card stat"><b><?= $aktif ?></b>Dosen Aktif</div>
  <div class="card stat"><b><?= $prodi ?></b>Program Studi</div>
</div>
<div class="card"><b>Akses API:</b> tersedia Web Service REST (JSON) di folder <code>/api</code> untuk integrasi aplikasi lain. Uji cepat: <a href="<?= BASE_URL ?>/api-tester.html">api-tester.html</a></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
