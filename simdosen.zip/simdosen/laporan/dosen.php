<?php
require_once __DIR__ . '/../includes/auth.php';
wajib('laporan');
$prodi_id = (int)($_GET['prodi_id'] ?? 0);
$sql = sql_dosen() . " WHERE sa.nama='Aktif'";
$par = [];
if ($prodi_id) { $sql .= " AND d.prodi_id=?"; $par[] = $prodi_id; }
$s = $pdo->prepare($sql . " ORDER BY d.nama");
$s->execute($par);
$rows = $s->fetchAll();

$info = ['universitas' => 'Semua', 'fakultas' => 'Semua', 'prodi' => 'Semua'];
if ($prodi_id) {
    $q = $pdo->prepare("SELECT p.nama prodi, f.nama fakultas, u.nama universitas FROM prodi p JOIN fakultas f ON f.id=p.fakultas_id JOIN universitas u ON u.id=f.universitas_id WHERE p.id=?");
    $q->execute([$prodi_id]);
    if ($x = $q->fetch()) $info = $x;
} else {
    $u = $pdo->query("SELECT nama FROM universitas LIMIT 1")->fetchColumn();
    if ($u) $info['universitas'] = $u;
}

function tabel_laporan($rows, $info) { ?>
  <h3>Daftar Dosen Aktif Universitas</h3>
  <p>Universitas : <?= e($info['universitas']) ?><br>Fakultas : <?= e($info['fakultas']) ?><br>Program Studi : <?= e($info['prodi']) ?></p>
  <table border="1" cellpadding="4" cellspacing="0">
    <tr><th>No</th><th>Nomor Registrasi</th><th>NUPTK</th><th>Nama</th><th>NIP</th><th>Jabatan Fungsional</th><th>Kepangkatan</th>
    <th>Pendidikan Terakhir</th><th>Rumpun Ilmu</th><th>Status Serdos</th><th>Status Pegawai</th><th>Ikatan Kerja</th><th>Status Aktivitas</th><th>Penempatan</th></tr>
    <?php foreach ($rows as $i => $r): ?>
    <tr><td><?= $i + 1 ?></td><td><?= e($r['nomor_registrasi']) ?></td><td><?= e($r['nuptk']) ?></td><td><?= e($r['nama']) ?></td>
    <td><?= e($r['nip']) ?></td><td><?= e($r['jabatan_fungsional']) ?></td><td><?= e($r['kepangkatan']) ?></td>
    <td><?= e($r['pendidikan']) ?></td><td><?= e($r['rumpun_ilmu']) ?></td><td><?= e($r['status_serdos']) ?></td>
    <td><?= e($r['status_pegawai']) ?></td><td><?= e($r['ikatan_kerja']) ?></td><td><?= e($r['status_aktivitas']) ?></td><td><?= e($r['penempatan']) ?></td></tr>
    <?php endforeach; if (!$rows): ?><tr><td colspan="14">Tidak ada data.</td></tr><?php endif; ?>
  </table>
<?php }

if (isset($_GET['excel'])) {
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename=daftar_dosen_aktif.xls');
    echo '<meta charset="utf-8">';
    tabel_laporan($rows, $info);
    exit;
}
$prodiList = $pdo->query("SELECT p.id, CONCAT(f.nama,' - ',p.nama) nama FROM prodi p JOIN fakultas f ON f.id=p.fakultas_id ORDER BY f.nama,p.nama")->fetchAll();
$judul = 'Laporan Dosen';
require __DIR__ . '/../includes/header.php';
?>
<div class="card noprint">
  <h2>Laporan Daftar Dosen Aktif</h2>
  <form method="get" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
    <select name="prodi_id" style="margin:0"><option value="0">Semua Program Studi</option>
      <?php foreach ($prodiList as $p): ?><option value="<?= $p['id'] ?>" <?= $p['id'] == $prodi_id ? 'selected' : '' ?>><?= e($p['nama']) ?></option><?php endforeach; ?>
    </select>
    <button class="btn">Tampilkan</button>
    <button type="button" class="btn abu" onclick="window.print()">Cetak</button>
    <a class="btn abu" href="?prodi_id=<?= $prodi_id ?>&excel=1">Unduh Excel</a>
  </form>
</div>
<div class="card wrap"><?php tabel_laporan($rows, $info); ?></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
