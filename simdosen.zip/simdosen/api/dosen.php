<?php
require_once __DIR__ . '/helper.php';
$u = api_user($pdo);
$m = metode();
$id = (int)($_GET['id'] ?? 0);
$izin = ['GET' => 'dosen.r', 'POST' => 'dosen.c', 'PUT' => 'dosen.u', 'DELETE' => 'dosen.d'];
if (!isset($izin[$m])) out(['status' => 'error', 'pesan' => 'Metode tidak didukung'], 405);
if (!can($izin[$m], $u)) out(['status' => 'error', 'pesan' => 'Role Anda tidak punya izin'], 403);

try {
    if ($m === 'GET') {
        if ($id) {
            $s = $pdo->prepare(sql_dosen() . " WHERE d.id=?");
            $s->execute([$id]);
            $r = $s->fetch();
            if (!$r) out(['status' => 'error', 'pesan' => 'Data tidak ditemukan'], 404);
            out(['status' => 'ok', 'data' => $r]);
        }
        $q = trim($_GET['q'] ?? '');
        $sql = sql_dosen(); $par = [];
        if ($q !== '') {
            $sql .= " WHERE d.nama LIKE ? OR d.nip LIKE ? OR d.nuptk LIKE ? OR d.nomor_registrasi LIKE ?";
            $par = array_fill(0, 4, "%$q%");
        }
        $s = $pdo->prepare($sql . " ORDER BY d.nama");
        $s->execute($par);
        $data = $s->fetchAll();
        out(['status' => 'ok', 'jumlah' => count($data), 'data' => $data]);
    }
    if ($m === 'POST') {
        $b = body();
        if ($err = validasi_dosen($b)) out(['status' => 'error', 'pesan' => $err], 422);
        $newId = simpan_dosen($pdo, $b);
        out(['status' => 'ok', 'pesan' => 'Data dibuat', 'id' => (int)$newId], 201);
    }
    if ($m === 'PUT') {
        if (!$id) out(['status' => 'error', 'pesan' => 'Parameter id wajib'], 400);
        $s = $pdo->prepare("SELECT * FROM dosen WHERE id=?");
        $s->execute([$id]);
        $lama = $s->fetch();
        if (!$lama) out(['status' => 'error', 'pesan' => 'Data tidak ditemukan'], 404);
        $b = array_merge($lama, body());
        if ($err = validasi_dosen($b)) out(['status' => 'error', 'pesan' => $err], 422);
        simpan_dosen($pdo, $b, $id);
        out(['status' => 'ok', 'pesan' => 'Data diperbarui']);
    }
    if ($m === 'DELETE') {
        if (!$id) out(['status' => 'error', 'pesan' => 'Parameter id wajib'], 400);
        $s = $pdo->prepare("DELETE FROM dosen WHERE id=?");
        $s->execute([$id]);
        if (!$s->rowCount()) out(['status' => 'error', 'pesan' => 'Data tidak ditemukan'], 404);
        out(['status' => 'ok', 'pesan' => 'Data dihapus']);
    }
} catch (PDOException $e) {
    out(['status' => 'error', 'pesan' => $e->getCode() == '23000' ? 'Data duplikat atau relasi tidak valid' : 'Kesalahan database'], 409);
}
