<?php
require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json; charset=utf-8');

function out($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function body() {
    $j = json_decode(file_get_contents('php://input'), true);
    return is_array($j) ? $j : $_POST;
}
// Metode HTTP efektif (mendukung override untuk hosting yang memblokir PUT/DELETE)
function metode() {
    $m = $_SERVER['REQUEST_METHOD'];
    if ($m === 'POST' && !empty($_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'])) {
        $o = strtoupper($_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE']);
        if (in_array($o, ['PUT', 'DELETE'], true)) return $o;
    }
    return $m;
}
function api_user($pdo) {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if (!$h && function_exists('getallheaders')) {
        foreach (getallheaders() as $k => $v) if (strtolower($k) === 'authorization') $h = $v;
    }
    if (!preg_match('/Bearer\s+(\S+)/i', $h, $m)) out(['status' => 'error', 'pesan' => 'Token tidak ditemukan'], 401);
    $s = $pdo->prepare("SELECT u.id, u.username, r.nama role FROM users u JOIN roles r ON r.id=u.role_id
                        WHERE u.api_token=? AND u.token_exp > NOW() AND u.aktif=1");
    $s->execute([$m[1]]);
    $u = $s->fetch();
    if (!$u) out(['status' => 'error', 'pesan' => 'Token tidak valid atau kedaluwarsa'], 401);
    return $u;
}
