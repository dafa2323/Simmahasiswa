<?php
require_once __DIR__ . '/helper.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['status' => 'error', 'pesan' => 'Gunakan metode POST'], 405);
$b = body();
$u = cek_login($pdo, trim($b['username'] ?? ''), $b['password'] ?? '');
if (!$u) out(['status' => 'error', 'pesan' => 'Username atau password salah'], 401);
$token = bin2hex(random_bytes(32));
$pdo->prepare("UPDATE users SET api_token=?, token_exp=DATE_ADD(NOW(), INTERVAL 1 DAY) WHERE id=?")->execute([$token, $u['id']]);
out(['status' => 'ok', 'token' => $token, 'berlaku' => '24 jam', 'role' => $u['role']]);
