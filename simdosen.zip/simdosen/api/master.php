<?php
require_once __DIR__ . '/helper.php';
$u = api_user($pdo);
if (!can('master.r', $u)) out(['status' => 'error', 'pesan' => 'Role Anda tidak punya izin'], 403);
if ($_SERVER['REQUEST_METHOD'] !== 'GET') out(['status' => 'error', 'pesan' => 'Hanya metode GET'], 405);
$t = $_GET['t'] ?? '';
if (!isset($MASTER[$t])) out(['status' => 'error', 'pesan' => 'Tabel tidak valid', 'tabel_tersedia' => array_keys($MASTER)], 400);
out(['status' => 'ok', 'data' => $pdo->query("SELECT * FROM `$t` ORDER BY id")->fetchAll()]);
