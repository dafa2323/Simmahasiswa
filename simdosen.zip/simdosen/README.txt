SIMDOSEN - Sistem Informasi Manajemen Dosen UM Bengkulu (PHP native + MySQL + REST API)

PEMASANGAN DI INFINITYFREE
1. Client Area > MySQL Databases > buat database "simdosen" (nama jadi if0_XXXXXXXX_simdosen).
2. Buka phpMyAdmin database tersebut > tab Import > pilih simdosen_v2.sql > Go.
3. Edit config/koneksi.php: isi host, nama database, user, password (4 baris di bagian atas).
4. Unggah SEMUA isi folder ini (termasuk .htaccess) ke folder htdocs lewat File Manager/FTP.
   BASE_URL terdeteksi otomatis (root htdocs atau subfolder).
5. Buka domain Anda, login: admin / password (lalu ganti di menu Pengguna).

AKUN AWAL (password: password)
admin    = akses penuh
operator = tambah/ubah dosen, lihat master, laporan
pimpinan = hanya lihat data dan laporan

API
POST api/login.php        {"username":"admin","password":"password"} -> token
GET/POST/PUT/DELETE api/dosen.php[?id=]    header: Authorization: Bearer TOKEN
GET api/master.php?t=prodi
Jika PUT/DELETE diblokir hosting: kirim POST + header X-HTTP-Method-Override: PUT/DELETE
Uji dari browser: buka api-tester.html
