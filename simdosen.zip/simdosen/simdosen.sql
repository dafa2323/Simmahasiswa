-- SIMDOSEN VERSI 2 (tanpa foreign key) - tempel di tab SQL phpMyAdmin
-- (tidak ada CREATE DATABASE / USE karena database dibuat lewat panel hosting)

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS dosen;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS roles;
DROP TABLE IF EXISTS prodi;
DROP TABLE IF EXISTS fakultas;
DROP TABLE IF EXISTS universitas;
DROP TABLE IF EXISTS jabatan_fungsional;
DROP TABLE IF EXISTS kepangkatan;
DROP TABLE IF EXISTS pendidikan;
DROP TABLE IF EXISTS rumpun_ilmu;
DROP TABLE IF EXISTS status_serdos;
DROP TABLE IF EXISTS status_pegawai;
DROP TABLE IF EXISTS ikatan_kerja;
DROP TABLE IF EXISTS status_aktivitas;
DROP TABLE IF EXISTS penempatan;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE roles (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(30) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL,
  password VARCHAR(255) NOT NULL,
  role_id INT NOT NULL,
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  api_token VARCHAR(64) NULL,
  token_exp DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE universitas (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(150) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE fakultas (
  id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(150) NOT NULL, universitas_id INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE prodi (
  id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(150) NOT NULL, fakultas_id INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE jabatan_fungsional (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE kepangkatan        (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE pendidikan         (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE rumpun_ilmu        (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE status_serdos      (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE status_pegawai     (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE ikatan_kerja       (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE status_aktivitas   (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE penempatan         (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(150) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE dosen (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nomor_registrasi VARCHAR(30) NOT NULL UNIQUE,
  nuptk VARCHAR(30) NULL,
  nama VARCHAR(150) NOT NULL,
  nip VARCHAR(30) NULL,
  prodi_id INT NOT NULL,
  jabatan_id INT NULL,
  pangkat_id INT NULL,
  pendidikan_id INT NULL,
  rumpun_id INT NULL,
  serdos_id INT NULL,
  pegawai_id INT NULL,
  ikatan_id INT NULL,
  aktivitas_id INT NULL,
  penempatan_id INT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO roles (nama) VALUES ('admin'),('operator'),('pimpinan');
-- password semua akun awal = "password" (segera ganti lewat menu Pengguna)
INSERT INTO users (username,nama,password,role_id) VALUES
('admin','Administrator','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',1),
('operator','Operator Kepegawaian','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',2),
('pimpinan','Pimpinan Fakultas','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',3);

INSERT INTO universitas (nama) VALUES ('Universitas Muhammadiyah Bengkulu');
INSERT INTO fakultas (nama,universitas_id) VALUES ('Teknik',1),('Hukum',1);
INSERT INTO prodi (nama,fakultas_id) VALUES ('Teknik Informatika',1),('Teknik Sipil',1),('Ilmu Hukum',2);

INSERT INTO jabatan_fungsional (nama) VALUES ('Tenaga Pengajar'),('Asisten Ahli'),('Lektor'),('Lektor Kepala'),('Guru Besar');
INSERT INTO kepangkatan (nama) VALUES ('III/a - Penata Muda'),('III/b - Penata Muda Tk. I'),('III/c - Penata'),('III/d - Penata Tk. I'),('IV/a - Pembina');
INSERT INTO pendidikan (nama) VALUES ('S1'),('S2'),('S3');
INSERT INTO rumpun_ilmu (nama) VALUES ('Ilmu Komputer'),('Teknik'),('Hukum'),('Ekonomi');
INSERT INTO status_serdos (nama) VALUES ('Sudah Sertifikasi'),('Belum Sertifikasi');
INSERT INTO status_pegawai (nama) VALUES ('Dosen Tetap Yayasan'),('Dosen PNS DPK'),('Dosen Tidak Tetap');
INSERT INTO ikatan_kerja (nama) VALUES ('Dosen Tetap'),('Dosen Tidak Tetap'),('Dosen LB');
INSERT INTO status_aktivitas (nama) VALUES ('Aktif'),('Cuti'),('Tugas Belajar'),('Pensiun'),('Non-Aktif');
INSERT INTO penempatan (nama) VALUES ('Program Studi Teknik Informatika'),('Program Studi Teknik Sipil'),('Program Studi Ilmu Hukum');

-- data contoh (fiktif)
INSERT INTO dosen (nomor_registrasi,nuptk,nama,nip,prodi_id,jabatan_id,pangkat_id,pendidikan_id,rumpun_id,serdos_id,pegawai_id,ikatan_id,aktivitas_id,penempatan_id) VALUES
('REG-001','1111222233334444','Dosen Contoh Satu, M.Kom','198001012005011001',1,3,3,2,1,1,2,1,1,1),
('REG-002','2222333344445555','Dosen Contoh Dua, M.T','198505052010012002',1,2,2,2,1,2,1,1,1,1),
('REG-003','3333444455556666','Dosen Contoh Tiga, M.Kom','',1,1,1,2,1,2,3,2,2,1);
