</main>
<p style="text-align:center;color:#777;font-size:12px">&copy; <?= date('Y') ?> SIMDOSEN - Universitas Muhammadiyah Bengkulu</p>
</body></html>
