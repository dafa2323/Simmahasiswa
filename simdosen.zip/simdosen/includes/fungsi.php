<?php
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function csrf() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function csrf_field() { return '<input type="hidden" name="csrf" value="' . csrf() . '">'; }
function csrf_cek() {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419);
        die('Token CSRF tidak valid.');
    }
}

// Matriks RBAC: role => daftar izin
$IZIN = [
    'admin'    => ['dosen.r','dosen.c','dosen.u','dosen.d','master.r','master.w','laporan','user.m'],
    'operator' => ['dosen.r','dosen.c','dosen.u','master.r','laporan'],
    'pimpinan' => ['dosen.r','master.r','laporan'],
];

// Konfigurasi tabel master (fk = kolom di tabel dosen, parent = relasi induk)
$MASTER = [
    'universitas'        => ['label' => 'Universitas'],
    'fakultas'           => ['label' => 'Fakultas', 'parent' => ['universitas_id', 'universitas']],
    'prodi'              => ['label' => 'Program Studi', 'parent' => ['fakultas_id', 'fakultas']],
    'jabatan_fungsional' => ['label' => 'Jabatan Fungsional', 'fk' => 'jabatan_id'],
    'kepangkatan'        => ['label' => 'Kepangkatan', 'fk' => 'pangkat_id'],
    'pendidikan'         => ['label' => 'Pendidikan Terakhir', 'fk' => 'pendidikan_id'],
    'rumpun_ilmu'        => ['label' => 'Rumpun Ilmu', 'fk' => 'rumpun_id'],
    'status_serdos'      => ['label' => 'Status Serdos', 'fk' => 'serdos_id'],
    'status_pegawai'     => ['label' => 'Status Pegawai', 'fk' => 'pegawai_id'],
    'ikatan_kerja'       => ['label' => 'Ikatan Kerja', 'fk' => 'ikatan_id'],
    'status_aktivitas'   => ['label' => 'Status Aktivitas', 'fk' => 'aktivitas_id'],
    'penempatan'         => ['label' => 'Penempatan', 'fk' => 'penempatan_id'],
];

function dosen_fields() {
    global $MASTER;
    $f = ['nomor_registrasi', 'nuptk', 'nama', 'nip', 'prodi_id'];
    foreach ($MASTER as $m) if (isset($m['fk'])) $f[] = $m['fk'];
    return $f;
}

function sql_dosen() {
    return "SELECT d.*, jf.nama jabatan_fungsional, kp.nama kepangkatan, pd.nama pendidikan,
      ri.nama rumpun_ilmu, ss.nama status_serdos, sp.nama status_pegawai, ik.nama ikatan_kerja,
      sa.nama status_aktivitas, pn.nama penempatan, pr.nama prodi, fk.nama fakultas, un.nama universitas
      FROM dosen d
      JOIN prodi pr ON pr.id=d.prodi_id
      JOIN fakultas fk ON fk.id=pr.fakultas_id
      JOIN universitas un ON un.id=fk.universitas_id
      LEFT JOIN jabatan_fungsional jf ON jf.id=d.jabatan_id
      LEFT JOIN kepangkatan kp ON kp.id=d.pangkat_id
      LEFT JOIN pendidikan pd ON pd.id=d.pendidikan_id
      LEFT JOIN rumpun_ilmu ri ON ri.id=d.rumpun_id
      LEFT JOIN status_serdos ss ON ss.id=d.serdos_id
      LEFT JOIN status_pegawai sp ON sp.id=d.pegawai_id
      LEFT JOIN ikatan_kerja ik ON ik.id=d.ikatan_id
      LEFT JOIN status_aktivitas sa ON sa.id=d.aktivitas_id
      LEFT JOIN penempatan pn ON pn.id=d.penempatan_id";
}

function simpan_dosen($pdo, $data, $id = 0) {
    $f = dosen_fields();
    $v = [];
    foreach ($f as $k) $v[$k] = trim((string)($data[$k] ?? '')) === '' ? null : trim($data[$k]);
    if ($id) {
        $set = implode(',', array_map(fn($k) => "$k=:$k", $f));
        $v['id'] = $id;
        $pdo->prepare("UPDATE dosen SET $set WHERE id=:id")->execute($v);
        return $id;
    }
    $pdo->prepare("INSERT INTO dosen (" . implode(',', $f) . ") VALUES (:" . implode(',:', $f) . ")")->execute($v);
    return $pdo->lastInsertId();
}

function validasi_dosen($d) {
    if (trim($d['nomor_registrasi'] ?? '') === '') return 'Nomor registrasi wajib diisi';
    if (trim($d['nama'] ?? '') === '') return 'Nama wajib diisi';
    if (empty($d['prodi_id'])) return 'Program studi wajib dipilih';
    return '';
}

function opsi($rows, $sel = null) {
    $h = '<option value="">- pilih -</option>';
    foreach ($rows as $r) {
        $h .= '<option value="' . e($r['id']) . '"' . ((string)$r['id'] === (string)$sel ? ' selected' : '') . '>' . e($r['nama']) . '</option>';
    }
    return $h;
}
