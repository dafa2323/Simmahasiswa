<?php
require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/fungsi.php';
if (session_status() === PHP_SESSION_NONE) session_start();

function cek_login($pdo, $username, $password) {
    $s = $pdo->prepare("SELECT u.*, r.nama role FROM users u JOIN roles r ON r.id=u.role_id WHERE u.username=? AND u.aktif=1");
    $s->execute([$username]);
    $u = $s->fetch();
    return ($u && password_verify($password, $u['password'])) ? $u : false;
}
function user() { return $_SESSION['user'] ?? null; }
function can($izin, $u = null) {
    global $IZIN;
    $u = $u ?? user();
    return $u && in_array($izin, $IZIN[$u['role']] ?? [], true);
}
function wajib($izin = null) {
    if (!user()) { header('Location: ' . BASE_URL . '/login.php'); exit; }
    if ($izin && !can($izin)) {
        http_response_code(403);
        die('Akses ditolak (403): role Anda tidak memiliki izin untuk halaman ini.');
    }
}
