<?php require_once __DIR__ . '/auth.php'; ?>
<!DOCTYPE html>
<html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($judul ?? 'SIMDOSEN') ?> - SIMDOSEN UM Bengkulu</title>
<style>
*{box-sizing:border-box}body{font-family:Arial,sans-serif;margin:0;background:#f4f6f8;color:#222}
nav{background:#0b5d3b;color:#fff;padding:10px 20px;display:flex;flex-wrap:wrap;gap:14px;align-items:center}
nav a{color:#fff;text-decoration:none}nav a:hover{text-decoration:underline}nav .kanan{margin-left:auto}
main{max-width:1200px;margin:20px auto;padding:0 16px}
.card{background:#fff;border-radius:8px;padding:16px;margin-bottom:16px;box-shadow:0 1px 3px #0002}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px}
.stat b{font-size:30px;display:block;color:#0b5d3b}
table{border-collapse:collapse;width:100%;background:#fff;font-size:13px}
th,td{border:1px solid #ccc;padding:6px 8px;text-align:left}th{background:#e8f1ec}
.wrap{overflow-x:auto}
input,select{padding:7px;margin:3px 0 10px;width:100%;max-width:420px}
.btn{background:#0b5d3b;color:#fff;border:0;padding:7px 14px;border-radius:5px;cursor:pointer;text-decoration:none;display:inline-block;font-size:13px;width:auto}
.btn.merah{background:#b3261e}.btn.abu{background:#666}
.err{background:#fde7e7;color:#b3261e;padding:10px;border-radius:5px;margin-bottom:10px}
.formgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:0 20px}
@media print{nav,.noprint{display:none!important}body{background:#fff}.card{box-shadow:none}}
</style></head><body>
<nav>
  <b>SIMDOSEN UMB</b>
  <?php if (user()): ?>
    <a href="<?= BASE_URL ?>/dashboard.php">Dashboard</a>
    <?php if (can('dosen.r')): ?><a href="<?= BASE_URL ?>/dosen/index.php">Data Dosen</a><?php endif; ?>
    <?php if (can('master.r')): ?><a href="<?= BASE_URL ?>/master.php">Data Master</a><?php endif; ?>
    <?php if (can('laporan')): ?><a href="<?= BASE_URL ?>/laporan/dosen.php">Laporan</a><?php endif; ?>
    <?php if (can('user.m')): ?><a href="<?= BASE_URL ?>/users.php">Pengguna</a><?php endif; ?>
    <span class="kanan"><?= e(user()['nama']) ?> (<?= e(user()['role']) ?>) | <a href="<?= BASE_URL ?>/logout.php">Keluar</a></span>
  <?php else: ?>
    <a class="kanan" href="<?= BASE_URL ?>/login.php">Login</a>
  <?php endif; ?>
</nav>
<main>
