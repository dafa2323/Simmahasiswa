<?php
require_once __DIR__ . '/includes/auth.php';
wajib();
$judul = 'Dashboard';
$total = $pdo->query("SELECT COUNT(*) FROM dosen")->fetchColumn();
$aktif = $pdo->query("SELECT COUNT(*) FROM dosen d JOIN status_aktivitas s ON s.id=d.aktivitas_id WHERE s.nama='Aktif'")->fetchColumn();
$serdos = $pdo->query("SELECT COUNT(*) FROM dosen d JOIN status_serdos s ON s.id=d.serdos_id WHERE s.nama LIKE 'Sudah%'")->fetchColumn();
$s3 = $pdo->query("SELECT COUNT(*) FROM dosen d JOIN pendidikan p ON p.id=d.pendidikan_id WHERE p.nama='S3'")->fetchColumn();
$perprodi = $pdo->query("SELECT p.nama, COUNT(d.id) jml FROM prodi p LEFT JOIN dosen d ON d.prodi_id=p.id GROUP BY p.id, p.nama ORDER BY p.nama")->fetchAll();
$perjabatan = $pdo->query("SELECT j.nama, COUNT(d.id) jml FROM jabatan_fungsional j LEFT JOIN dosen d ON d.jabatan_id=j.id GROUP BY j.id, j.nama ORDER BY j.id")->fetchAll();
require __DIR__ . '/includes/header.php';
?>
<h2>Dashboard</h2>
<div class="grid">
  <div class="card stat"><b><?= $total ?></b>Total Dosen</div>
  <div class="card stat"><b><?= $aktif ?></b>Dosen Aktif</div>
  <div class="card stat"><b><?= $serdos ?></b>Sudah Sertifikasi</div>
  <div class="card stat"><b><?= $s3 ?></b>Berpendidikan S3</div>
</div>
<div class="grid">
  <div class="card"><h3>Dosen per Program Studi</h3>
    <table><tr><th>Program Studi</th><th>Jumlah</th></tr>
    <?php foreach ($perprodi as $r): ?><tr><td><?= e($r['nama']) ?></td><td><?= $r['jml'] ?></td></tr><?php endforeach; ?></table></div>
  <div class="card"><h3>Dosen per Jabatan Fungsional</h3>
    <table><tr><th>Jabatan</th><th>Jumlah</th></tr>
    <?php foreach ($perjabatan as $r): ?><tr><td><?= e($r['nama']) ?></td><td><?= $r['jml'] ?></td></tr><?php endforeach; ?></table></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
