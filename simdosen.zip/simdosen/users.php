<?php
require_once __DIR__ . '/includes/auth.php';
wajib('user.m');
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    try {
        if (($_POST['aksi'] ?? '') === 'hapus') {
            $hid = (int)$_POST['id'];
            if ($hid === (int)user()['id']) throw new Exception('Tidak bisa menghapus akun sendiri.');
            $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$hid]);
        } else {
            $id = (int)($_POST['id'] ?? 0);
            $un = trim($_POST['username'] ?? ''); $nm = trim($_POST['nama'] ?? '');
            $rl = (int)($_POST['role_id'] ?? 0); $ak = isset($_POST['aktif']) ? 1 : 0;
            $pw = $_POST['password'] ?? '';
            if ($un === '' || $nm === '' || !$rl) throw new Exception('Username, nama, dan role wajib diisi.');
            if (!$id && strlen($pw) < 6) throw new Exception('Password minimal 6 karakter.');
            if ($id) {
                $pdo->prepare("UPDATE users SET username=?,nama=?,role_id=?,aktif=? WHERE id=?")->execute([$un, $nm, $rl, $ak, $id]);
                if ($pw !== '') $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([password_hash($pw, PASSWORD_DEFAULT), $id]);
            } else {
                $pdo->prepare("INSERT INTO users (username,nama,password,role_id,aktif) VALUES (?,?,?,?,?)")
                    ->execute([$un, $nm, password_hash($pw, PASSWORD_DEFAULT), $rl, $ak]);
            }
        }
        header('Location: users.php');
        exit;
    } catch (PDOException $e) {
        $err = $e->getCode() == '23000' ? 'Username sudah dipakai.' : 'Kesalahan database.';
    } catch (Exception $e) { $err = $e->getMessage(); }
}
$edit = ['id' => 0, 'username' => '', 'nama' => '', 'role_id' => '', 'aktif' => 1];
if (isset($_GET['edit'])) {
    $s = $pdo->prepare("SELECT * FROM users WHERE id=?");
    $s->execute([(int)$_GET['edit']]);
    if ($r = $s->fetch()) $edit = $r;
}
$roles = $pdo->query("SELECT id, nama FROM roles")->fetchAll();
$rows = $pdo->query("SELECT u.*, r.nama role FROM users u JOIN roles r ON r.id=u.role_id ORDER BY u.id")->fetchAll();
$judul = 'Pengguna';
require __DIR__ . '/includes/header.php';
?>
<div class="card">
  <h2>Manajemen Pengguna</h2>
  <?php if ($err): ?><div class="err"><?= e($err) ?></div><?php endif; ?>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $edit['id'] ?>">
    <div class="formgrid">
      <div>Username<input name="username" value="<?= e($edit['username']) ?>" required></div>
      <div>Nama<input name="nama" value="<?= e($edit['nama']) ?>" required></div>
      <div>Role<select name="role_id" required><?= opsi($roles, $edit['role_id']) ?></select></div>
      <div>Password <?= $edit['id'] ? '(kosongkan jika tidak diganti)' : '' ?><input type="password" name="password"></div>
    </div>
    <label><input type="checkbox" name="aktif" style="width:auto" <?= $edit['aktif'] ? 'checked' : '' ?>> Aktif</label><br><br>
    <button class="btn">Simpan</button> <?php if ($edit['id']): ?><a class="btn abu" href="users.php">Batal</a><?php endif; ?>
  </form>
</div>
<div class="wrap"><table>
  <tr><th>ID</th><th>Username</th><th>Nama</th><th>Role</th><th>Aktif</th><th>Aksi</th></tr>
  <?php foreach ($rows as $r): ?>
  <tr><td><?= $r['id'] ?></td><td><?= e($r['username']) ?></td><td><?= e($r['nama']) ?></td><td><?= e($r['role']) ?></td>
  <td><?= $r['aktif'] ? 'Ya' : 'Tidak' ?></td><td>
    <a class="btn" href="?edit=<?= $r['id'] ?>">Edit</a>
    <form method="post" style="display:inline" onsubmit="return confirm('Hapus pengguna ini?')">
      <?= csrf_field() ?><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?= $r['id'] ?>">
      <button class="btn merah">Hapus</button></form></td></tr>
  <?php endforeach; ?>
</table></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
