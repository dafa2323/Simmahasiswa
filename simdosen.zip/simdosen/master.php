<?php
require_once __DIR__ . '/includes/auth.php';
wajib('master.r');
$t = $_GET['t'] ?? 'jabatan_fungsional';
if (!isset($MASTER[$t])) die('Tabel tidak valid.');
$m = $MASTER[$t];
$parent = $m['parent'] ?? null;
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    wajib('master.w');
    csrf_cek();
    try {
        if (($_POST['aksi'] ?? '') === 'hapus') {
            $hid = (int)$_POST['id'];
            $pakai = ['universitas' => ['fakultas', 'universitas_id'], 'fakultas' => ['prodi', 'fakultas_id'], 'prodi' => ['dosen', 'prodi_id']];
            if (isset($m['fk'])) $pakai[$t] = ['dosen', $m['fk']];
            if (isset($pakai[$t])) {
                $c = $pdo->prepare("SELECT COUNT(*) FROM `{$pakai[$t][0]}` WHERE `{$pakai[$t][1]}`=?");
                $c->execute([$hid]);
                if ($c->fetchColumn() > 0) throw new Exception('Data tidak bisa dihapus karena masih dipakai data lain.');
            }
            $pdo->prepare("DELETE FROM `$t` WHERE id=?")->execute([$hid]);
        } else {
            $nama = trim($_POST['nama'] ?? '');
            if ($nama === '') throw new Exception('Nama wajib diisi.');
            $id = (int)($_POST['id'] ?? 0);
            if ($parent) {
                $pv = (int)($_POST['parent'] ?? 0);
                if (!$pv) throw new Exception('Induk wajib dipilih.');
                if ($id) $pdo->prepare("UPDATE `$t` SET nama=?, `{$parent[0]}`=? WHERE id=?")->execute([$nama, $pv, $id]);
                else $pdo->prepare("INSERT INTO `$t` (nama, `{$parent[0]}`) VALUES (?,?)")->execute([$nama, $pv]);
            } else {
                if ($id) $pdo->prepare("UPDATE `$t` SET nama=? WHERE id=?")->execute([$nama, $id]);
                else $pdo->prepare("INSERT INTO `$t` (nama) VALUES (?)")->execute([$nama]);
            }
        }
        header('Location: master.php?t=' . $t);
        exit;
    } catch (PDOException $e) {
        $err = $e->getCode() == '23000' ? 'Gagal: data duplikat atau masih dipakai data lain.' : 'Kesalahan database.';
    } catch (Exception $e) {
        $err = $e->getMessage();
    }
}

$edit = ['id' => 0, 'nama' => '', 'parent' => ''];
if (isset($_GET['edit']) && can('master.w')) {
    $s = $pdo->prepare("SELECT * FROM `$t` WHERE id=?");
    $s->execute([(int)$_GET['edit']]);
    if ($r = $s->fetch()) $edit = ['id' => $r['id'], 'nama' => $r['nama'], 'parent' => $parent ? $r[$parent[0]] : ''];
}
if ($parent) {
    $rows = $pdo->query("SELECT x.*, p.nama parent_nama FROM `$t` x JOIN `{$parent[1]}` p ON p.id=x.`{$parent[0]}` ORDER BY x.id")->fetchAll();
    $popt = $pdo->query("SELECT id, nama FROM `{$parent[1]}` ORDER BY nama")->fetchAll();
} else {
    $rows = $pdo->query("SELECT * FROM `$t` ORDER BY id")->fetchAll();
}
$judul = 'Data Master';
require __DIR__ . '/includes/header.php';
?>
<div class="card">
  <h2>Data Master</h2>
  <?php foreach ($MASTER as $k => $mm): ?>
    <a class="btn <?= $k === $t ? '' : 'abu' ?>" style="margin:2px" href="?t=<?= $k ?>"><?= e($mm['label']) ?></a>
  <?php endforeach; ?>
</div>
<?php if (can('master.w')): ?>
<div class="card">
  <h3><?= $edit['id'] ? 'Edit' : 'Tambah' ?> <?= e($m['label']) ?></h3>
  <?php if ($err): ?><div class="err"><?= e($err) ?></div><?php endif; ?>
  <form method="post"><?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= $edit['id'] ?>">
    <?php if ($parent): ?>Induk (<?= e($parent[1]) ?>)<select name="parent" required><?= opsi($popt, $edit['parent']) ?></select><?php endif; ?>
    Nama<input name="nama" value="<?= e($edit['nama']) ?>" required>
    <button class="btn">Simpan</button>
    <?php if ($edit['id']): ?><a class="btn abu" href="?t=<?= $t ?>">Batal</a><?php endif; ?>
  </form>
</div>
<?php elseif ($err): ?><div class="err"><?= e($err) ?></div><?php endif; ?>
<div class="wrap"><table>
  <tr><th>ID</th><?php if ($parent): ?><th><?= e($parent[1]) ?></th><?php endif; ?><th>Nama</th><?php if (can('master.w')): ?><th>Aksi</th><?php endif; ?></tr>
  <?php foreach ($rows as $r): ?>
  <tr><td><?= $r['id'] ?></td><?php if ($parent): ?><td><?= e($r['parent_nama']) ?></td><?php endif; ?><td><?= e($r['nama']) ?></td>
  <?php if (can('master.w')): ?><td>
    <a class="btn" href="?t=<?= $t ?>&edit=<?= $r['id'] ?>">Edit</a>
    <form method="post" style="display:inline" onsubmit="return confirm('Hapus data ini?')">
      <?= csrf_field() ?><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?= $r['id'] ?>">
      <button class="btn merah">Hapus</button></form></td><?php endif; ?></tr>
  <?php endforeach; ?>
</table></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
