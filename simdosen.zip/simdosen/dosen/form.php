<?php
require_once __DIR__ . '/../includes/auth.php';
$id = (int)($_GET['id'] ?? 0);
wajib($id ? 'dosen.u' : 'dosen.c');
$err = '';
$d = array_fill_keys(dosen_fields(), '');
if ($id) {
    $s = $pdo->prepare("SELECT * FROM dosen WHERE id=?");
    $s->execute([$id]);
    $d = $s->fetch();
    if (!$d) die('Data tidak ditemukan.');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    $d = array_merge($d, $_POST);
    $err = validasi_dosen($d);
    if (!$err) {
        try {
            simpan_dosen($pdo, $d, $id);
            header('Location: index.php');
            exit;
        } catch (PDOException $e) {
            $err = $e->getCode() == '23000' ? 'Nomor registrasi sudah terdaftar.' : 'Gagal menyimpan data.';
        }
    }
}
$prodi = $pdo->query("SELECT p.id, CONCAT(f.nama,' - ',p.nama) nama FROM prodi p JOIN fakultas f ON f.id=p.fakultas_id ORDER BY f.nama,p.nama")->fetchAll();
$judul = $id ? 'Edit Dosen' : 'Tambah Dosen';
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2><?= e($judul) ?></h2>
  <?php if ($err): ?><div class="err"><?= e($err) ?></div><?php endif; ?>
  <form method="post"><?= csrf_field() ?>
  <div class="formgrid">
    <div>Nomor Registrasi *<input name="nomor_registrasi" value="<?= e($d['nomor_registrasi']) ?>" required></div>
    <div>NUPTK<input name="nuptk" value="<?= e($d['nuptk']) ?>"></div>
    <div>Nama *<input name="nama" value="<?= e($d['nama']) ?>" required></div>
    <div>NIP<input name="nip" value="<?= e($d['nip']) ?>"></div>
    <div>Program Studi *<select name="prodi_id" required><?= opsi($prodi, $d['prodi_id']) ?></select></div>
    <?php foreach ($MASTER as $tbl => $m): if (!isset($m['fk'])) continue;
        $opt = $pdo->query("SELECT id, nama FROM `$tbl` ORDER BY nama")->fetchAll(); ?>
      <div><?= e($m['label']) ?><select name="<?= $m['fk'] ?>"><?= opsi($opt, $d[$m['fk']]) ?></select></div>
    <?php endforeach; ?>
  </div>
  <button class="btn">Simpan</button> <a class="btn abu" href="index.php">Batal</a>
  </form>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
