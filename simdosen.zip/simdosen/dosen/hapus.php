<?php
require_once __DIR__ . '/../includes/auth.php';
wajib('dosen.d');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    $pdo->prepare("DELETE FROM dosen WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
}
header('Location: index.php');
