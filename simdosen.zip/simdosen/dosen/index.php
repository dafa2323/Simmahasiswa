<?php
require_once __DIR__ . '/../includes/auth.php';
wajib('dosen.r');
$judul = 'Data Dosen';
$q = trim($_GET['q'] ?? '');
$sql = sql_dosen();
$par = [];
if ($q !== '') {
    $sql .= " WHERE d.nama LIKE ? OR d.nip LIKE ? OR d.nuptk LIKE ? OR d.nomor_registrasi LIKE ?";
    $par = array_fill(0, 4, "%$q%");
}
$s = $pdo->prepare($sql . " ORDER BY d.nama");
$s->execute($par);
$rows = $s->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<div class="card">
  <h2>Data Dosen</h2>
  <form method="get" style="display:flex;gap:8px;flex-wrap:wrap">
    <input name="q" placeholder="Cari nama / NIP / NUPTK / no. registrasi" value="<?= e($q) ?>" style="margin:0">
    <button class="btn">Cari</button>
    <?php if (can('dosen.c')): ?><a class="btn" href="form.php">+ Tambah Dosen</a><?php endif; ?>
  </form>
</div>
<div class="wrap"><table>
<tr><th>No</th><th>No. Registrasi</th><th>NUPTK</th><th>Nama</th><th>NIP</th><th>Jabatan Fungsional</th><th>Kepangkatan</th>
<th>Pendidikan</th><th>Rumpun Ilmu</th><th>Serdos</th><th>Status Pegawai</th><th>Ikatan Kerja</th><th>Aktivitas</th><th>Penempatan</th><th>Aksi</th></tr>
<?php foreach ($rows as $i => $r): ?>
<tr><td><?= $i + 1 ?></td><td><?= e($r['nomor_registrasi']) ?></td><td><?= e($r['nuptk']) ?></td><td><?= e($r['nama']) ?></td>
<td><?= e($r['nip']) ?></td><td><?= e($r['jabatan_fungsional']) ?></td><td><?= e($r['kepangkatan']) ?></td>
<td><?= e($r['pendidikan']) ?></td><td><?= e($r['rumpun_ilmu']) ?></td><td><?= e($r['status_serdos']) ?></td>
<td><?= e($r['status_pegawai']) ?></td><td><?= e($r['ikatan_kerja']) ?></td><td><?= e($r['status_aktivitas']) ?></td>
<td><?= e($r['penempatan']) ?></td>
<td style="white-space:nowrap">
  <?php if (can('dosen.u')): ?><a class="btn" href="form.php?id=<?= $r['id'] ?>">Edit</a><?php endif; ?>
  <?php if (can('dosen.d')): ?>
  <form method="post" action="hapus.php" style="display:inline" onsubmit="return confirm('Hapus data dosen ini?')">
    <?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['id'] ?>">
    <button class="btn merah">Hapus</button></form>
  <?php endif; ?>
</td></tr>
<?php endforeach; if (!$rows): ?><tr><td colspan="15">Data tidak ditemukan.</td></tr><?php endif; ?>
</table></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
