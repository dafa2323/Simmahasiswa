<?php
require_once __DIR__ . '/includes/auth.php';
wajib();
$s = $pdo->prepare("SELECT * FROM bimbingan WHERE id=?");
$s->execute([(int)($_GET['id'] ?? 0)]);
$b = $s->fetch();
if (!$b || !$b['file_simpan']) { http_response_code(404); die('File tidak ditemukan.'); }
proposal_akses($pdo, $b['proposal_id']); // cek hak akses
$path = __DIR__ . '/uploads/' . basename($b['file_simpan']);
if (!is_file($path)) { http_response_code(404); die('File sudah tidak ada di server.'); }
$mime = ['pdf' => 'application/pdf', 'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg',
         'doc' => 'application/msword', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'zip' => 'application/zip'];
$ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
$nama = $b['file_asli'] ?: ('file.' . $ext);
header('Content-Type: ' . ($mime[$ext] ?? 'application/octet-stream'));
header('Content-Length: ' . filesize($path));
header('Content-Disposition: attachment; filename="' . str_replace('"', '', $nama) . '"');
header('X-Content-Type-Options: nosniff');
readfile($path);
