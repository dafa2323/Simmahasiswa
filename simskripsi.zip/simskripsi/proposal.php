<?php
require_once __DIR__ . '/includes/auth.php';
wajib();
$u = user();
$aktif = 'proposal';
list($w, $pr) = scope_proposal('p');
$q  = trim($_GET['q'] ?? '');
$fp = (int)($_GET['prodi'] ?? 0);
$fs = $_GET['status'] ?? '';
$wh = [$w]; $par = $pr;
if ($q !== '') { $wh[] = "(p.judul LIKE ? OR m.nama LIKE ? OR m.username LIKE ?)"; $l = '%' . $q . '%'; array_push($par, $l, $l, $l); }
if ($fp) { $wh[] = "m.prodi_id=?"; $par[] = $fp; }
if (in_array($fs, $STATUS, true)) { $wh[] = "p.status=?"; $par[] = $fs; }
$W = implode(' AND ', $wh);

$sc = $pdo->prepare("SELECT COUNT(*) FROM proposal p JOIN users m ON m.id=p.mahasiswa_id WHERE $W");
$sc->execute($par);
$total = (int)$sc->fetchColumn();
$per = 10;
$hal = min(max(1, (int)($_GET['hal'] ?? 1)), max(1, (int)ceil($total / $per)));
$off = ($hal - 1) * $per;
$sr = $pdo->prepare(sql_proposal() . " WHERE $W ORDER BY p.id DESC LIMIT $per OFFSET $off");
$sr->execute($par);
$rows = $sr->fetchAll();
$prodis = $pdo->query("SELECT id,nama FROM prodi ORDER BY nama")->fetchAll();

$judul = 'Data Proposal';
$crumbs = crumb([['Dashboard', 'dashboard.php'], ['Proposal']]);
$aksi = ($u['role'] === 'mahasiswa' || staff()) ? '<a class="btn" href="' . BASE_URL . '/proposal_form.php">' . ikon('plus', 16) . ' Ajukan Proposal</a>' : '';
require __DIR__ . '/includes/header.php';
?>
<div class="card">
  <form class="filters" method="get">
    <div class="cari"><?= ikon('search', 16) ?><input name="q" value="<?= e($q) ?>" placeholder="Cari nama, NPM, atau judul..."></div>
    <?php if ($u['role'] !== 'mahasiswa'): ?>
    <select name="prodi"><option value="0">Semua Prodi</option>
      <?php foreach ($prodis as $d): ?><option value="<?= $d['id'] ?>" <?= $fp == $d['id'] ? 'selected' : '' ?>><?= e($d['nama']) ?></option><?php endforeach; ?>
    </select>
    <?php endif; ?>
    <select name="status"><option value="">Semua Status</option>
      <?php foreach ($STATUS as $st): ?><option <?= $fs === $st ? 'selected' : '' ?>><?= e($st) ?></option><?php endforeach; ?>
    </select>
    <button class="btn">Cari</button>
  </form>
  <div class="wrap"><table class="tb">
    <tr><th>No</th><th>Nama</th><th>NPM</th><th>Judul Proposal</th><th>Prodi</th><th>Status</th><th>Aksi</th></tr>
    <?php foreach ($rows as $i => $r): ?>
    <tr>
      <td><?= $off + $i + 1 ?></td><td><?= e($r['mhs_nama']) ?></td><td><?= e($r['npm']) ?></td>
      <td><?= e(trunc($r['judul'], 50)) ?></td><td><?= e($r['prodi'] ?: '-') ?></td><td><?= badge($r['status']) ?></td>
      <td><div class="aksi">
        <a class="ib biru" title="Detail" href="<?= BASE_URL ?>/proposal_detail.php?id=<?= $r['id'] ?>"><?= ikon('eye', 15) ?></a>
        <?php if (bisa_edit($r)): ?><a class="ib hijau" title="Edit" href="<?= BASE_URL ?>/proposal_form.php?id=<?= $r['id'] ?>"><?= ikon('edit', 15) ?></a><?php endif; ?>
        <?php if (bisa_hapus($r)): ?>
        <form method="post" action="<?= BASE_URL ?>/proposal_hapus.php" onsubmit="return confirm('Hapus proposal ini beserta semua catatan dan filenya?')" style="margin:0">
          <?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['id'] ?>">
          <button class="ib merah" title="Hapus"><?= ikon('trash', 15) ?></button></form>
        <?php endif; ?>
      </div></td>
    </tr>
    <?php endforeach; if (!$rows): ?><tr><td colspan="7" class="kosong">Tidak ada data proposal.</td></tr><?php endif; ?>
  </table></div>
  <?= paginasi($total, $hal, $per) ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
