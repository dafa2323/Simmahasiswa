<?php
require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/fungsi.php';
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

function cek_login($pdo, $un, $pw) {
    $s = $pdo->prepare("SELECT * FROM users WHERE username=? AND aktif=1");
    $s->execute([$un]);
    $u = $s->fetch();
    return ($u && password_verify($pw, $u['password'])) ? $u : false;
}
function user() { return $_SESSION['user'] ?? null; }
function staff() { $u = user(); return $u && in_array($u['role'], ['admin', 'kaprodi'], true); }
function wajib(...$roles) {
    if (!user()) redirect('login.php');
    if ($roles && !in_array(user()['role'], $roles, true)) {
        http_response_code(403);
        die('Akses ditolak (403): peran Anda tidak memiliki izin untuk halaman ini.');
    }
}

// Batas data proposal sesuai peran: staf = semua, dosen = yang dibimbing, mahasiswa = milik sendiri
function scope_proposal($a = 'p') {
    $u = user();
    if (staff()) return ['1=1', []];
    if ($u['role'] === 'dosen') return ["$a.pembimbing_id=?", [$u['id']]];
    return ["$a.mahasiswa_id=?", [$u['id']]];
}
function aktivitas_scope($a = 'a') {
    $u = user();
    if (staff()) return ['1=1', []];
    $kol = $u['role'] === 'dosen' ? 'pembimbing_id' : 'mahasiswa_id';
    return ["$a.proposal_id IN (SELECT id FROM proposal WHERE $kol=?)", [$u['id']]];
}
function proposal_akses($pdo, $id) {
    list($w, $pr) = scope_proposal('p');
    $s = $pdo->prepare(sql_proposal() . " WHERE p.id=? AND $w");
    $s->execute(array_merge([$id], $pr));
    $p = $s->fetch();
    if (!$p) { http_response_code(404); die('Proposal tidak ditemukan atau Anda tidak berhak mengaksesnya.'); }
    return $p;
}
function bisa_edit($p) {
    $u = user();
    if (staff()) return true;
    return $u['role'] === 'mahasiswa' && (int)$p['mahasiswa_id'] === (int)$u['id'] && in_array($p['status'], ['Diajukan', 'Ditolak'], true);
}
function bisa_hapus($p) {
    $u = user();
    if (staff()) return true;
    return $u['role'] === 'mahasiswa' && (int)$p['mahasiswa_id'] === (int)$u['id'] && $p['status'] === 'Diajukan';
}
function bisa_status($p) {
    $u = user();
    return staff() || ($u['role'] === 'dosen' && (int)$p['pembimbing_id'] === (int)$u['id']);
}

function menu_untuk($role) {
    $m = [
        'dashboard' => ['Dashboard', 'dashboard.php', 'grid'],
        'proposal'  => ['Proposal', 'proposal.php', 'file'],
        'bimbingan' => ['Bimbingan', 'bimbingan.php', 'chat'],
        'seminar'   => ['Seminar', 'jadwal.php?j=Seminar', 'calendar'],
        'sidang'    => ['Sidang', 'jadwal.php?j=Sidang', 'award'],
    ];
    if (in_array($role, ['admin', 'kaprodi'], true)) {
        $m['mahasiswa'] = ['Mahasiswa', 'pengguna.php?r=mahasiswa', 'users'];
        $m['dosen']     = ['Dosen Pembimbing', 'pengguna.php?r=dosen', 'user'];
        $m['jadwal']    = ['Jadwal', 'jadwal.php', 'clock'];
        $m['master']    = ['Master Data', 'master.php', 'db'];
        $m['laporan']   = ['Laporan', 'laporan.php', 'chart'];
    } elseif ($role === 'dosen') {
        $m['jadwal'] = ['Jadwal', 'jadwal.php', 'clock'];
        $m['profil'] = ['Profil Saya', 'profil.php', 'user'];
    } else {
        $m['dokumen'] = ['Dokumen', 'bimbingan.php?jenis=dokumen', 'folder'];
        $m['profil']  = ['Profil Saya', 'profil.php', 'user'];
    }
    return $m;
}
