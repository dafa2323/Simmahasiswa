<?php
require_once __DIR__ . '/auth.php';
wajib();
$u = user();
$menu = menu_untuk($u['role']);
list($aw, $ap) = aktivitas_scope('a');
$sn = $pdo->prepare("SELECT COUNT(*) FROM aktivitas a WHERE $aw AND a.waktu >= ?");
$sn->execute(array_merge($ap, [date('Y-m-d H:i:s', time() - 86400)]));
$notif = (int)$sn->fetchColumn();
$inisial = strtoupper(mb_substr($u['nama'], 0, 1, 'UTF-8'));
$aktif = $aktif ?? '';
?>
<!DOCTYPE html>
<html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($judul ?? 'SIMSKRIPSI') ?> - SIMSKRIPSI UMB</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/app.css">
</head><body>
<div class="layout">
<aside class="sb" id="sb">
  <div class="sb-logo"><?= logo(38) ?><span>SIMSKRIPSI<br>UMB</span></div>
  <nav>
  <?php foreach ($menu as $k => $m): ?>
    <a href="<?= BASE_URL . '/' . $m[1] ?>" class="<?= $aktif === $k ? 'on' : '' ?>"><?= ikon($m[2], 16) ?><?= e($m[0]) ?></a>
  <?php endforeach; ?>
  </nav>
</aside>
<div class="main">
  <header class="top noprint">
    <button class="burger" type="button" onclick="document.getElementById('sb').classList.toggle('buka')" aria-label="Menu"><?= ikon('menu', 22) ?></button>
    <div class="grow"></div>
    <a class="bell" href="<?= BASE_URL ?>/dashboard.php" title="Aktivitas 24 jam terakhir"><?= ikon('bell', 20) ?><?php if ($notif): ?><i><?= $notif > 9 ? '9+' : $notif ?></i><?php endif; ?></a>
    <a class="me" href="<?= BASE_URL ?>/profil.php">
      <span class="av"><?= e($inisial) ?></span>
      <span class="meinfo"><b><?= e($u['nama']) ?></b><small><?= e(ucfirst($u['role'])) ?></small></span>
    </a>
    <a class="keluar" href="<?= BASE_URL ?>/logout.php" title="Keluar"><?= ikon('logout', 18) ?></a>
  </header>
  <div class="content">
    <div class="ptitle">
      <div>
        <h1><?= e($judul ?? '') ?></h1>
        <?php if (!empty($sub)): ?><p><?= e($sub) ?></p><?php endif; ?>
        <?= $crumbs ?? '' ?>
      </div>
      <?php if (!empty($aksi)): ?><div class="noprint"><?= $aksi ?></div><?php endif; ?>
    </div>
    <?= flash_tampil() ?>
