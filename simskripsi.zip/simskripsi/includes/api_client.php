<?php
// Klien web service: SIMSKRIPSI bertanya ke SIMMAHASISWA dan SIMDOSEN.
// Analogi bank: SIMSKRIPSI = web kampus, kedua web lain = "bank" pemilik data.

function api_config() {
    static $cfg = null;
    if ($cfg === null) $cfg = require __DIR__ . '/../config/api.php';
    return $cfg;
}

// Satu permintaan HTTP. Selalu mengembalikan array: ok, code, data, err
function api_http($method, $url, $headers = [], $body = null) {
    if (!function_exists('curl_init')) {
        return ['ok' => false, 'code' => 0, 'data' => null, 'err' => 'Ekstensi cURL PHP belum aktif'];
    }
    $h = array_merge(['Accept: application/json'], $headers);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 4);
    curl_setopt($ch, CURLOPT_TIMEOUT, 8);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        $h[] = 'Content-Type: application/json';
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $h);
    $raw  = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $cerr = curl_error($ch);
    curl_close($ch);
    if ($raw === false) {
        return ['ok' => false, 'code' => 0, 'data' => null, 'err' => $cerr ?: 'Tidak dapat terhubung ke layanan'];
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        return ['ok' => false, 'code' => $code, 'data' => null, 'err' => 'Respons bukan JSON (HTTP ' . $code . ')'];
    }
    return ['ok' => $code >= 200 && $code < 300, 'code' => $code, 'data' => $data, 'err' => (string)($data['pesan'] ?? '')];
}

// Login ke layanan, simpan token di session supaya tidak login berulang
function api_token($svc, $paksa = false) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $t = $_SESSION['api_token'][$svc] ?? null;
    if (!$paksa && $t && $t['exp'] > time()) return ['ok' => true, 'token' => $t['token'], 'err' => ''];
    $c = api_config()[$svc];
    $r = api_http('POST', $c['url'] . '/login.php', [], ['username' => $c['username'], 'password' => $c['password']]);
    if (!$r['ok'] || empty($r['data']['token'])) {
        return ['ok' => false, 'token' => '', 'err' => 'Login ke layanan gagal: ' . ($r['err'] ?: 'HTTP ' . $r['code'])];
    }
    $_SESSION['api_token'][$svc] = ['token' => $r['data']['token'], 'exp' => time() + 3600 * 12];
    return ['ok' => true, 'token' => $r['data']['token'], 'err' => ''];
}

// GET ke layanan dengan token. Kalau token ditolak (401), login ulang sekali.
function api_get($svc, $path, $params = []) {
    $c = api_config()[$svc];
    $url = $c['url'] . '/' . $path . ($params ? '?' . http_build_query($params) : '');
    for ($i = 0; $i < 2; $i++) {
        $t = api_token($svc, $i === 1);
        if (!$t['ok']) return ['ok' => false, 'code' => 0, 'data' => null, 'err' => $t['err']];
        $r = api_http('GET', $url, ['Authorization: Bearer ' . $t['token']]);
        if ($r['code'] !== 401) return $r;
    }
    return $r;
}

// ---------- SIMMAHASISWA ----------
// Cek NPM: harus ada dan berstatus Aktif. Mengembalikan ['ok'=>bool, 'pesan'=>string, 'data'=>array|null]
function mhs_cek_npm($npm) {
    $npm = trim((string)$npm);
    $r = api_get('mahasiswa', 'mahasiswa.php', ['npm' => $npm]);
    if ($r['code'] === 404) {
        return ['ok' => false, 'data' => null, 'pesan' => 'NPM ' . $npm . ' tidak terdaftar di SIMMAHASISWA.'];
    }
    if (!$r['ok']) {
        return ['ok' => false, 'data' => null, 'pesan' => 'Layanan SIMMAHASISWA tidak dapat dihubungi (' . $r['err'] . '). Coba lagi nanti.'];
    }
    $m = $r['data']['data'] ?? null;
    if (!$m) return ['ok' => false, 'data' => null, 'pesan' => 'Respons SIMMAHASISWA tidak sesuai format.'];
    if (($m['status_mahasiswa'] ?? '') !== 'Aktif') {
        return ['ok' => false, 'data' => $m, 'pesan' => 'Pengajuan ditolak: status mahasiswa di SIMMAHASISWA adalah "' . ($m['status_mahasiswa'] ?? '-') . '". Hanya mahasiswa berstatus Aktif yang dapat mengajukan proposal.'];
    }
    return ['ok' => true, 'data' => $m, 'pesan' => ''];
}

// ---------- SIMDOSEN ----------
// Peta semua dosen di SIMDOSEN: kode (NIP, atau nomor registrasi jika NIP kosong) => nama + status aktivitas.
// Hanya satu kali panggilan per halaman (hasilnya disimpan sementara).
function dosen_status_peta() {
    static $cache = null;
    if ($cache !== null) return $cache;
    $r = api_get('dosen', 'dosen.php');
    if (!$r['ok']) return $cache = ['ok' => false, 'peta' => [], 'err' => $r['err'] ?: 'HTTP ' . $r['code']];
    $peta = [];
    foreach (($r['data']['data'] ?? []) as $d) {
        $kode = trim((string)($d['nip'] ?? '')) !== '' ? trim($d['nip']) : trim((string)($d['nomor_registrasi'] ?? ''));
        if ($kode === '') continue;
        $peta[$kode] = ['nama' => $d['nama'], 'status' => (string)($d['status_aktivitas'] ?? '-')];
    }
    return $cache = ['ok' => true, 'peta' => $peta, 'err' => ''];
}

// Daftar dosen berstatus aktivitas "Aktif" (untuk pilihan pembimbing).
function dosen_aktif_api() {
    $h = dosen_status_peta();
    if (!$h['ok']) return ['ok' => false, 'data' => [], 'err' => $h['err']];
    $out = [];
    foreach ($h['peta'] as $kode => $d) {
        // kunci array berupa angka (NIP) otomatis menjadi integer di PHP, jadi paksa kembali ke teks
        if ($d['status'] === 'Aktif') $out[] = ['kode' => (string)$kode, 'nama' => $d['nama']];
    }
    return ['ok' => true, 'data' => $out, 'err' => ''];
}

// Sinkronkan kolom users.aktif di SIMSKRIPSI dengan status aktivitas di SIMDOSEN.
// Status "Aktif" di SIMDOSEN -> aktif=1; status lain (Cuti, Pensiun, dst) -> aktif=0.
// Hanya menyentuh akun dosen yang NIP/kodenya ada di SIMDOSEN. Mengembalikan peta status.
function dosen_sinkron_status($pdo) {
    $h = dosen_status_peta();
    if (!$h['ok']) return $h;
    $rows = $pdo->query("SELECT id, username, nama, aktif FROM users WHERE role='dosen'")->fetchAll();
    $up = $pdo->prepare("UPDATE users SET aktif=?, nama=? WHERE id=?");
    foreach ($rows as $x) {
        if (!isset($h['peta'][$x['username']])) continue;
        $d = $h['peta'][$x['username']];
        $ak = $d['status'] === 'Aktif' ? 1 : 0;
        if ((int)$x['aktif'] !== $ak || $x['nama'] !== $d['nama']) $up->execute([$ak, $d['nama'], $x['id']]);
    }
    return $h;
}

// Pastikan dosen dari SIMDOSEN punya akun lokal di SIMSKRIPSI (hanya referensi: kode + nama).
// Mengembalikan id users lokal.
function dosen_lokal_dari_kode($pdo, $kode, $daftar) {
    $dosen = null;
    foreach ($daftar as $d) if ($d['kode'] === $kode) { $dosen = $d; break; }
    if (!$dosen) throw new Exception('Dosen pembimbing tidak ditemukan atau tidak berstatus Aktif di SIMDOSEN.');
    $s = $pdo->prepare("SELECT id, role FROM users WHERE username=?");
    $s->execute([$kode]);
    $ada = $s->fetch();
    if ($ada) {
        if ($ada['role'] !== 'dosen') throw new Exception('Kode dosen bentrok dengan akun lain di SIMSKRIPSI.');
        $pdo->prepare("UPDATE users SET nama=?, aktif=1 WHERE id=?")->execute([$dosen['nama'], $ada['id']]);
        return (int)$ada['id'];
    }
    // password awal akun dosen = "password" (sama seperti data contoh)
    $hash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';
    $pdo->prepare("INSERT INTO users (username,nama,password,role,prodi_id,aktif,created_at) VALUES (?,?,?,'dosen',NULL,1,?)")
        ->execute([$kode, $dosen['nama'], $hash, sekarang()]);
    return (int)$pdo->lastInsertId();
}
