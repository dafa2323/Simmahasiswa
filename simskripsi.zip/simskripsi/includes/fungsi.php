<?php
// Cadangan bila ekstensi mbstring tidak aktif di hosting
if (!function_exists('mb_substr')) {
    function mb_substr($s, $a, $l = null, $enc = null) {
        $c = preg_split('//u', (string)$s, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        return implode('', array_slice($c, $a, $l));
    }
}
if (!function_exists('mb_strlen')) {
    function mb_strlen($s, $enc = null) { return count(preg_split('//u', (string)$s, -1, PREG_SPLIT_NO_EMPTY) ?: []); }
}
if (!function_exists('mb_strimwidth')) {
    function mb_strimwidth($s, $st, $w, $tm = '', $enc = null) {
        $c = preg_split('//u', (string)$s, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        if (count($c) - $st <= $w) return implode('', array_slice($c, $st));
        $tl = count(preg_split('//u', (string)$tm, -1, PREG_SPLIT_NO_EMPTY) ?: []);
        return implode('', array_slice($c, $st, max(0, $w - $tl))) . $tm;
    }
}
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function csrf() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function csrf_field() { return '<input type="hidden" name="csrf" value="' . csrf() . '">'; }
function csrf_cek() {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419);
        die('Token CSRF tidak valid. Muat ulang halaman lalu coba lagi.');
    }
}
function flash($pesan, $tipe = 'ok') { $_SESSION['flash'] = [$tipe, $pesan]; }
function flash_tampil() {
    if (empty($_SESSION['flash'])) return '';
    list($t, $m) = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return '<div class="alert ' . ($t === 'ok' ? 'ok' : 'err') . '">' . e($m) . '</div>';
}
function redirect($path) { header('Location: ' . BASE_URL . '/' . ltrim($path, '/')); exit; }

// ---------- Status & tanggal ----------
$STATUS = ['Diajukan', 'Disetujui', 'Bimbingan', 'Seminar', 'Sidang', 'Selesai', 'Ditolak'];
$ALUR   = ['Diajukan', 'Disetujui', 'Bimbingan', 'Seminar', 'Sidang', 'Selesai'];
$WARNA  = ['Diajukan' => '#2f6fed', 'Disetujui' => '#1fa65a', 'Bimbingan' => '#f5b02e', 'Seminar' => '#f97316',
           'Sidang' => '#8b5cf6', 'Selesai' => '#14b8a6', 'Ditolak' => '#ef4444'];
$BULAN  = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

function badge($s) { return '<span class="pill s-' . strtolower($s) . '">' . e($s) . '</span>'; }
function tgl($d) { return $d ? date('d-m-Y', strtotime($d)) : '-'; }
function tgl_id($dt, $jam = false) {
    global $BULAN;
    if (!$dt) return '-';
    $t = strtotime($dt);
    return date('j', $t) . ' ' . $BULAN[(int)date('n', $t)] . ' ' . date('Y', $t) . ($jam ? ' ' . date('H:i', $t) : '');
}
function trunc($s, $n = 40) { return mb_strimwidth((string)$s, 0, $n, '...', 'UTF-8'); }
function sekarang() { return date('Y-m-d H:i:s'); }

// ---------- Ikon (inline SVG) ----------
function ikon($n, $s = 18) {
    static $p = [
        'grid' => '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
        'file' => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
        'chat' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
        'calendar' => '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
        'award' => '<circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/>',
        'users' => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'user' => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'clock' => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
        'db' => '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>',
        'chart' => '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
        'bell' => '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
        'eye' => '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
        'edit' => '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/>',
        'trash' => '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
        'plus' => '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
        'upload' => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>',
        'download' => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
        'check' => '<polyline points="20 6 9 17 4 12"/>',
        'lock' => '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
        'search' => '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
        'logout' => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
        'arrow' => '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>',
        'folder' => '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
        'print' => '<polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
        'menu' => '<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
    ];
    return '<svg class="ic" width="' . $s . '" height="' . $s . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' . ($p[$n] ?? '') . '</svg>';
}

// Logo: pakai assets/logo.png bila ada, kalau tidak pakai gambar pengganti
function logo($s = 44) {
    if (file_exists(__DIR__ . '/../assets/logo.png'))
        return '<img src="' . BASE_URL . '/assets/logo.png" width="' . $s . '" height="' . $s . '" alt="Logo UM Bengkulu" style="object-fit:contain">';
    return '<svg width="' . $s . '" height="' . $s . '" viewBox="0 0 48 48"><circle cx="24" cy="24" r="23" fill="#0b5d3b"/><circle cx="24" cy="24" r="17" fill="#f5c542"/><circle cx="24" cy="24" r="12" fill="#0b5d3b"/><text x="24" y="28" text-anchor="middle" font-size="9" font-weight="700" fill="#fff" font-family="Arial">UMB</text></svg>';
}

function crumb($arr) {
    $o = [];
    foreach ($arr as $c) $o[] = isset($c[1]) ? '<a href="' . BASE_URL . '/' . $c[1] . '">' . e($c[0]) . '</a>' : '<span>' . e($c[0]) . '</span>';
    return '<div class="crumb">' . implode(' <i>&rsaquo;</i> ', $o) . '</div>';
}

// ---------- Query proposal ----------
function sql_proposal() {
    return "SELECT p.*, m.nama mhs_nama, m.username npm, m.prodi_id, pr.nama prodi, d.nama dosen_nama
            FROM proposal p
            JOIN users m ON m.id=p.mahasiswa_id
            LEFT JOIN prodi pr ON pr.id=m.prodi_id
            LEFT JOIN users d ON d.id=p.pembimbing_id ";
}

function paginasi($total, $hal, $per) {
    $n = max(1, (int)ceil($total / $per));
    $q = $_GET; unset($q['hal']);
    $url = function ($h) use ($q) { return '?' . http_build_query($q + ['hal' => $h]); };
    $awal = $total ? ($hal - 1) * $per + 1 : 0;
    $akhir = min($total, $hal * $per);
    $o = '<div class="pager"><span>Menampilkan ' . $awal . ' - ' . $akhir . ' dari ' . $total . ' data</span><div>';
    if ($n > 1) {
        $o .= $hal > 1 ? '<a href="' . e($url($hal - 1)) . '">&lsaquo;</a>' : '<b class="off">&lsaquo;</b>';
        $a = max(1, $hal - 2); $z = min($n, $a + 4); $a = max(1, $z - 4);
        for ($i = $a; $i <= $z; $i++)
            $o .= $i == $hal ? '<b class="on">' . $i . '</b>' : '<a href="' . e($url($i)) . '">' . $i . '</a>';
        $o .= $hal < $n ? '<a href="' . e($url($hal + 1)) . '">&rsaquo;</a>' : '<b class="off">&rsaquo;</b>';
    }
    return $o . '</div></div>';
}

// ---------- Log & upload ----------
function aktivitas($pdo, $teks, $tipe = 'proposal', $pid = null) {
    $pdo->prepare("INSERT INTO aktivitas (proposal_id,tipe,teks,waktu) VALUES (?,?,?,?)")->execute([$pid, $tipe, $teks, sekarang()]);
}
function log_status($pdo, $pid, $status, $oleh) {
    $pdo->prepare("INSERT INTO proposal_log (proposal_id,status,waktu,oleh) VALUES (?,?,?,?)")->execute([$pid, $status, sekarang(), $oleh]);
}
function render_aktivitas($rows) {
    $map = ['proposal' => ['file', '#f59e0b', '#fff4e0'], 'bimbingan' => ['chat', '#2f6fed', '#e8f0ff'],
            'status' => ['check', '#1fa65a', '#e3f6ec'], 'jadwal' => ['calendar', '#ef4444', '#fde8e8']];
    if (!$rows) return '<p class="mut">Belum ada aktivitas.</p>';
    $o = '<ul class="akt">';
    foreach ($rows as $r) {
        $m = $map[$r['tipe']] ?? $map['proposal'];
        $o .= '<li><span class="aki" style="color:' . $m[1] . ';background:' . $m[2] . '">' . ikon($m[0], 14) . '</span><div>'
            . e($r['teks']) . '<small>' . e(tgl_id($r['waktu'], true)) . '</small></div></li>';
    }
    return $o . '</ul>';
}

function upload_simpan($f) {
    if (empty($f['name']) || $f['error'] === UPLOAD_ERR_NO_FILE) return null;
    if ($f['error'] !== UPLOAD_ERR_OK) throw new Exception('Upload file gagal (kode ' . $f['error'] . ').');
    if ($f['size'] > 5 * 1024 * 1024) throw new Exception('Ukuran file maksimal 5 MB.');
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png', 'zip'], true))
        throw new Exception('Tipe file tidak diizinkan (boleh: pdf, doc, docx, jpg, png, zip).');
    $dir = __DIR__ . '/../uploads';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $nama = bin2hex(random_bytes(12)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $nama)) throw new Exception('Gagal menyimpan file ke server.');
    $asli = substr(preg_replace('/[^\w.\- ]+/u', '_', basename($f['name'])), 0, 150);
    return [$asli, $nama];
}
