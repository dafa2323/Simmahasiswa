<?php
require_once __DIR__ . '/includes/auth.php';
wajib();
$u = user();
$jenis = $_GET['jenis'] ?? 'bimbingan';
if (!in_array($jenis, ['bimbingan', 'revisi', 'dokumen'], true)) $jenis = 'bimbingan';
$aktif = ($jenis === 'dokumen' && $u['role'] === 'mahasiswa') ? 'dokumen' : 'bimbingan';
list($w, $pr) = scope_proposal('p');
$q = trim($_GET['q'] ?? '');
$wh = "$w AND b.jenis=?"; $par = array_merge($pr, [$jenis]);
if ($q !== '') { $wh .= " AND (m.nama LIKE ? OR m.username LIKE ? OR p.judul LIKE ? OR b.catatan LIKE ?)"; $l = '%' . $q . '%'; array_push($par, $l, $l, $l, $l); }
$base = "FROM bimbingan b JOIN proposal p ON p.id=b.proposal_id JOIN users m ON m.id=p.mahasiswa_id LEFT JOIN users x ON x.id=b.dibuat_oleh WHERE $wh";
$sc = $pdo->prepare("SELECT COUNT(*) $base"); $sc->execute($par);
$total = (int)$sc->fetchColumn();
$per = 10;
$hal = min(max(1, (int)($_GET['hal'] ?? 1)), max(1, (int)ceil($total / $per)));
$off = ($hal - 1) * $per;
$sr = $pdo->prepare("SELECT b.*, p.judul, m.nama mhs_nama, m.username npm, x.nama oleh_nama $base ORDER BY b.tanggal DESC, b.id DESC LIMIT $per OFFSET $off");
$sr->execute($par);
$rows = $sr->fetchAll();
$judul = ['bimbingan' => 'Bimbingan', 'revisi' => 'Revisi', 'dokumen' => 'Dokumen'][$jenis];
$sub = 'Daftar ' . strtolower($judul) . ' dari seluruh proposal yang dapat Anda akses. Untuk menambah data, buka Detail Proposal.';
require __DIR__ . '/includes/header.php';
?>
<div class="card">
  <div class="tabs">
    <?php foreach (['bimbingan' => 'Bimbingan', 'revisi' => 'Revisi', 'dokumen' => 'Dokumen'] as $k => $lb): ?>
      <a class="<?= $jenis === $k ? 'on' : '' ?>" href="?jenis=<?= $k ?>"><?= $lb ?></a>
    <?php endforeach; ?>
  </div>
  <form class="filters" method="get"><input type="hidden" name="jenis" value="<?= e($jenis) ?>">
    <div class="cari"><?= ikon('search', 16) ?><input name="q" value="<?= e($q) ?>" placeholder="Cari nama, NPM, judul, atau catatan..."></div>
    <button class="btn">Cari</button>
  </form>
  <div class="wrap"><table class="tb">
    <tr><th>No</th><th>Tanggal</th><th>Mahasiswa</th><th>Judul Proposal</th><th>Keterangan</th><th>File</th><th>Oleh</th></tr>
    <?php foreach ($rows as $i => $r): ?>
      <tr><td><?= $off + $i + 1 ?></td><td><?= e(tgl($r['tanggal'])) ?></td><td><?= e($r['mhs_nama']) ?><br><small class="mut"><?= e($r['npm']) ?></small></td>
        <td><a href="<?= BASE_URL ?>/proposal_detail.php?id=<?= $r['proposal_id'] ?>&tab=<?= $jenis ?>"><?= e(trunc($r['judul'], 40)) ?></a></td>
        <td><?= nl2br(e($r['catatan'])) ?></td>
        <td><?php if ($r['file_simpan']): ?><a class="file" href="<?= BASE_URL ?>/unduh.php?id=<?= $r['id'] ?>"><?= ikon('download', 14) ?> <?= e($r['file_asli']) ?></a><?php else: ?>-<?php endif; ?></td>
        <td><?= e($r['oleh_nama'] ?: '-') ?></td></tr>
    <?php endforeach; if (!$rows): ?><tr><td colspan="7" class="kosong">Belum ada data.</td></tr><?php endif; ?>
  </table></div>
  <?= paginasi($total, $hal, $per) ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
