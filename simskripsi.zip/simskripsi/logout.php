<?php
require_once __DIR__ . '/includes/auth.php';
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    setcookie(session_name(), '', ['expires' => time() - 3600, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
}
session_destroy();
header('Location: ' . BASE_URL . '/login.php');
exit;
