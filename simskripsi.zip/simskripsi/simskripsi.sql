-- SIMSKRIPSI - Sistem Informasi Skripsi Mahasiswa (UM Bengkulu)
-- Import lewat phpMyAdmin > tab Import. Aman diimpor ulang (tabel lama dihapus).
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS aktivitas;
DROP TABLE IF EXISTS jadwal;
DROP TABLE IF EXISTS bimbingan;
DROP TABLE IF EXISTS proposal_log;
DROP TABLE IF EXISTS proposal;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS prodi;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE prodi (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kode VARCHAR(10) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,      -- NPM (mahasiswa) / NIP (dosen) / akun admin
  nama VARCHAR(100) NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','kaprodi','dosen','mahasiswa') NOT NULL,
  prodi_id INT NULL,
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NULL,
  FOREIGN KEY (prodi_id) REFERENCES prodi(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE proposal (
  id INT AUTO_INCREMENT PRIMARY KEY,
  mahasiswa_id INT NOT NULL,
  pembimbing_id INT NULL,
  judul VARCHAR(255) NOT NULL,
  abstrak TEXT NULL,
  status ENUM('Diajukan','Disetujui','Bimbingan','Seminar','Sidang','Selesai','Ditolak') NOT NULL DEFAULT 'Diajukan',
  tgl_pengajuan DATE NOT NULL,
  created_at DATETIME NULL,
  FOREIGN KEY (mahasiswa_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (pembimbing_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE proposal_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  proposal_id INT NOT NULL,
  status VARCHAR(20) NOT NULL,
  waktu DATETIME NOT NULL,
  oleh INT NULL,
  FOREIGN KEY (proposal_id) REFERENCES proposal(id) ON DELETE CASCADE,
  FOREIGN KEY (oleh) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE bimbingan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  proposal_id INT NOT NULL,
  jenis ENUM('bimbingan','revisi','dokumen') NOT NULL DEFAULT 'bimbingan',
  tanggal DATE NOT NULL,
  catatan TEXT NULL,
  file_asli VARCHAR(160) NULL,
  file_simpan VARCHAR(80) NULL,
  dibuat_oleh INT NULL,
  created_at DATETIME NULL,
  FOREIGN KEY (proposal_id) REFERENCES proposal(id) ON DELETE CASCADE,
  FOREIGN KEY (dibuat_oleh) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE jadwal (
  id INT AUTO_INCREMENT PRIMARY KEY,
  proposal_id INT NOT NULL,
  jenis ENUM('Seminar','Sidang') NOT NULL,
  tanggal DATE NOT NULL,
  jam TIME NULL,
  ruang VARCHAR(80) NULL,
  catatan VARCHAR(255) NULL,
  FOREIGN KEY (proposal_id) REFERENCES proposal(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE aktivitas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  proposal_id INT NULL,
  tipe VARCHAR(20) NOT NULL DEFAULT 'proposal',
  teks VARCHAR(255) NOT NULL,
  waktu DATETIME NOT NULL,
  FOREIGN KEY (proposal_id) REFERENCES proposal(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ===== DATA AWAL (semua password: password) =====
INSERT INTO prodi (id,kode,nama) VALUES
(1,'TI','Teknik Informatika'),(2,'MJ','Manajemen'),(3,'AK','Akuntansi');

INSERT INTO users (id,username,nama,password,role,prodi_id,created_at) VALUES
(1,'admin','Administrator','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin',NULL,NOW()),
(2,'kaprodi','Kaprodi Teknik Informatika','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','kaprodi',1,NOW()),
(3,'dosen1','Dr. Ahmad, M.Kom','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','dosen',1,NOW()),
(4,'dosen2','Dr. Sari Wulandari, M.M.','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','dosen',2,NOW()),
(5,'221010001','Andi Pratama','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','mahasiswa',2,NOW()),
(6,'221010002','Siti Rahmawati','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','mahasiswa',1,NOW()),
(7,'221010003','Budi Santoso','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','mahasiswa',2,NOW()),
(8,'221010004','Dela Anggraini','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','mahasiswa',1,NOW()),
(9,'221010005','Rizky Maulana','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','mahasiswa',1,NOW());

INSERT INTO proposal (id,mahasiswa_id,pembimbing_id,judul,abstrak,status,tgl_pengajuan,created_at) VALUES
(1,5,NULL,'Analisis Sistem Informasi Penjualan terhadap Kinerja UMKM','Penelitian tentang pengaruh sistem informasi penjualan pada kinerja UMKM di Kota Bengkulu.','Diajukan','2026-10-10','2026-10-10 08:15:00'),
(2,6,3,'Implementasi Web Service pada Sistem Informasi Akademik','Perancangan dan implementasi web service REST untuk integrasi data sistem informasi akademik.','Bimbingan','2026-10-01','2026-10-01 09:00:00'),
(3,7,4,'Pengaruh Digital Marketing terhadap Keputusan Pembelian','Kajian pengaruh digital marketing pada keputusan pembelian konsumen.','Bimbingan','2026-09-28','2026-09-28 10:00:00'),
(4,8,3,'Sistem Pendukung Keputusan Penerima Beasiswa','Penerapan metode SAW pada sistem pendukung keputusan penerima beasiswa.','Seminar','2026-09-15','2026-09-15 10:00:00'),
(5,9,NULL,'Implementasi Web Semantik pada Repositori Dosen','Pemanfaatan web semantik untuk pencarian repositori karya dosen.','Ditolak','2026-10-02','2026-10-02 11:00:00');

INSERT INTO proposal_log (proposal_id,status,waktu,oleh) VALUES
(1,'Diajukan','2026-10-10 08:15:00',5),
(2,'Diajukan','2026-10-01 09:00:00',6),(2,'Disetujui','2026-10-03 10:00:00',2),(2,'Bimbingan','2026-10-03 10:05:00',3),
(3,'Diajukan','2026-09-28 10:00:00',7),(3,'Disetujui','2026-09-30 10:00:00',2),(3,'Bimbingan','2026-10-01 10:00:00',4),
(4,'Diajukan','2026-09-15 10:00:00',8),(4,'Disetujui','2026-09-17 10:00:00',2),(4,'Bimbingan','2026-09-18 10:00:00',3),(4,'Seminar','2026-10-06 10:00:00',3),
(5,'Diajukan','2026-10-02 11:00:00',9),(5,'Ditolak','2026-10-09 10:05:00',2);

INSERT INTO bimbingan (proposal_id,jenis,tanggal,catatan,dibuat_oleh,created_at) VALUES
(2,'bimbingan','2026-10-03','Perbaiki latar belakang dan kajian pustaka',3,'2026-10-03 11:00:00'),
(2,'bimbingan','2026-10-08','Lanjut ke metode penelitian',3,'2026-10-08 11:00:00'),
(4,'bimbingan','2026-09-25','Tambahkan perbandingan metode SAW dan TOPSIS',3,'2026-09-25 11:00:00');

INSERT INTO jadwal (proposal_id,jenis,tanggal,jam,ruang,catatan) VALUES
(4,'Seminar','2026-10-20','09:00:00','Ruang Sidang A','Seminar proposal');

INSERT INTO aktivitas (proposal_id,tipe,teks,waktu) VALUES
(1,'proposal','Andi Pratama mengajukan proposal','2026-10-10 08:15:00'),
(2,'bimbingan','Dosen menambahkan catatan bimbingan untuk Siti Rahmawati','2026-10-09 14:20:00'),
(4,'status','Proposal Dela Anggraini masuk tahap Seminar','2026-10-09 10:05:00'),
(4,'jadwal','Jadwal seminar Dela Anggraini ditambahkan','2026-10-08 16:30:00');
