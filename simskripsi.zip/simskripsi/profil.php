<?php
require_once __DIR__ . '/includes/auth.php';
wajib();
$u = user();
$aktif = 'profil';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    try {
        $nm = trim($_POST['nama'] ?? '');
        if ($nm === '') throw new Exception('Nama wajib diisi.');
        $pdo->prepare("UPDATE users SET nama=? WHERE id=?")->execute([$nm, $u['id']]);
        $_SESSION['user']['nama'] = $nm;
        $baru = $_POST['password_baru'] ?? '';
        if ($baru !== '') {
            $s = $pdo->prepare("SELECT password FROM users WHERE id=?"); $s->execute([$u['id']]);
            if (!password_verify($_POST['password_lama'] ?? '', $s->fetchColumn())) throw new Exception('Password lama salah.');
            if (strlen($baru) < 6) throw new Exception('Password baru minimal 6 karakter.');
            if ($baru !== ($_POST['password_baru2'] ?? '')) throw new Exception('Konfirmasi password baru tidak sama.');
            $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([password_hash($baru, PASSWORD_DEFAULT), $u['id']]);
        }
        flash('Profil diperbarui.');
        redirect('profil.php');
    } catch (Exception $ex) { $err = $ex->getMessage(); }
}
$s = $pdo->prepare("SELECT u.*, p.nama prodi FROM users u LEFT JOIN prodi p ON p.id=u.prodi_id WHERE u.id=?");
$s->execute([$u['id']]);
$me = $s->fetch();
$judul = 'Profil Saya';
require __DIR__ . '/includes/header.php';
?>
<div class="card" style="max-width:640px">
  <?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
  <form method="post" autocomplete="off"><?= csrf_field() ?>
    <div class="fg"><label>Username / NPM / NIP</label><input value="<?= e($me['username']) ?>" disabled></div>
    <div class="fg"><label>Peran</label><input value="<?= e(ucfirst($me['role'])) ?>" disabled></div>
    <?php if ($me['prodi']): ?><div class="fg"><label>Program Studi</label><input value="<?= e($me['prodi']) ?>" disabled></div><?php endif; ?>
    <div class="fg"><label>Nama Lengkap</label><input name="nama" value="<?= e($me['nama']) ?>" required></div>
    <h3 style="margin:18px 0 10px">Ganti Password (opsional)</h3>
    <div class="fg"><label>Password Lama</label><input type="password" name="password_lama" autocomplete="current-password"></div>
    <div class="fgrid">
      <div class="fg"><label>Password Baru</label><input type="password" name="password_baru" autocomplete="new-password"></div>
      <div class="fg"><label>Ulangi Password Baru</label><input type="password" name="password_baru2" autocomplete="new-password"></div>
    </div>
    <button class="btn">Simpan</button>
  </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
