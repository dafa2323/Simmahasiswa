<?php
require_once __DIR__ . '/includes/auth.php';
wajib();
$u = user();
$aktif = 'dashboard';
$val = function ($sql, $p = []) use ($pdo) { $s = $pdo->prepare($sql); $s->execute($p); return (int)$s->fetchColumn(); };
list($aw, $ap) = aktivitas_scope('a');

if ($u['role'] === 'mahasiswa') {
    // ===== Dashboard Mahasiswa =====
    $s = $pdo->prepare(sql_proposal() . " WHERE p.mahasiswa_id=? ORDER BY p.id DESC LIMIT 1");
    $s->execute([$u['id']]);
    $p = $s->fetch();
    $tglLog = [];
    if ($p) {
        $l = $pdo->prepare("SELECT status, MIN(waktu) w FROM proposal_log WHERE proposal_id=? GROUP BY status");
        $l->execute([$p['id']]);
        foreach ($l->fetchAll() as $r) $tglLog[$r['status']] = $r['w'];
    }
    $sa = $pdo->prepare("SELECT a.* FROM aktivitas a WHERE $aw ORDER BY a.waktu DESC, a.id DESC LIMIT 4");
    $sa->execute($ap);
    $akt = $sa->fetchAll();

    $judul = 'Dashboard Mahasiswa';
    $sub = 'Selamat datang, ' . $u['nama'];
    require __DIR__ . '/includes/header.php';
    ?>
    <div class="card">
      <h3>Status Skripsi Saya</h3>
      <?php if (!$p): ?>
        <div class="kosong">Anda belum mengajukan proposal.<br><br>
          <a class="btn" href="<?= BASE_URL ?>/proposal_form.php"><?= ikon('plus', 16) ?> Ajukan Proposal</a></div>
      <?php else:
        $idx = array_search($p['status'], $ALUR, true);
        $ditolak = ($p['status'] === 'Ditolak');
        if ($idx === false) $idx = 0; ?>
        <div class="hs">
        <?php foreach ($ALUR as $i => $st):
            if ($ditolak) $kls = $i === 0 ? 'done' : 'pend';
            else $kls = ($i < $idx || ($i === $idx && $st === 'Selesai')) ? 'done' : ($i === $idx ? 'cur' : 'pend'); ?>
          <div class="st <?= $kls ?>"><span class="c"><?= $kls === 'done' ? ikon('check', 18) : ikon('clock', 16) ?></span>
            <b><?= e($st) ?></b>
            <small><?= isset($tglLog[$st]) && $kls !== 'pend' ? e(tgl($tglLog[$st])) : ($kls === 'cur' ? 'Sedang berjalan' : '&nbsp;') ?></small></div>
        <?php endforeach; ?>
        </div>
        <?php if ($ditolak): ?><div class="alert err" style="margin:16px 0 0">Proposal Anda ditolak. Perbaiki judul/abstrak melalui tombol Edit di menu Proposal, lalu ajukan kembali.</div><?php endif; ?>
      <?php endif; ?>
    </div>

    <?php if ($p): ?>
    <div class="two">
      <div class="card">
        <h3>Informasi Proposal</h3>
        <table class="kv">
          <tr><td>Judul</td><td><?= e($p['judul']) ?></td></tr>
          <tr><td>Dosen Pembimbing</td><td><?= e($p['dosen_nama'] ?: 'Belum ditetapkan') ?></td></tr>
          <tr><td>Program Studi</td><td><?= e($p['prodi'] ?: '-') ?></td></tr>
          <tr><td>Tanggal Pengajuan</td><td><?= e(tgl_id($p['tgl_pengajuan'])) ?></td></tr>
          <tr><td>Status</td><td><?= badge($p['status']) ?></td></tr>
        </table>
      </div>
      <div class="card menucepat">
        <h3>Menu Cepat</h3>
        <a href="<?= BASE_URL ?>/proposal_detail.php?id=<?= $p['id'] ?>"><?= ikon('file', 18) ?> Lihat Proposal Saya</a>
        <a href="<?= BASE_URL ?>/proposal_detail.php?id=<?= $p['id'] ?>&tab=bimbingan"><?= ikon('chat', 18) ?> Catatan Bimbingan</a>
        <a href="<?= BASE_URL ?>/proposal_detail.php?id=<?= $p['id'] ?>&tab=revisi"><?= ikon('upload', 18) ?> Upload Revisi</a>
        <a href="<?= BASE_URL ?>/jadwal.php"><?= ikon('calendar', 18) ?> Jadwal Seminar</a>
      </div>
    </div>
    <?php endif; ?>
    <div class="card"><h3>Aktivitas Terbaru</h3><?= render_aktivitas($akt) ?></div>
    <?php
    require __DIR__ . '/includes/footer.php';
    exit;
}

// ===== Dashboard Admin / Kaprodi / Dosen =====
list($w, $pr) = scope_proposal('p');
$totProposal = $val("SELECT COUNT(*) FROM proposal p WHERE $w", $pr);
$totMhs = staff() ? $val("SELECT COUNT(*) FROM users WHERE role='mahasiswa'")
                  : $val("SELECT COUNT(DISTINCT p.mahasiswa_id) FROM proposal p WHERE $w", $pr);
$sedangBimb = $val("SELECT COUNT(*) FROM proposal p WHERE $w AND p.status='Bimbingan'", $pr);
$selesai = $val("SELECT COUNT(*) FROM proposal p WHERE $w AND p.status='Selesai'", $pr);

$s = $pdo->prepare("SELECT p.status, COUNT(*) n FROM proposal p WHERE $w GROUP BY p.status");
$s->execute($pr);
$per = array_fill_keys($STATUS, 0);
foreach ($s->fetchAll() as $r) $per[$r['status']] = (int)$r['n'];
$total = array_sum($per);
if ($total > 0) {
    $seg = []; $acc = 0;
    foreach ($STATUS as $st) {
        if (!$per[$st]) continue;
        $a = $acc; $acc += $per[$st] / $total * 100;
        $seg[] = $WARNA[$st] . ' ' . round($a, 2) . '% ' . round($acc, 2) . '%';
    }
    $grad = 'conic-gradient(' . implode(',', $seg) . ')';
} else $grad = 'conic-gradient(#e5e9f2 0 100%)';

$sa = $pdo->prepare("SELECT a.* FROM aktivitas a WHERE $aw ORDER BY a.waktu DESC, a.id DESC LIMIT 4");
$sa->execute($ap);
$akt = $sa->fetchAll();
$sp = $pdo->prepare(sql_proposal() . " WHERE $w ORDER BY p.created_at DESC, p.id DESC LIMIT 3");
$sp->execute($pr);
$terbaru = $sp->fetchAll();

$judul = 'Dashboard';
$sub = 'Selamat datang di Sistem Informasi Skripsi';
require __DIR__ . '/includes/header.php';
?>
<div class="grid4">
  <div class="card stat"><span class="sbox c-biru"><?= ikon('users', 22) ?></span><div><b><?= $totMhs ?></b><small>Total Mahasiswa</small></div></div>
  <div class="card stat"><span class="sbox c-hijau"><?= ikon('file', 22) ?></span><div><b><?= $totProposal ?></b><small>Proposal</small></div></div>
  <div class="card stat"><span class="sbox c-kuning"><?= ikon('chat', 22) ?></span><div><b><?= $sedangBimb ?></b><small>Sedang Bimbingan</small></div></div>
  <div class="card stat"><span class="sbox c-merah"><?= ikon('award', 22) ?></span><div><b><?= $selesai ?></b><small>Sidang Selesai</small></div></div>
</div>

<div class="dash2">
  <div class="card">
    <h3>Status Proposal</h3>
    <div class="donutwrap">
      <div class="donut" style="background:<?= $grad ?>"><div><b><?= $total ?></b><small>Proposal</small></div></div>
      <ul class="legend">
        <?php foreach ($STATUS as $st): ?>
          <li><i style="background:<?= $WARNA[$st] ?>"></i><?= e($st) ?><span><?= $per[$st] ?></span></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
  <div class="card">
    <div class="hd"><h3>Aktivitas Terbaru</h3></div>
    <?= render_aktivitas($akt) ?>
  </div>
</div>

<div class="card">
  <div class="hd"><h3>Proposal Terbaru</h3><a href="<?= BASE_URL ?>/proposal.php">Lihat Semua</a></div>
  <div class="wrap"><table class="tb">
    <tr><th>No</th><th>Nama</th><th>Judul Proposal</th><th>Prodi</th><th>Status</th><th>Tanggal</th></tr>
    <?php foreach ($terbaru as $i => $r): ?>
      <tr><td><?= $i + 1 ?></td><td><?= e($r['mhs_nama']) ?></td>
        <td><a href="<?= BASE_URL ?>/proposal_detail.php?id=<?= $r['id'] ?>"><?= e(trunc($r['judul'], 45)) ?></a></td>
        <td><?= e($r['prodi'] ?: '-') ?></td><td><?= badge($r['status']) ?></td><td><?= e(tgl($r['tgl_pengajuan'])) ?></td></tr>
    <?php endforeach; if (!$terbaru): ?><tr><td colspan="6" class="kosong">Belum ada proposal.</td></tr><?php endif; ?>
  </table></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
