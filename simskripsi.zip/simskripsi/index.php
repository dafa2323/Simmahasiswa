<?php
require_once __DIR__ . '/includes/auth.php';
$masuk = BASE_URL . (user() ? '/dashboard.php' : '/login.php');
$fotoAda = file_exists(__DIR__ . '/assets/kampus.jpg');
$bg = $fotoAda
    ? "linear-gradient(90deg,rgba(255,255,255,.96) 0%,rgba(255,255,255,.82) 42%,rgba(255,255,255,.08) 100%),url('" . BASE_URL . "/assets/kampus.jpg')"
    : 'linear-gradient(120deg,#eef4ff,#dbe8ff)';
?>
<!DOCTYPE html>
<html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SIMSKRIPSI - Universitas Muhammadiyah Bengkulu</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/app.css">
<style>html{scroll-behavior:smooth}</style>
</head><body class="landing">
<header class="lp-nav">
  <a class="brand" href="#beranda"><?= logo(42) ?><span><b>SIMSKRIPSI</b><small>Universitas Muhammadiyah Bengkulu</small></span></a>
  <nav>
    <a href="#beranda">Beranda</a><a href="#informasi">Informasi</a><a href="#panduan">Panduan</a><a href="#kontak">Kontak</a>
    <a class="btn" href="<?= $masuk ?>"><?= user() ? 'Dashboard' : 'Login' ?></a>
  </nav>
</header>

<section class="hero" id="beranda" style="background-image:<?= $bg ?>">
  <h1>Sistem Informasi Skripsi Mahasiswa</h1>
  <p>Mengelola proses pengajuan, bimbingan, seminar hingga yudisium secara online, cepat, transparan dan terintegrasi.</p>
  <a class="btn" href="<?= $masuk ?>"><?= user() ? 'Ke Dashboard' : 'Login ke Sistem' ?> <?= ikon('arrow', 16) ?></a>
</section>

<section class="fitur">
  <div><span class="fi"><?= ikon('file', 24) ?></span>Pengajuan Proposal Online</div>
  <div><span class="fi"><?= ikon('edit', 24) ?></span>Bimbingan Terstruktur</div>
  <div><span class="fi"><?= ikon('chart', 24) ?></span>Monitoring Progress</div>
  <div><span class="fi"><?= ikon('folder', 24) ?></span>Dokumen Terintegrasi</div>
</section>

<section class="sec">
  <h2>Alur Proses Skripsi</h2>
  <div class="alur">
    <div><span class="ac"><?= ikon('file', 20) ?></span><b>1</b>Pengajuan</div>
    <div><span class="ac"><?= ikon('edit', 20) ?></span><b>2</b>Persetujuan<br>Judul</div>
    <div><span class="ac"><?= ikon('users', 20) ?></span><b>3</b>Bimbingan</div>
    <div><span class="ac"><?= ikon('calendar', 20) ?></span><b>4</b>Seminar<br>Proposal</div>
    <div><span class="ac"><?= ikon('award', 20) ?></span><b>5</b>Sidang Skripsi</div>
    <div><span class="ac"><?= ikon('check', 20) ?></span><b>6</b>Yudisium</div>
  </div>
</section>

<section class="sec" id="informasi">
  <h2>Informasi</h2>
  <p class="info">SIMSKRIPSI membantu mahasiswa, dosen pembimbing, kaprodi, dan admin mengelola seluruh tahapan skripsi dalam satu aplikasi: pengajuan judul, penetapan pembimbing, catatan bimbingan, unggah revisi dan dokumen, penjadwalan seminar dan sidang, hingga laporan rekap.</p>
</section>

<section class="sec" id="panduan">
  <h2>Panduan Singkat</h2>
  <ol class="langkah">
    <li>Login menggunakan akun yang diberikan (mahasiswa: NPM, dosen: NIP).</li>
    <li>Mahasiswa mengajukan proposal pada menu Proposal, lalu menunggu persetujuan kaprodi.</li>
    <li>Setelah disetujui dan memiliki pembimbing, catat dan pantau bimbingan serta unggah revisi.</li>
    <li>Pantau jadwal seminar dan sidang pada menu Seminar dan Sidang.</li>
  </ol>
</section>

<section class="sec" id="kontak">
  <h2>Kontak</h2>
  <p class="info">Universitas Muhammadiyah Bengkulu, Jl. Bali, Kota Bengkulu.<br>Untuk bantuan akun, hubungi admin program studi masing-masing.</p>
</section>

<footer class="lp-foot">&copy; <?= date('Y') ?> SIMSKRIPSI - Universitas Muhammadiyah Bengkulu</footer>
</body></html>
