SIMSKRIPSI - Sistem Informasi Skripsi Mahasiswa (UM Bengkulu)
PHP + MySQL, tanpa framework. Cocok untuk InfinityFree.

CARA PASANG (InfinityFree)
a. Client Area > MySQL Databases > buat database baru. Catat: MySQL Host Name, nama database lengkap, MySQL Username, dan password akun hosting.
b. Buka phpMyAdmin database tersebut > tab Import > pilih simskripsi.sql > Go.
c. Buka config/koneksi.php, isi 4 baris paling atas (host, nama database, user, password).
d. Upload SEMUA isi folder ini ke htdocs (boleh ke subfolder, misalnya htdocs/simskripsi).
e. Taruh foto kampus di assets/kampus.jpg dan logo kampus di assets/logo.png (opsional, kalau tidak ada akan memakai gambar pengganti).
f. Buka alamat websitenya, lalu klik Login.

AKUN CONTOH (password semuanya: password)
Admin       : admin
Kaprodi     : kaprodi
Dosen       : dosen1, dosen2
Mahasiswa   : 221010001 sampai 221010005
Segera ganti password lewat menu Profil Saya. Hapus akun contoh yang tidak dipakai.

PERAN DAN HAK AKSES
Admin/Kaprodi : melihat semua proposal, menetapkan pembimbing, mengubah status, mengelola mahasiswa/dosen/prodi, jadwal, laporan.
Dosen         : melihat proposal yang dibimbing, menambah catatan bimbingan, mengubah status, mengatur jadwal.
Mahasiswa     : mengajukan satu proposal, melihat status, menambah catatan/revisi/dokumen, melihat jadwal.

HALAMAN
index.php (beranda), login.php, dashboard.php (admin dan mahasiswa), proposal.php (data proposal),
proposal_detail.php (detail, bimbingan, revisi, dokumen, riwayat), jadwal.php (seminar dan sidang),
pengguna.php (mahasiswa/dosen), master.php (prodi), laporan.php (cetak dan CSV), profil.php.

CATATAN
a. File upload (pdf, doc, docx, jpg, png, zip, maks 5 MB) disimpan di folder uploads dan hanya bisa diunduh lewat aplikasi (unduh.php) oleh pihak yang berhak.
b. Jangan membagikan config/koneksi.php yang sudah berisi password database.
c. Butuh PHP 7.3 ke atas dan ekstensi PDO MySQL (sudah tersedia di InfinityFree).
