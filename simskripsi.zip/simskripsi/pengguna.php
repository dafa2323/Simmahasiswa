<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/api_client.php';
$r = $_GET['r'] ?? $_POST['r'] ?? 'mahasiswa';
if (!in_array($r, ['mahasiswa', 'dosen', 'kaprodi', 'admin'], true)) $r = 'mahasiswa';
if (in_array($r, ['admin', 'kaprodi'], true)) wajib('admin'); else wajib('admin', 'kaprodi');
$u = user();
$LB = ['mahasiswa' => ['Data Mahasiswa', 'NPM'], 'dosen' => ['Dosen Pembimbing', 'NIP'], 'kaprodi' => ['Akun Kaprodi', 'Username'], 'admin' => ['Akun Admin', 'Username']];
$aktif = in_array($r, ['mahasiswa', 'dosen'], true) ? $r : 'master';
$pakaiProdi = in_array($r, ['mahasiswa', 'dosen', 'kaprodi'], true);
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    try {
        if (($_POST['aksi'] ?? '') === 'hapus') {
            $hid = (int)$_POST['id'];
            if ($hid === (int)$u['id']) throw new Exception('Tidak bisa menghapus akun sendiri.');
            $pdo->prepare("DELETE FROM users WHERE id=? AND role=?")->execute([$hid, $r]);
            flash('Akun dihapus.');
        } else {
            $id = (int)($_POST['id'] ?? 0);
            $un = trim($_POST['username'] ?? ''); $nm = trim($_POST['nama'] ?? ''); $pw = $_POST['password'] ?? '';
            $pd = $pakaiProdi ? ((int)($_POST['prodi_id'] ?? 0) ?: null) : null;
            $ak = isset($_POST['aktif']) ? 1 : 0;
            if (!preg_match('/^[A-Za-z0-9_.\-]{3,50}$/', $un)) throw new Exception($LB[$r][1] . ' 3-50 karakter (huruf, angka, titik, minus, underscore).');
            if ($nm === '') throw new Exception('Nama wajib diisi.');
            if (!$id && strlen($pw) < 6) throw new Exception('Password minimal 6 karakter.');
            if ($pw !== '' && strlen($pw) < 6) throw new Exception('Password minimal 6 karakter.');
            if ($id) {
                if ($id === (int)$u['id'] && !$ak) throw new Exception('Tidak bisa menonaktifkan akun sendiri.');
                $pdo->prepare("UPDATE users SET username=?,nama=?,prodi_id=?,aktif=? WHERE id=? AND role=?")->execute([$un, $nm, $pd, $ak, $id, $r]);
                if ($pw !== '') $pdo->prepare("UPDATE users SET password=? WHERE id=? AND role=?")->execute([password_hash($pw, PASSWORD_DEFAULT), $id, $r]);
            } else {
                $pdo->prepare("INSERT INTO users (username,nama,password,role,prodi_id,aktif,created_at) VALUES (?,?,?,?,?,?,?)")
                    ->execute([$un, $nm, password_hash($pw, PASSWORD_DEFAULT), $r, $pd, $ak, sekarang()]);
            }
            flash('Data disimpan.');
        }
        redirect('pengguna.php?r=' . $r);
    } catch (PDOException $e) { $err = $e->getCode() == '23000' ? 'Username sudah dipakai.' : 'Kesalahan database.';
    } catch (Exception $e) { $err = $e->getMessage(); }
}
// Dosen: samakan status aktif dengan SIMDOSEN sebelum daftar ditampilkan
$sinkron = $r === 'dosen' ? dosen_sinkron_status($pdo) : null;
$edit = ['id' => 0, 'username' => '', 'nama' => '', 'prodi_id' => '', 'aktif' => 1];
if (isset($_GET['edit'])) {
    $s = $pdo->prepare("SELECT * FROM users WHERE id=? AND role=?"); $s->execute([(int)$_GET['edit'], $r]);
    if ($x = $s->fetch()) $edit = $x;
}
$q = trim($_GET['q'] ?? '');
$wh = "u.role=?"; $par = [$r];
if ($q !== '') { $wh .= " AND (u.nama LIKE ? OR u.username LIKE ?)"; $par[] = '%' . $q . '%'; $par[] = '%' . $q . '%'; }
$sc = $pdo->prepare("SELECT COUNT(*) FROM users u WHERE $wh"); $sc->execute($par);
$total = (int)$sc->fetchColumn();
$per = 10;
$hal = min(max(1, (int)($_GET['hal'] ?? 1)), max(1, (int)ceil($total / $per)));
$off = ($hal - 1) * $per;
$sr = $pdo->prepare("SELECT u.*, p.nama prodi FROM users u LEFT JOIN prodi p ON p.id=u.prodi_id WHERE $wh ORDER BY u.nama LIMIT $per OFFSET $off");
$sr->execute($par);
$rows = $sr->fetchAll();
$prodis = $pdo->query("SELECT id,nama FROM prodi ORDER BY nama")->fetchAll();
$judul = $LB[$r][0];
$crumbs = crumb([['Dashboard', 'dashboard.php'], [$judul]]);
require __DIR__ . '/includes/header.php';
?>
<div class="card">
  <h3><?= $edit['id'] ? 'Edit Akun' : 'Tambah Akun' ?></h3>
  <?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
  <form method="post" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $edit['id'] ?>"><input type="hidden" name="r" value="<?= e($r) ?>">
    <div class="fgrid">
      <div class="fg"><label><?= $LB[$r][1] ?> (untuk login)</label><input name="username" value="<?= e($edit['username']) ?>" required></div>
      <div class="fg"><label>Nama Lengkap</label><input name="nama" value="<?= e($edit['nama']) ?>" required></div>
      <?php if ($pakaiProdi): ?>
      <div class="fg"><label>Program Studi</label><select name="prodi_id"><option value="0">- pilih -</option>
        <?php foreach ($prodis as $d): ?><option value="<?= $d['id'] ?>" <?= $edit['prodi_id'] == $d['id'] ? 'selected' : '' ?>><?= e($d['nama']) ?></option><?php endforeach; ?></select></div>
      <?php endif; ?>
      <div class="fg"><label>Password <?= $edit['id'] ? '(kosongkan jika tidak diganti)' : '(min. 6 karakter)' ?></label><input type="password" name="password" autocomplete="new-password"></div>
    </div>
    <label style="display:flex;gap:7px;align-items:center;font-weight:400"><input type="checkbox" name="aktif" <?= $edit['aktif'] ? 'checked' : '' ?>> Akun aktif</label><br>
    <button class="btn">Simpan</button> <?php if ($edit['id']): ?><a class="btn abu" href="?r=<?= e($r) ?>">Batal</a><?php endif; ?>
  </form>
</div>
<div class="card">
  <form class="filters" method="get"><input type="hidden" name="r" value="<?= e($r) ?>">
    <div class="cari"><?= ikon('search', 16) ?><input name="q" value="<?= e($q) ?>" placeholder="Cari nama atau <?= e($LB[$r][1]) ?>..."></div><button class="btn">Cari</button></form>
  <?php if ($r === 'dosen'): ?>
    <?php if ($sinkron && !$sinkron['ok']): ?><div class="alert err">Status dosen dari SIMDOSEN tidak dapat dimuat: <?= e($sinkron['err']) ?>. Kolom Aktif belum diperbarui.</div>
    <?php else: ?><p style="margin:6px 0;color:#667">Status aktif dosen diperbarui otomatis dari SIMDOSEN setiap halaman ini dibuka.</p><?php endif; ?>
  <?php endif; ?>
  <div class="wrap"><table class="tb">
    <tr><th>No</th><th><?= $LB[$r][1] ?></th><th>Nama</th><?php if ($pakaiProdi): ?><th>Prodi</th><?php endif; ?><?php if ($r === 'dosen'): ?><th>Status di SIMDOSEN</th><?php endif; ?><th>Aktif</th><th>Aksi</th></tr>
    <?php foreach ($rows as $i => $x): ?>
      <tr><td><?= $off + $i + 1 ?></td><td><?= e($x['username']) ?></td><td><?= e($x['nama']) ?></td>
        <?php if ($pakaiProdi): ?><td><?= e($x['prodi'] ?: '-') ?></td><?php endif; ?>
        <?php if ($r === 'dosen'): ?><td><?= $sinkron && $sinkron['ok'] ? e($sinkron['peta'][$x['username']]['status'] ?? 'Tidak terdaftar di SIMDOSEN') : '-' ?></td><?php endif; ?>
        <td><?= $x['aktif'] ? 'Ya' : 'Tidak' ?></td>
        <td><div class="aksi"><a class="ib hijau" title="Edit" href="?r=<?= e($r) ?>&edit=<?= $x['id'] ?>"><?= ikon('edit', 15) ?></a>
          <form method="post" onsubmit="return confirm('Hapus akun ini? Proposal terkait ikut terhapus.')" style="margin:0"><?= csrf_field() ?>
            <input type="hidden" name="aksi" value="hapus"><input type="hidden" name="r" value="<?= e($r) ?>"><input type="hidden" name="id" value="<?= $x['id'] ?>">
            <button class="ib merah" title="Hapus"><?= ikon('trash', 15) ?></button></form></div></td></tr>
    <?php endforeach; if (!$rows): ?><tr><td colspan="6" class="kosong">Belum ada data.</td></tr><?php endif; ?>
  </table></div>
  <?= paginasi($total, $hal, $per) ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
