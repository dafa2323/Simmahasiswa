<?php
require_once __DIR__ . '/includes/auth.php';
wajib('admin', 'kaprodi');
$aktif = 'laporan';
$fp = (int)($_GET['prodi'] ?? 0);
$fs = $_GET['status'] ?? '';
$wh = ['1=1']; $par = [];
if ($fp) { $wh[] = 'm.prodi_id=?'; $par[] = $fp; }
if (in_array($fs, $STATUS, true)) { $wh[] = 'p.status=?'; $par[] = $fs; }
$s = $pdo->prepare(sql_proposal() . ' WHERE ' . implode(' AND ', $wh) . ' ORDER BY pr.nama, m.nama');
$s->execute($par);
$rows = $s->fetchAll();

if (isset($_GET['csv'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="laporan-proposal-' . date('Ymd') . '.csv"');
    $o = fopen('php://output', 'w');
    fwrite($o, "\xEF\xBB\xBF");
    fputcsv($o, ['No', 'NPM', 'Nama', 'Prodi', 'Judul', 'Pembimbing', 'Status', 'Tgl Pengajuan']);
    foreach ($rows as $i => $r) fputcsv($o, [$i + 1, $r['npm'], $r['mhs_nama'], $r['prodi'], $r['judul'], $r['dosen_nama'], $r['status'], $r['tgl_pengajuan']]);
    exit;
}
$prodis = $pdo->query("SELECT id,nama FROM prodi ORDER BY nama")->fetchAll();
$judul = 'Laporan Proposal Skripsi';
$sub = 'Rekap proposal per program studi dan status. Dicetak ' . tgl_id(date('Y-m-d'));
$qs = http_build_query(['prodi' => $fp, 'status' => $fs, 'csv' => 1]);
$aksi = '<button class="btn" onclick="window.print()">' . ikon('print', 15) . ' Cetak</button> <a class="btn hijau" href="?' . e($qs) . '">' . ikon('download', 15) . ' Unduh CSV</a>';
require __DIR__ . '/includes/header.php';
?>
<div class="card">
  <form class="filters noprint" method="get">
    <select name="prodi"><option value="0">Semua Prodi</option>
      <?php foreach ($prodis as $d): ?><option value="<?= $d['id'] ?>" <?= $fp == $d['id'] ? 'selected' : '' ?>><?= e($d['nama']) ?></option><?php endforeach; ?></select>
    <select name="status"><option value="">Semua Status</option><?php foreach ($STATUS as $st): ?><option <?= $fs === $st ? 'selected' : '' ?>><?= e($st) ?></option><?php endforeach; ?></select>
    <button class="btn">Tampilkan</button>
  </form>
  <div class="wrap"><table class="tb">
    <tr><th>No</th><th>NPM</th><th>Nama</th><th>Prodi</th><th>Judul</th><th>Pembimbing</th><th>Status</th><th>Tgl Pengajuan</th></tr>
    <?php foreach ($rows as $i => $r): ?>
      <tr><td><?= $i + 1 ?></td><td><?= e($r['npm']) ?></td><td><?= e($r['mhs_nama']) ?></td><td><?= e($r['prodi'] ?: '-') ?></td>
        <td><?= e($r['judul']) ?></td><td><?= e($r['dosen_nama'] ?: '-') ?></td><td><?= e($r['status']) ?></td><td><?= e(tgl($r['tgl_pengajuan'])) ?></td></tr>
    <?php endforeach; if (!$rows): ?><tr><td colspan="8" class="kosong">Tidak ada data.</td></tr><?php endif; ?>
  </table></div>
  <p class="mut">Total: <?= count($rows) ?> proposal</p>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
