<?php
require_once __DIR__ . '/includes/auth.php';
wajib();
$u = user();
$j = $_GET['j'] ?? '';
if (!in_array($j, ['Seminar', 'Sidang'], true)) $j = '';
$aktif = $j === 'Seminar' ? 'seminar' : ($j === 'Sidang' ? 'sidang' : 'jadwal');
$boleh = staff() || $u['role'] === 'dosen';
list($w, $pr) = scope_proposal('p');
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $boleh) {
    csrf_cek();
    try {
        if (($_POST['aksi'] ?? '') === 'hapus') {
            $s = $pdo->prepare("SELECT proposal_id FROM jadwal WHERE id=?"); $s->execute([(int)$_POST['id']]);
            if ($pid = $s->fetchColumn()) { proposal_akses($pdo, $pid); $pdo->prepare("DELETE FROM jadwal WHERE id=?")->execute([(int)$_POST['id']]); }
            flash('Jadwal dihapus.');
        } else {
            $id = (int)($_POST['id'] ?? 0);
            $p = proposal_akses($pdo, (int)($_POST['proposal_id'] ?? 0));
            $jn = $_POST['jenis'] ?? '';
            if (!in_array($jn, ['Seminar', 'Sidang'], true)) throw new Exception('Jenis jadwal tidak valid.');
            $tg = $_POST['tanggal'] ?? '';
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tg) || !strtotime($tg)) throw new Exception('Tanggal tidak valid.');
            $jam = preg_match('/^\d{2}:\d{2}$/', $_POST['jam'] ?? '') ? $_POST['jam'] . ':00' : null;
            $rg = trim($_POST['ruang'] ?? ''); $ct = trim($_POST['catatan'] ?? '');
            if ($id) {
                $pdo->prepare("UPDATE jadwal SET proposal_id=?,jenis=?,tanggal=?,jam=?,ruang=?,catatan=? WHERE id=?")->execute([$p['id'], $jn, $tg, $jam, $rg, $ct, $id]);
            } else {
                $pdo->prepare("INSERT INTO jadwal (proposal_id,jenis,tanggal,jam,ruang,catatan) VALUES (?,?,?,?,?,?)")->execute([$p['id'], $jn, $tg, $jam, $rg, $ct]);
                aktivitas($pdo, 'Jadwal ' . strtolower($jn) . ' ' . $p['mhs_nama'] . ' ditambahkan', 'jadwal', $p['id']);
            }
            flash('Jadwal disimpan.');
        }
        redirect('jadwal.php' . ($j ? '?j=' . $j : ''));
    } catch (Exception $ex) { $err = $ex->getMessage(); }
}

$wh = $w; $par = $pr;
if ($j) { $wh .= " AND j.jenis=?"; $par[] = $j; }
$sr = $pdo->prepare("SELECT j.*, p.judul, m.nama mhs_nama, m.username npm FROM jadwal j JOIN proposal p ON p.id=j.proposal_id JOIN users m ON m.id=p.mahasiswa_id WHERE $wh ORDER BY j.tanggal DESC, j.jam DESC");
$sr->execute($par);
$rows = $sr->fetchAll();
$edit = ['id' => 0, 'proposal_id' => '', 'jenis' => $j ?: 'Seminar', 'tanggal' => date('Y-m-d'), 'jam' => '09:00:00', 'ruang' => '', 'catatan' => ''];
if ($boleh && isset($_GET['edit'])) foreach ($rows as $r) if ($r['id'] == (int)$_GET['edit']) $edit = $r;
if ($boleh) {
    $sp = $pdo->prepare("SELECT p.id, p.judul, m.nama, m.username FROM proposal p JOIN users m ON m.id=p.mahasiswa_id WHERE $w ORDER BY m.nama");
    $sp->execute($pr);
    $plist = $sp->fetchAll();
}
$judul = $j ? 'Jadwal ' . $j : 'Jadwal Seminar & Sidang';
$crumbs = crumb([['Dashboard', 'dashboard.php'], [$judul]]);
require __DIR__ . '/includes/header.php';
?>
<?php if ($boleh): ?>
<div class="card noprint">
  <h3><?= $edit['id'] ? 'Edit Jadwal' : 'Tambah Jadwal' ?></h3>
  <?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $edit['id'] ?>">
    <div class="fgrid">
      <div class="fg"><label>Proposal / Mahasiswa</label><select name="proposal_id" required><option value="">- pilih -</option>
        <?php foreach ($plist as $d): ?><option value="<?= $d['id'] ?>" <?= $edit['proposal_id'] == $d['id'] ? 'selected' : '' ?>><?= e($d['username'] . ' - ' . $d['nama'] . ' - ' . trunc($d['judul'], 30)) ?></option><?php endforeach; ?></select></div>
      <div class="fg"><label>Jenis</label><select name="jenis"><?php foreach (['Seminar', 'Sidang'] as $x): ?><option <?= $edit['jenis'] === $x ? 'selected' : '' ?>><?= $x ?></option><?php endforeach; ?></select></div>
      <div class="fg"><label>Tanggal</label><input type="date" name="tanggal" value="<?= e($edit['tanggal']) ?>" required></div>
      <div class="fg"><label>Jam</label><input type="time" name="jam" value="<?= e(substr((string)$edit['jam'], 0, 5)) ?>"></div>
      <div class="fg"><label>Ruang</label><input name="ruang" value="<?= e($edit['ruang']) ?>"></div>
      <div class="fg"><label>Catatan</label><input name="catatan" value="<?= e($edit['catatan']) ?>"></div>
    </div>
    <button class="btn">Simpan</button> <?php if ($edit['id']): ?><a class="btn abu" href="?<?= $j ? 'j=' . $j : '' ?>">Batal</a><?php endif; ?>
  </form>
</div>
<?php endif; ?>
<div class="card">
  <div class="wrap"><table class="tb">
    <tr><th>Tanggal</th><th>Jam</th><th>Jenis</th><th>Mahasiswa</th><th>Judul</th><th>Ruang</th><th>Catatan</th><?php if ($boleh): ?><th class="noprint">Aksi</th><?php endif; ?></tr>
    <?php foreach ($rows as $r): ?>
      <tr><td><?= e(tgl($r['tanggal'])) ?></td><td><?= e(substr((string)$r['jam'], 0, 5) ?: '-') ?></td>
        <td><?= badge($r['jenis']) ?></td><td><?= e($r['mhs_nama']) ?><br><small class="mut"><?= e($r['npm']) ?></small></td>
        <td><a href="<?= BASE_URL ?>/proposal_detail.php?id=<?= $r['proposal_id'] ?>"><?= e(trunc($r['judul'], 38)) ?></a></td>
        <td><?= e($r['ruang'] ?: '-') ?></td><td><?= e($r['catatan'] ?: '-') ?></td>
        <?php if ($boleh): ?><td class="noprint"><div class="aksi">
          <a class="ib hijau" title="Edit" href="?<?= $j ? 'j=' . $j . '&' : '' ?>edit=<?= $r['id'] ?>"><?= ikon('edit', 15) ?></a>
          <form method="post" onsubmit="return confirm('Hapus jadwal ini?')" style="margin:0"><?= csrf_field() ?><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?= $r['id'] ?>">
            <button class="ib merah" title="Hapus"><?= ikon('trash', 15) ?></button></form></div></td><?php endif; ?></tr>
    <?php endforeach; if (!$rows): ?><tr><td colspan="8" class="kosong">Belum ada jadwal.</td></tr><?php endif; ?>
  </table></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
