<?php
require_once __DIR__ . '/includes/auth.php';
if (user()) redirect('dashboard.php');
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    $u = cek_login($pdo, trim($_POST['username'] ?? ''), $_POST['password'] ?? '');
    if ($u) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => $u['id'], 'username' => $u['username'], 'nama' => $u['nama'], 'role' => $u['role'], 'prodi_id' => $u['prodi_id']];
        if (!empty($_POST['ingat'])) {
            setcookie(session_name(), session_id(), [
                'expires' => time() + 60 * 60 * 24 * 30, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax',
                'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            ]);
        }
        redirect('dashboard.php');
    }
    usleep(400000);
    $err = 'Username atau password salah.';
}
$bg = file_exists(__DIR__ . '/assets/kampus.jpg')
    ? "linear-gradient(rgba(235,242,255,.80),rgba(235,242,255,.80)),url('" . BASE_URL . "/assets/kampus.jpg')"
    : 'linear-gradient(120deg,#eef4ff,#dbe8ff)';
?>
<!DOCTYPE html>
<html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login - SIMSKRIPSI UM Bengkulu</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/app.css">
</head><body>
<div class="lg" style="background-image:<?= $bg ?>">
  <div class="lg-card">
    <div class="lg-top"><?= logo(74) ?><h1>SIMSKRIPSI</h1><p>Universitas Muhammadiyah Bengkulu</p></div>
    <div class="lg-tabs">
      <button type="button" class="on" id="t1" onclick="tab(1)">Login</button>
      <button type="button" id="t2" onclick="tab(2)">Informasi</button>
    </div>

    <div id="p1">
      <?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
      <form method="post" autocomplete="off">
        <?= csrf_field() ?>
        <div class="inp"><?= ikon('user', 18) ?><input name="username" placeholder="Username / NPM / NIP" required autofocus value="<?= e($_POST['username'] ?? '') ?>"></div>
        <div class="inp"><?= ikon('lock', 18) ?><input type="password" name="password" id="pw" placeholder="Password" required>
          <button type="button" class="mata" onclick="var p=document.getElementById('pw');p.type=p.type==='password'?'text':'password'" aria-label="Tampilkan password"><?= ikon('eye', 18) ?></button></div>
        <button class="btn blok">Login</button>
        <div class="lg-row">
          <label><input type="checkbox" name="ingat" value="1"> Ingat saya</label>
          <a href="#" onclick="alert('Untuk reset password, hubungi admin program studi Anda.');return false">Lupa password?</a>
        </div>
      </form>
      <div class="kotak-info">
        <b>Untuk login gunakan akun:</b>
        <div><span>Mahasiswa</span>: NPM</div>
        <div><span>Dosen</span>: NIP</div>
        <div><span>Kaprodi</span>: Akun Dosen</div>
        <div><span>Admin</span>: Akun yang diberikan</div>
      </div>
    </div>

    <div id="p2" style="display:none">
      <p style="font-size:13.5px;color:#374151">SIMSKRIPSI adalah sistem informasi untuk mengelola proses skripsi: pengajuan proposal, bimbingan, seminar, sidang, hingga laporan. Akun dibuat oleh admin program studi. Jika belum memiliki akun atau lupa password, hubungi admin.</p>
    </div>
    <div class="lg-back"><a href="<?= BASE_URL ?>/index.php">&larr; Kembali ke Beranda</a></div>
  </div>
</div>
<script>
function tab(n){document.getElementById('p1').style.display=n==1?'':'none';document.getElementById('p2').style.display=n==2?'':'none';
document.getElementById('t1').className=n==1?'on':'';document.getElementById('t2').className=n==2?'on':'';}
</script>
</body></html>
