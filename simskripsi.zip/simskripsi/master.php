<?php
require_once __DIR__ . '/includes/auth.php';
wajib('admin', 'kaprodi');
$aktif = 'master';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    try {
        if (($_POST['aksi'] ?? '') === 'hapus') {
            $pdo->prepare("DELETE FROM prodi WHERE id=?")->execute([(int)$_POST['id']]);
            flash('Program studi dihapus.');
        } else {
            $id = (int)($_POST['id'] ?? 0);
            $kd = strtoupper(trim($_POST['kode'] ?? '')); $nm = trim($_POST['nama'] ?? '');
            if ($kd === '' || $nm === '' || strlen($kd) > 10) throw new Exception('Kode (maks. 10 karakter) dan nama wajib diisi.');
            if ($id) $pdo->prepare("UPDATE prodi SET kode=?, nama=? WHERE id=?")->execute([$kd, $nm, $id]);
            else $pdo->prepare("INSERT INTO prodi (kode,nama) VALUES (?,?)")->execute([$kd, $nm]);
            flash('Program studi disimpan.');
        }
        redirect('master.php');
    } catch (PDOException $e) { $err = $e->getCode() == '23000' ? 'Kode program studi sudah dipakai.' : 'Kesalahan database.';
    } catch (Exception $e) { $err = $e->getMessage(); }
}
$edit = ['id' => 0, 'kode' => '', 'nama' => ''];
if (isset($_GET['edit'])) { $s = $pdo->prepare("SELECT * FROM prodi WHERE id=?"); $s->execute([(int)$_GET['edit']]); if ($x = $s->fetch()) $edit = $x; }
$rows = $pdo->query("SELECT p.*, (SELECT COUNT(*) FROM users u WHERE u.prodi_id=p.id AND u.role='mahasiswa') jml FROM prodi p ORDER BY p.nama")->fetchAll();
$judul = 'Master Data';
$sub = 'Kelola program studi dan akun khusus.';
require __DIR__ . '/includes/header.php';
?>
<div class="card">
  <h3>Program Studi</h3>
  <?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $edit['id'] ?>">
    <div class="fgrid">
      <div class="fg"><label>Kode</label><input name="kode" maxlength="10" value="<?= e($edit['kode']) ?>" required></div>
      <div class="fg"><label>Nama Program Studi</label><input name="nama" value="<?= e($edit['nama']) ?>" required></div>
    </div>
    <button class="btn">Simpan</button> <?php if ($edit['id']): ?><a class="btn abu" href="master.php">Batal</a><?php endif; ?>
  </form>
</div>
<div class="card">
  <div class="wrap"><table class="tb">
    <tr><th>No</th><th>Kode</th><th>Program Studi</th><th>Jumlah Mahasiswa</th><th>Aksi</th></tr>
    <?php foreach ($rows as $i => $x): ?>
      <tr><td><?= $i + 1 ?></td><td><?= e($x['kode']) ?></td><td><?= e($x['nama']) ?></td><td><?= $x['jml'] ?></td>
        <td><div class="aksi"><a class="ib hijau" title="Edit" href="?edit=<?= $x['id'] ?>"><?= ikon('edit', 15) ?></a>
          <form method="post" onsubmit="return confirm('Hapus program studi ini?')" style="margin:0"><?= csrf_field() ?><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?= $x['id'] ?>">
            <button class="ib merah" title="Hapus"><?= ikon('trash', 15) ?></button></form></div></td></tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php if (user()['role'] === 'admin'): ?>
<div class="card"><h3>Akun Khusus</h3>
  <a class="btn outline" href="pengguna.php?r=kaprodi">Kelola Akun Kaprodi</a>
  <a class="btn outline" href="pengguna.php?r=admin">Kelola Akun Admin</a>
</div>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
