<?php
// Alamat dan akun layanan (web service) yang dipanggil oleh SIMSKRIPSI.
// Kalau folder web kamu beda nama, ubah bagian 'url' saja.
return [
    'mahasiswa' => [
        'url'      => 'http://localhost/simmahasiswa/api',
        'username' => 'svc_simskripsi',
        'password' => 'password',
    ],
    'dosen' => [
        'url'      => 'http://localhost/simdosen/api',
        'username' => 'pimpinan',
        'password' => 'password',
    ],
];
