<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/api_client.php';
wajib('mahasiswa', 'admin', 'kaprodi');
$u = user();
$aktif = 'proposal';
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$p = ['id' => 0, 'mahasiswa_id' => 0, 'pembimbing_id' => null, 'judul' => '', 'abstrak' => '', 'status' => 'Diajukan'];
if ($id) {
    $p = proposal_akses($pdo, $id);
    if (!bisa_edit($p)) { http_response_code(403); die('Proposal ini tidak dapat diedit pada status saat ini.'); }
} elseif ($u['role'] === 'mahasiswa') {
    $c = $pdo->prepare("SELECT id FROM proposal WHERE mahasiswa_id=? AND status<>'Ditolak' LIMIT 1");
    $c->execute([$u['id']]);
    if ($ada = $c->fetchColumn()) { flash('Anda sudah memiliki proposal aktif. Satu mahasiswa hanya dapat memiliki satu proposal.', 'err'); redirect('proposal_detail.php?id=' . $ada); }
}

// Daftar dosen pembimbing diambil dari SIMDOSEN lewat web service (hanya dosen berstatus Aktif)
if (staff()) dosen_sinkron_status($pdo); // samakan status aktif dosen dengan SIMDOSEN
$dosenApi = staff() ? dosen_aktif_api() : ['ok' => false, 'data' => [], 'err' => ''];
$curKode = ''; $curNama = ''; $curAda = false;
if (!empty($p['pembimbing_id'])) {
    $cq = $pdo->prepare("SELECT username,nama FROM users WHERE id=?"); $cq->execute([$p['pembimbing_id']]);
    if ($cr = $cq->fetch()) { $curKode = $cr['username']; $curNama = $cr['nama']; }
}
if ($dosenApi['ok']) foreach ($dosenApi['data'] as $dd) if ($dd['kode'] === $curKode) $curAda = true;

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    try {
        $jd = trim($_POST['judul'] ?? ''); $ab = trim($_POST['abstrak'] ?? '');
        if ($jd === '' || mb_strlen($jd) > 255) throw new Exception('Judul wajib diisi (maksimal 255 karakter).');
        $pemb = $p['pembimbing_id'] ?: null;
        if (staff() && $dosenApi['ok']) {
            $kode = trim($_POST['pembimbing_kode'] ?? '');
            if ($kode === '') $pemb = null;
            elseif ($kode !== '__tetap') $pemb = dosen_lokal_dari_kode($pdo, $kode, $dosenApi['data']);
        }
        if ($id) {
            if ($u['role'] === 'mahasiswa' && $p['status'] === 'Ditolak') { // ajukan ulang: cek status di SIMMAHASISWA
                $cekM = mhs_cek_npm($u['username']);
                if (!$cekM['ok']) throw new Exception($cekM['pesan']);
            }
            $status = $p['status'];
            if (staff() && in_array($_POST['status'] ?? '', $STATUS, true)) $status = $_POST['status'];
            if ($u['role'] === 'mahasiswa' && $p['status'] === 'Ditolak') $status = 'Diajukan'; // ajukan ulang
            $pdo->prepare("UPDATE proposal SET judul=?, abstrak=?, pembimbing_id=?, status=? WHERE id=?")->execute([$jd, $ab, $pemb, $status, $id]);
            if ($status !== $p['status']) {
                log_status($pdo, $id, $status, $u['id']);
                aktivitas($pdo, 'Status proposal ' . $p['mhs_nama'] . ' menjadi ' . $status, 'status', $id);
            }
            flash('Proposal diperbarui.');
            redirect('proposal_detail.php?id=' . $id);
        }
        $mid = $u['id'];
        if (staff()) {
            $mid = (int)($_POST['mahasiswa_id'] ?? 0);
            $cm = $pdo->prepare("SELECT nama FROM users WHERE id=? AND role='mahasiswa'"); $cm->execute([$mid]);
            if (!$cm->fetchColumn()) throw new Exception('Pilih mahasiswa.');
        }
        // Validasi ke SIMMAHASISWA lewat web service: NPM harus terdaftar dan berstatus Aktif
        $qn = $pdo->prepare("SELECT username FROM users WHERE id=?"); $qn->execute([$mid]);
        $cekM = mhs_cek_npm((string)$qn->fetchColumn());
        if (!$cekM['ok']) throw new Exception($cekM['pesan']);
        $pdo->prepare("INSERT INTO proposal (mahasiswa_id,pembimbing_id,judul,abstrak,status,tgl_pengajuan,created_at) VALUES (?,?,?,?, 'Diajukan', ?, ?)")
            ->execute([$mid, $pemb, $jd, $ab, date('Y-m-d'), sekarang()]);
        $nid = (int)$pdo->lastInsertId();
        log_status($pdo, $nid, 'Diajukan', $u['id']);
        $nm = $pdo->prepare("SELECT nama FROM users WHERE id=?"); $nm->execute([$mid]);
        aktivitas($pdo, $nm->fetchColumn() . ' mengajukan proposal', 'proposal', $nid);
        flash('Proposal berhasil diajukan.');
        redirect('proposal_detail.php?id=' . $nid);
    } catch (Exception $ex) { $err = $ex->getMessage(); }
}
$mhs = staff() && !$id ? $pdo->query("SELECT id,username,nama FROM users WHERE role='mahasiswa' AND aktif=1 ORDER BY nama")->fetchAll() : [];
$val = function ($k) use ($p) { return $_SERVER["REQUEST_METHOD"] === "POST" ? ($_POST[$k] ?? "") : ($p[$k] ?? ""); };

$judul = $id ? 'Edit Proposal' : 'Ajukan Proposal';
$crumbs = crumb([['Dashboard', 'dashboard.php'], ['Proposal', 'proposal.php'], [$judul]]);
require __DIR__ . '/includes/header.php';
?>
<div class="card" style="max-width:760px">
  <?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
  <?php if ($u['role'] === 'mahasiswa' && $id && $p['status'] === 'Ditolak'): ?>
    <div class="alert err">Proposal ini ditolak. Setelah Anda simpan, statusnya kembali menjadi Diajukan.</div>
  <?php endif; ?>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
    <?php if ($mhs): ?>
    <div class="fg"><label>Mahasiswa</label>
      <select name="mahasiswa_id" required><option value="">- pilih mahasiswa -</option>
        <?php foreach ($mhs as $m): ?><option value="<?= $m['id'] ?>" <?= $val('mahasiswa_id') == $m['id'] ? 'selected' : '' ?>><?= e($m['username'] . ' - ' . $m['nama']) ?></option><?php endforeach; ?>
      </select></div>
    <?php endif; ?>
    <div class="fg"><label>Judul Proposal</label><input name="judul" maxlength="255" required value="<?= e($val('judul')) ?>"></div>
    <div class="fg"><label>Abstrak / Ringkasan</label><textarea name="abstrak" rows="6"><?= e($val('abstrak')) ?></textarea></div>
    <?php if (staff()): ?>
    <div class="fg"><label>Dosen Pembimbing (data dari SIMDOSEN)</label>
      <?php if (!$dosenApi['ok']): ?>
        <div class="alert err">Daftar dosen dari SIMDOSEN tidak dapat dimuat: <?= e($dosenApi['err']) ?>. Dosen pembimbing tidak diubah.</div>
      <?php else: ?>
      <select name="pembimbing_kode"><option value="">- belum ditetapkan -</option>
        <?php if ($curNama && !$curAda): ?><option value="__tetap" selected><?= e($curNama) ?> (data lokal, tidak aktif di SIMDOSEN)</option><?php endif; ?>
        <?php foreach ($dosenApi['data'] as $d): ?><option value="<?= e($d['kode']) ?>" <?= $curKode === $d['kode'] ? 'selected' : '' ?>><?= e($d['nama']) ?></option><?php endforeach; ?>
      </select>
      <?php endif; ?></div>
    <?php if ($id): ?>
    <div class="fg"><label>Status</label>
      <select name="status"><?php foreach ($STATUS as $st): ?><option <?= $p['status'] === $st ? 'selected' : '' ?>><?= e($st) ?></option><?php endforeach; ?></select></div>
    <?php endif; endif; ?>
    <button class="btn">Simpan</button> <a class="btn abu" href="<?= BASE_URL ?>/proposal.php">Batal</a>
  </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
