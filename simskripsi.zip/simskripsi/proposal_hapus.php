<?php
require_once __DIR__ . '/includes/auth.php';
wajib();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('proposal.php');
csrf_cek();
$p = proposal_akses($pdo, (int)($_POST['id'] ?? 0));
if (!bisa_hapus($p)) { http_response_code(403); die('Anda tidak berhak menghapus proposal ini.'); }
// hapus file fisik lebih dulu
$f = $pdo->prepare("SELECT file_simpan FROM bimbingan WHERE proposal_id=? AND file_simpan IS NOT NULL");
$f->execute([$p['id']]);
foreach ($f->fetchAll() as $r) @unlink(__DIR__ . '/uploads/' . basename($r['file_simpan']));
$pdo->prepare("DELETE FROM proposal WHERE id=?")->execute([$p['id']]);
flash('Proposal dihapus.');
redirect('proposal.php');
