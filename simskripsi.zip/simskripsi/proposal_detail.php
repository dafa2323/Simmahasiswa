<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/api_client.php';
wajib();
$u = user();
$aktif = 'proposal';
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$p = proposal_akses($pdo, $id);
$tab = $_GET['tab'] ?? 'bimbingan';
if (!in_array($tab, ['bimbingan', 'revisi', 'dokumen', 'riwayat'], true)) $tab = 'bimbingan';
$JENIS = ['bimbingan' => ['Catatan Bimbingan', 'Tambah Catatan Bimbingan'], 'revisi' => ['Keterangan Revisi', 'Tambah Revisi'], 'dokumen' => ['Keterangan Dokumen', 'Unggah Dokumen']];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    $aksi_post = $_POST['aksi'] ?? '';
    $kembali = 'proposal_detail.php?id=' . $id;
    try {
        if ($aksi_post === 'tambah') {
            $jn = $_POST['jenis'] ?? '';
            if (!isset($JENIS[$jn])) throw new Exception('Jenis tidak valid.');
            $tg = $_POST['tanggal'] ?? '';
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tg) || !strtotime($tg)) throw new Exception('Tanggal tidak valid.');
            $ct = trim($_POST['catatan'] ?? '');
            $up = upload_simpan($_FILES['berkas'] ?? ['name' => '', 'error' => UPLOAD_ERR_NO_FILE]);
            if ($ct === '' && !$up) throw new Exception('Isi keterangan atau lampirkan file.');
            $pdo->prepare("INSERT INTO bimbingan (proposal_id,jenis,tanggal,catatan,file_asli,file_simpan,dibuat_oleh,created_at) VALUES (?,?,?,?,?,?,?,?)")
                ->execute([$id, $jn, $tg, $ct, $up[0] ?? null, $up[1] ?? null, $u['id'], sekarang()]);
            $kata = ['bimbingan' => 'menambahkan catatan bimbingan untuk', 'revisi' => 'mengunggah revisi untuk', 'dokumen' => 'mengunggah dokumen untuk'][$jn];
            aktivitas($pdo, $u['nama'] . ' ' . $kata . ' ' . $p['mhs_nama'], 'bimbingan', $id);
            flash('Data berhasil ditambahkan.');
            $kembali .= '&tab=' . $jn;
        } elseif ($aksi_post === 'hapus_item') {
            $s = $pdo->prepare("SELECT * FROM bimbingan WHERE id=? AND proposal_id=?");
            $s->execute([(int)($_POST['item'] ?? 0), $id]);
            $it = $s->fetch();
            if (!$it) throw new Exception('Data tidak ditemukan.');
            if (!staff() && (int)$it['dibuat_oleh'] !== (int)$u['id']) throw new Exception('Anda hanya dapat menghapus data buatan sendiri.');
            if ($it['file_simpan']) @unlink(__DIR__ . '/uploads/' . basename($it['file_simpan']));
            $pdo->prepare("DELETE FROM bimbingan WHERE id=?")->execute([$it['id']]);
            flash('Data dihapus.');
            $kembali .= '&tab=' . $it['jenis'];
        } elseif ($aksi_post === 'status') {
            if (!bisa_status($p)) throw new Exception('Anda tidak berhak mengubah status.');
            $st = $_POST['status'] ?? '';
            if (!in_array($st, $STATUS, true)) throw new Exception('Status tidak valid.');
            if ($st !== $p['status']) {
                $pdo->prepare("UPDATE proposal SET status=? WHERE id=?")->execute([$st, $id]);
                log_status($pdo, $id, $st, $u['id']);
                aktivitas($pdo, 'Status proposal ' . $p['mhs_nama'] . ' menjadi ' . $st, 'status', $id);
                flash('Status diubah menjadi ' . $st . '.');
            }
        } elseif ($aksi_post === 'pembimbing') {
            if (!staff()) throw new Exception('Hanya admin/kaprodi yang dapat menetapkan pembimbing.');
            $kode = trim($_POST['pembimbing_kode'] ?? '');
            if ($kode === '__tetap') { $d = $p['pembimbing_id'] ?: null; }
            elseif ($kode === '') { $d = null; }
            else {
                $da = dosen_aktif_api(); // hanya dosen berstatus Aktif di SIMDOSEN yang boleh dipilih
                if (!$da['ok']) throw new Exception('Daftar dosen dari SIMDOSEN tidak dapat dimuat: ' . $da['err']);
                $d = dosen_lokal_dari_kode($pdo, $kode, $da['data']);
            }
            $pdo->prepare("UPDATE proposal SET pembimbing_id=? WHERE id=?")->execute([$d, $id]);
            aktivitas($pdo, 'Dosen pembimbing ' . $p['mhs_nama'] . ' diperbarui', 'status', $id);
            flash('Dosen pembimbing disimpan.');
        }
    } catch (Exception $ex) { flash($ex->getMessage(), 'err'); }
    redirect($kembali);
}

// data tampilan
$lg = $pdo->prepare("SELECT l.*, x.nama oleh_nama FROM proposal_log l LEFT JOIN users x ON x.id=l.oleh WHERE l.proposal_id=? ORDER BY l.waktu, l.id");
$lg->execute([$id]);
$logs = $lg->fetchAll();
$tglLog = [];
foreach ($logs as $r) if (!isset($tglLog[$r['status']])) $tglLog[$r['status']] = $r['waktu'];
$items = [];
if ($tab !== 'riwayat') {
    $si = $pdo->prepare("SELECT b.*, x.nama oleh_nama FROM bimbingan b LEFT JOIN users x ON x.id=b.dibuat_oleh WHERE b.proposal_id=? AND b.jenis=? ORDER BY b.tanggal DESC, b.id DESC");
    $si->execute([$id, $tab]);
    $items = $si->fetchAll();
}
// Dosen: samakan status aktif dengan SIMDOSEN, lalu siapkan pilihan pembimbing dari SIMDOSEN
dosen_sinkron_status($pdo);
$dosenApi = staff() ? dosen_aktif_api() : ['ok' => false, 'data' => [], 'err' => ''];
$curKode = ''; $curNama = ''; $curAda = false; $curStatus = '';
if (!empty($p['pembimbing_id'])) {
    $cq = $pdo->prepare("SELECT username,nama FROM users WHERE id=?"); $cq->execute([$p['pembimbing_id']]);
    if ($cr = $cq->fetch()) {
        $curKode = $cr['username']; $curNama = $cr['nama'];
        $ph = dosen_status_peta();
        if ($ph['ok'] && isset($ph['peta'][$curKode]) && $ph['peta'][$curKode]['status'] !== 'Aktif') $curStatus = $ph['peta'][$curKode]['status'];
    }
}
if ($dosenApi['ok']) foreach ($dosenApi['data'] as $dd) if ($dd['kode'] === $curKode) $curAda = true;
$idx = array_search($p['status'], $ALUR, true);
$ditolak = $p['status'] === 'Ditolak';

$judul = 'Detail Proposal';
$crumbs = crumb([['Dashboard', 'dashboard.php'], ['Proposal', 'proposal.php'], ['Detail Proposal']]);
$aksi = '<a class="btn" href="' . BASE_URL . '/proposal.php">Kembali</a> '
      . (bisa_edit($p) ? '<a class="btn hijau" href="' . BASE_URL . '/proposal_form.php?id=' . $id . '">' . ikon('edit', 15) . ' Edit Data</a>' : '');
require __DIR__ . '/includes/header.php';
?>
<div class="two">
  <div class="card">
    <h3>Informasi Mahasiswa</h3>
    <table class="kv">
      <tr><td>Nama</td><td>: <?= e($p['mhs_nama']) ?></td></tr>
      <tr><td>NPM</td><td>: <?= e($p['npm']) ?></td></tr>
      <tr><td>Program Studi</td><td>: <?= e($p['prodi'] ?: '-') ?></td></tr>
      <tr><td>Judul Proposal</td><td>: <?= e($p['judul']) ?></td></tr>
      <tr><td>Dosen Pembimbing</td><td>: <?= e($p['dosen_nama'] ?: 'Belum ditetapkan') ?><?= $curStatus ? ' <small style="color:#b00">(status di SIMDOSEN: ' . e($curStatus) . ')</small>' : '' ?></td></tr>
      <tr><td>Tanggal Pengajuan</td><td>: <?= e(tgl_id($p['tgl_pengajuan'])) ?></td></tr>
      <?php if (trim((string)$p['abstrak']) !== ''): ?><tr><td>Abstrak</td><td>: <?= nl2br(e($p['abstrak'])) ?></td></tr><?php endif; ?>
    </table>
    <?php if (staff()): ?>
    <form method="post" style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap" class="noprint">
      <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="aksi" value="pembimbing">
      <?php if (!$dosenApi['ok']): ?>
        <div class="alert err" style="flex:1">Daftar dosen dari SIMDOSEN tidak dapat dimuat: <?= e($dosenApi['err']) ?>.</div>
      <?php else: ?>
      <select name="pembimbing_kode" style="flex:1;min-width:200px"><option value="">- belum ditetapkan -</option>
        <?php if ($curNama && !$curAda): ?><option value="__tetap" selected><?= e($curNama) ?> (tidak aktif di SIMDOSEN)</option><?php endif; ?>
        <?php foreach ($dosenApi['data'] as $dd): ?><option value="<?= e($dd['kode']) ?>" <?= $curKode === $dd['kode'] ? 'selected' : '' ?>><?= e($dd['nama']) ?></option><?php endforeach; ?>
      </select>
      <button class="btn kecil">Tetapkan Pembimbing</button>
      <?php endif; ?>
    </form>
    <?php endif; ?>
  </div>

  <div class="card">
    <h3>Status Proposal</h3>
    <ul class="tl">
    <?php foreach ($ALUR as $i => $st):
        if ($ditolak) $kls = $i === 0 ? 'done' : 'pend';
        else $kls = ($i < $idx || ($i === $idx && $st === 'Selesai')) ? 'done' : ($i === $idx ? 'cur' : 'pend'); ?>
      <li class="<?= $kls ?>"><span class="dot"><?= $kls === 'done' ? ikon('check', 14) : '' ?></span>
        <b><?= e($st) ?></b><?php if ($kls === 'cur'): ?><small>Sedang berjalan</small><?php endif; ?>
        <?php if (isset($tglLog[$st]) && $kls !== 'pend'): ?><span class="tg"><?= e(tgl($tglLog[$st])) ?></span><?php endif; ?></li>
    <?php endforeach; ?>
    <?php if ($ditolak): ?>
      <li class="tolak"><span class="dot"></span><b>Ditolak</b><?php if (isset($tglLog['Ditolak'])): ?><span class="tg"><?= e(tgl($tglLog['Ditolak'])) ?></span><?php endif; ?></li>
    <?php endif; ?>
    </ul>
    <?php if (bisa_status($p)): ?>
    <form method="post" style="display:flex;gap:8px;margin-top:16px" class="noprint">
      <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="aksi" value="status">
      <select name="status"><?php foreach ($STATUS as $st): ?><option <?= $p['status'] === $st ? 'selected' : '' ?>><?= e($st) ?></option><?php endforeach; ?></select>
      <button class="btn kecil">Ubah</button>
    </form>
    <?php endif; ?>
  </div>
</div>

<div class="card">
  <div class="tabs">
    <?php foreach (['bimbingan' => 'Bimbingan', 'revisi' => 'Revisi', 'dokumen' => 'Dokumen', 'riwayat' => 'Riwayat'] as $k => $lb): ?>
      <a class="<?= $tab === $k ? 'on' : '' ?>" href="?id=<?= $id ?>&tab=<?= $k ?>"><?= $lb ?></a>
    <?php endforeach; ?>
  </div>

  <?php if ($tab === 'riwayat'): ?>
    <div class="wrap"><table class="tb">
      <tr><th>No</th><th>Waktu</th><th>Status</th><th>Diubah oleh</th></tr>
      <?php foreach ($logs as $i => $r): ?>
        <tr><td><?= $i + 1 ?></td><td><?= e(tgl_id($r['waktu'], true)) ?></td><td><?= badge($r['status']) ?></td><td><?= e($r['oleh_nama'] ?: '-') ?></td></tr>
      <?php endforeach; ?>
    </table></div>
  <?php else: ?>
    <div class="wrap"><table class="tb">
      <tr><th>No</th><th>Tanggal</th><th><?= $JENIS[$tab][0] ?></th><th>File</th><th>Oleh</th><th>Aksi</th></tr>
      <?php foreach ($items as $i => $r): ?>
        <tr><td><?= $i + 1 ?></td><td><?= e(tgl($r['tanggal'])) ?></td><td><?= nl2br(e($r['catatan'])) ?></td>
          <td><?php if ($r['file_simpan']): ?><a class="file" href="<?= BASE_URL ?>/unduh.php?id=<?= $r['id'] ?>"><?= ikon('download', 14) ?> <?= e($r['file_asli']) ?></a><?php else: ?>-<?php endif; ?></td>
          <td><?= e($r['oleh_nama'] ?: '-') ?></td>
          <td><?php if (staff() || (int)$r['dibuat_oleh'] === (int)$u['id']): ?>
            <form method="post" onsubmit="return confirm('Hapus data ini?')" style="margin:0">
              <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="aksi" value="hapus_item"><input type="hidden" name="item" value="<?= $r['id'] ?>">
              <button class="ib merah" title="Hapus"><?= ikon('trash', 15) ?></button></form>
          <?php endif; ?></td></tr>
      <?php endforeach; if (!$items): ?><tr><td colspan="6" class="kosong">Belum ada data.</td></tr><?php endif; ?>
    </table></div>

    <details class="addbox noprint">
      <summary class="btn"><?= ikon('plus', 15) ?> <?= $JENIS[$tab][1] ?></summary>
      <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="aksi" value="tambah"><input type="hidden" name="jenis" value="<?= e($tab) ?>">
        <div class="fgrid">
          <div class="fg"><label>Tanggal</label><input type="date" name="tanggal" value="<?= date('Y-m-d') ?>" required></div>
          <div class="fg"><label>File (opsional: pdf, doc, docx, jpg, png, zip - maks 5 MB)</label><input type="file" name="berkas"></div>
        </div>
        <div class="fg"><label><?= $JENIS[$tab][0] ?></label><textarea name="catatan" rows="3"></textarea></div>
        <button class="btn">Simpan</button>
      </form>
    </details>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
