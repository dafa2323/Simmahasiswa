<?php
require_once 'auth_check.php';
require_once 'koneksi.php';

wajib_role(['ADMIN']);

$q = trim($_GET['q'] ?? '');

$sql = "SELECT p.id_pengguna, p.username, p.nama_lengkap, p.email, p.status_aktif, p.last_login,
               r.nama_role, f.nama_fakultas, ps.nama_program_studi
        FROM pengguna p
        INNER JOIN roles r ON p.id_role = r.id_role
        LEFT JOIN fakultas f ON p.id_fakultas = f.id_fakultas
        LEFT JOIN program_studi ps ON p.id_program_studi = ps.id_program_studi
        WHERE 1=1";
$types = '';
$params = [];

if ($q !== '') {
    $sql .= " AND (p.username LIKE ? OR p.nama_lengkap LIKE ?)";
    $types = 'ss';
    $like = '%' . $q . '%';
    $params = [$like, $like];
}
$sql .= " ORDER BY r.id_role ASC, p.nama_lengkap ASC";

$stmt = mysqli_prepare($koneksi, $sql);
if ($types !== '') {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$idSaya = (int) $_SESSION['id_pengguna'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengguna - SIM Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="app-body">

<?php include 'topbar.php'; ?>
<?php include 'sideleftbar.php'; ?>

<main class="main-content">
    <div class="page-heading page-heading-flex">
        <div>
            <span class="eyebrow">MASTER DATA</span>
            <h1>Pengguna</h1>
            <p>Kelola akun pengguna dan hak aksesnya.</p>
        </div>
        <a href="pengguna_form.php" class="btn btn-primary">+ Tambah Pengguna</a>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_SESSION['success']) ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']) ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <div class="dashboard-panel">
        <form method="get" class="search-form">
            <input type="text" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Cari username atau nama...">
            <button type="submit" class="btn btn-primary btn-sm">Cari</button>
            <?php if ($q !== ''): ?>
                <a href="pengguna.php" class="btn btn-outline btn-sm">Reset</a>
            <?php endif; ?>
        </form>

        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th width="60">No.</th>
                        <th>Username</th>
                        <th>Nama Lengkap</th>
                        <th>Role</th>
                        <th>Lingkup</th>
                        <th width="100">Status</th>
                        <th width="150">Login Terakhir</th>
                        <th width="150">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php $no = 1; while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><strong><?= htmlspecialchars($row['username']) ?></strong></td>
                            <td><?= htmlspecialchars($row['nama_lengkap']) ?></td>
                            <td><span class="badge"><?= htmlspecialchars($row['nama_role']) ?></span></td>
                            <td><?= htmlspecialchars($row['nama_program_studi'] ?? $row['nama_fakultas'] ?? 'Universitas') ?></td>
                            <td>
                                <span class="badge <?= $row['status_aktif'] === 'Aktif' ? '' : 'badge-off' ?>">
                                    <?= htmlspecialchars($row['status_aktif']) ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars($row['last_login'] ?? '-') ?></td>
                            <td>
                                <div class="action-group">
                                    <a class="btn btn-sm btn-outline" href="pengguna_form.php?id=<?= (int) $row['id_pengguna'] ?>">Edit</a>
                                    <?php if ((int) $row['id_pengguna'] !== $idSaya): ?>
                                        <form action="pengguna_hapus.php" method="post" onsubmit="return confirm('Hapus pengguna ini?');">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="id_pengguna" value="<?= (int) $row['id_pengguna'] ?>">
                                            <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="8" class="empty-state">Belum ada data pengguna.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<script>
function toggleSidebar() { document.getElementById('sidebar').classList.toggle('show'); }
</script>
</body>
</html>
<?php mysqli_stmt_close($stmt); ?>
