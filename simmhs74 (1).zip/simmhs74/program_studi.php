<?php
require_once 'auth_check.php';
require_once 'koneksi.php';

wajib_role(['ADMIN']);

$result = mysqli_query(
    $koneksi,
    "SELECT ps.id_program_studi, ps.kode_program_studi, ps.nama_program_studi,
            ps.jenjang, ps.status_aktif, f.nama_fakultas,
            (SELECT COUNT(*) FROM mahasiswa m WHERE m.id_program_studi = ps.id_program_studi) AS jml_mhs
     FROM program_studi ps
     INNER JOIN fakultas f ON ps.id_fakultas = f.id_fakultas
     ORDER BY f.nama_fakultas ASC, ps.nama_program_studi ASC"
);
if (!$result) {
    die('Gagal mengambil data program studi: ' . htmlspecialchars(mysqli_error($koneksi)));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Program Studi - SIM Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="app-body">

<?php include 'topbar.php'; ?>
<?php include 'sideleftbar.php'; ?>

<main class="main-content">
    <div class="page-heading page-heading-flex">
        <div>
            <span class="eyebrow">MASTER DATA</span>
            <h1>Program Studi</h1>
            <p>Kelola data program studi pada setiap fakultas.</p>
        </div>
        <a href="program_studi_form.php" class="btn btn-primary">+ Tambah Program Studi</a>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_SESSION['success']) ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']) ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <div class="dashboard-panel">
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th width="60">No.</th>
                        <th width="110">Kode</th>
                        <th>Program Studi</th>
                        <th>Fakultas</th>
                        <th width="80">Jenjang</th>
                        <th width="110">Mahasiswa</th>
                        <th width="110">Status</th>
                        <th width="150">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php $no = 1; while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><span class="badge"><?= htmlspecialchars($row['kode_program_studi']) ?></span></td>
                            <td><strong><?= htmlspecialchars($row['nama_program_studi']) ?></strong></td>
                            <td><?= htmlspecialchars($row['nama_fakultas']) ?></td>
                            <td><?= htmlspecialchars($row['jenjang']) ?></td>
                            <td><?= (int) $row['jml_mhs'] ?></td>
                            <td>
                                <span class="badge <?= $row['status_aktif'] === 'Aktif' ? '' : 'badge-off' ?>">
                                    <?= htmlspecialchars($row['status_aktif']) ?>
                                </span>
                            </td>
                            <td>
                                <div class="action-group">
                                    <a class="btn btn-sm btn-outline" href="program_studi_form.php?id=<?= (int) $row['id_program_studi'] ?>">Edit</a>
                                    <form action="program_studi_hapus.php" method="post" onsubmit="return confirm('Hapus program studi ini?');">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="id_program_studi" value="<?= (int) $row['id_program_studi'] ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="8" class="empty-state">Belum ada data program studi.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<script>
function toggleSidebar() { document.getElementById('sidebar').classList.toggle('show'); }
</script>
</body>
</html>
