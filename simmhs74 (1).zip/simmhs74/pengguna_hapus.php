<?php
require_once 'auth_check.php';
require_once 'koneksi.php';
require_once 'audit.php';

wajib_role(['ADMIN']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: pengguna.php');
    exit;
}
csrf_verify();

$id = filter_input(INPUT_POST, 'id_pengguna', FILTER_VALIDATE_INT);
if (!$id) {
    $_SESSION['error'] = 'ID pengguna tidak valid.';
    header('Location: pengguna.php');
    exit;
}

if ($id === (int) $_SESSION['id_pengguna']) {
    $_SESSION['error'] = 'Anda tidak dapat menghapus akun Anda sendiri.';
    header('Location: pengguna.php');
    exit;
}

$stmt = mysqli_prepare($koneksi, "SELECT username, nama_lengkap, id_role FROM pengguna WHERE id_pengguna = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$user) {
    $_SESSION['error'] = 'Pengguna tidak ditemukan.';
    header('Location: pengguna.php');
    exit;
}

/* Akun yang terhubung ke data mahasiswa tidak boleh dihapus */
$stmt = mysqli_prepare($koneksi, "SELECT COUNT(*) AS total FROM mahasiswa WHERE id_pengguna = ?");
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if ((int) $row['total'] > 0) {
    $_SESSION['error'] = 'Pengguna tidak dapat dihapus karena terhubung dengan data mahasiswa. Nonaktifkan saja akunnya.';
    header('Location: pengguna.php');
    exit;
}

try {
    $stmt = mysqli_prepare($koneksi, "DELETE FROM pengguna WHERE id_pengguna = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    catat_audit($koneksi, 'pengguna', $id, 'DELETE', $user, null);
    $_SESSION['success'] = 'Pengguna berhasil dihapus.';
} catch (Throwable $e) {
    $_SESSION['error'] = 'Gagal menghapus pengguna. Coba nonaktifkan akunnya.';
}

header('Location: pengguna.php');
exit;
