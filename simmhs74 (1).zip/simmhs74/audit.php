<?php
/**
 * audit.php
 * Helper pencatatan audit log. Kegagalan mencatat tidak boleh menggagalkan proses utama.
 */
function catat_audit($koneksi, string $tabel, $recordId, string $aksi, ?array $lama = null, ?array $baru = null): void
{
    try {
        $idPengguna = isset($_SESSION['id_pengguna']) ? (int) $_SESSION['id_pengguna'] : null;
        $rid   = $recordId === null ? null : (string) $recordId;
        $jLama = $lama === null ? null : json_encode($lama, JSON_UNESCAPED_UNICODE);
        $jBaru = $baru === null ? null : json_encode($baru, JSON_UNESCAPED_UNICODE);
        $ip    = $_SERVER['REMOTE_ADDR'] ?? null;
        $agent = $_SERVER['HTTP_USER_AGENT'] ?? null;

        $stmt = mysqli_prepare(
            $koneksi,
            "INSERT INTO audit_log (id_pengguna, tabel_nama, record_id, aksi, data_lama, data_baru, ip_address, user_agent)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'isssssss', $idPengguna, $tabel, $rid, $aksi, $jLama, $jBaru, $ip, $agent);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
    } catch (Throwable $e) {
        /* diabaikan */
    }
}
