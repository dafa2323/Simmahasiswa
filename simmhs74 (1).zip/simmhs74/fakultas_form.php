<?php
require_once 'auth_check.php';
require_once 'koneksi.php';
require_once 'audit.php';

wajib_role(['ADMIN']);

$id     = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$isEdit = $id > 0;
$data   = ['kode_fakultas' => '', 'nama_fakultas' => ''];

if ($isEdit) {
    $stmt = mysqli_prepare($koneksi, "SELECT kode_fakultas, nama_fakultas FROM fakultas WHERE id_fakultas = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $lama = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if (!$lama) {
        $_SESSION['error'] = 'Fakultas tidak ditemukan.';
        header('Location: fakultas.php');
        exit;
    }
    $data = $lama;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $data['kode_fakultas'] = strtoupper(trim($_POST['kode_fakultas'] ?? ''));
    $data['nama_fakultas'] = trim($_POST['nama_fakultas'] ?? '');

    if ($data['kode_fakultas'] === '' || $data['nama_fakultas'] === '') {
        $error = 'Kode dan nama fakultas wajib diisi.';
    } elseif (!preg_match('/^[A-Z0-9_]+$/', $data['kode_fakultas'])) {
        $error = 'Kode hanya boleh berisi huruf kapital, angka, dan underscore.';
    } else {
        $stmt = mysqli_prepare($koneksi, "SELECT id_fakultas FROM fakultas WHERE kode_fakultas = ? AND id_fakultas <> ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, 'si', $data['kode_fakultas'], $id);
        mysqli_stmt_execute($stmt);
        $ada = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        mysqli_stmt_close($stmt);
        if ($ada) {
            $error = 'Kode fakultas sudah digunakan.';
        }
    }

    if ($error === '') {
        try {
            if ($isEdit) {
                $stmt = mysqli_prepare($koneksi, "UPDATE fakultas SET kode_fakultas = ?, nama_fakultas = ? WHERE id_fakultas = ?");
                mysqli_stmt_bind_param($stmt, 'ssi', $data['kode_fakultas'], $data['nama_fakultas'], $id);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
                catat_audit($koneksi, 'fakultas', $id, 'UPDATE', $lama, $data);
                $_SESSION['success'] = 'Fakultas berhasil diperbarui.';
            } else {
                $res = mysqli_query($koneksi, "SELECT id_universitas FROM universitas ORDER BY id_universitas ASC LIMIT 1");
                $uni = $res ? mysqli_fetch_assoc($res) : null;
                if (!$uni) {
                    throw new Exception('Data universitas belum ada.');
                }
                $idUni = (int) $uni['id_universitas'];

                $stmt = mysqli_prepare($koneksi, "INSERT INTO fakultas (id_universitas, kode_fakultas, nama_fakultas) VALUES (?, ?, ?)");
                mysqli_stmt_bind_param($stmt, 'iss', $idUni, $data['kode_fakultas'], $data['nama_fakultas']);
                mysqli_stmt_execute($stmt);
                $newId = mysqli_insert_id($koneksi);
                mysqli_stmt_close($stmt);
                catat_audit($koneksi, 'fakultas', $newId, 'INSERT', null, $data);
                $_SESSION['success'] = 'Fakultas berhasil ditambahkan.';
            }
            header('Location: fakultas.php');
            exit;
        } catch (Throwable $e) {
            $error = 'Gagal menyimpan data fakultas.';
        }
    }
}

$judul = $isEdit ? 'Edit Fakultas' : 'Tambah Fakultas';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $judul ?> - SIM Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="app-body">

<?php include 'topbar.php'; ?>
<?php include 'sideleftbar.php'; ?>

<main class="main-content">
    <div class="page-heading">
        <span class="eyebrow">MASTER DATA</span>
        <h1><?= $judul ?></h1>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="dashboard-panel form-panel">
        <form method="post">
            <?= csrf_field() ?>
            <div class="form-group">
                <label for="kode_fakultas">Kode Fakultas</label>
                <input type="text" id="kode_fakultas" name="kode_fakultas" maxlength="20" required value="<?= htmlspecialchars($data['kode_fakultas']) ?>" placeholder="Contoh: FT">
                <small class="form-help">Huruf kapital, angka, dan underscore.</small>
            </div>
            <div class="form-group">
                <label for="nama_fakultas">Nama Fakultas</label>
                <input type="text" id="nama_fakultas" name="nama_fakultas" maxlength="200" required value="<?= htmlspecialchars($data['nama_fakultas']) ?>" placeholder="Contoh: Fakultas Teknik">
            </div>
            <div class="form-actions">
                <a href="fakultas.php" class="btn btn-outline">Batal</a>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</main>

<script>
function toggleSidebar() { document.getElementById('sidebar').classList.toggle('show'); }
</script>
</body>
</html>
