<?php
require_once 'auth_check.php';
require_once 'koneksi.php';
require_once 'audit.php';

wajib_role(['ADMIN']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: program_studi.php');
    exit;
}
csrf_verify();

$id = filter_input(INPUT_POST, 'id_program_studi', FILTER_VALIDATE_INT);
if (!$id) {
    $_SESSION['error'] = 'ID program studi tidak valid.';
    header('Location: program_studi.php');
    exit;
}

$stmt = mysqli_prepare($koneksi, "SELECT kode_program_studi, nama_program_studi FROM program_studi WHERE id_program_studi = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$ps = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$ps) {
    $_SESSION['error'] = 'Program studi tidak ditemukan.';
    header('Location: program_studi.php');
    exit;
}

$cek = [
    'mahasiswa' => "SELECT COUNT(*) AS total FROM mahasiswa WHERE id_program_studi = ?",
    'pengguna'  => "SELECT COUNT(*) AS total FROM pengguna WHERE id_program_studi = ?",
];
foreach ($cek as $label => $sql) {
    $stmt = mysqli_prepare($koneksi, $sql);
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
    if ((int) $row['total'] > 0) {
        $_SESSION['error'] = 'Program studi tidak dapat dihapus karena masih digunakan oleh ' . $label . '.';
        header('Location: program_studi.php');
        exit;
    }
}

try {
    $stmt = mysqli_prepare($koneksi, "DELETE FROM program_studi WHERE id_program_studi = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    catat_audit($koneksi, 'program_studi', $id, 'DELETE', $ps, null);
    $_SESSION['success'] = 'Program studi berhasil dihapus.';
} catch (Throwable $e) {
    $_SESSION['error'] = 'Gagal menghapus program studi.';
}

header('Location: program_studi.php');
exit;
