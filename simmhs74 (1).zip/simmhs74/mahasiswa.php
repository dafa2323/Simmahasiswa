<?php
require_once 'auth_check.php';
require_once 'koneksi.php';

wajib_role(['ADMIN', 'OPERATOR_PRODI']);

$role   = $_SESSION['kode_role'];
$idProdi = (int) ($_SESSION['id_program_studi'] ?? 0);
$q      = trim($_GET['q'] ?? '');

$sql = "SELECT m.id_mahasiswa, m.npm, m.nama_mahasiswa, m.jenis_kelamin,
               m.tanggal_masuk, m.status_mahasiswa,
               ps.nama_program_studi
        FROM mahasiswa m
        INNER JOIN program_studi ps ON m.id_program_studi = ps.id_program_studi
        WHERE 1=1";
$types  = '';
$params = [];

/* Operator Prodi hanya boleh melihat mahasiswa prodinya sendiri */
if ($role === 'OPERATOR_PRODI') {
    $sql .= " AND m.id_program_studi = ?";
    $types .= 'i';
    $params[] = $idProdi;
}

if ($q !== '') {
    $sql .= " AND (m.npm LIKE ? OR m.nama_mahasiswa LIKE ?)";
    $types .= 'ss';
    $like = '%' . $q . '%';
    $params[] = $like;
    $params[] = $like;
}

$sql .= " ORDER BY m.npm ASC";

$stmt = mysqli_prepare($koneksi, $sql);
if (!$stmt) {
    die('Gagal menyiapkan query: ' . htmlspecialchars(mysqli_error($koneksi)));
}
if ($types !== '') {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Mahasiswa - SIM Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="app-body">

<?php include 'topbar.php'; ?>
<?php include 'sideleftbar.php'; ?>

<main class="main-content">
    <div class="page-heading page-heading-flex">
        <div>
            <span class="eyebrow">DATA AKADEMIK</span>
            <h1>Data Mahasiswa</h1>
            <p>Kelola data mahasiswa sesuai kewenangan role Anda.</p>
        </div>
        <a href="mahasiswa_form.php" class="btn btn-primary">+ Tambah Mahasiswa</a>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_SESSION['success']) ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']) ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <div class="dashboard-panel">
        <form method="get" class="search-form">
            <input type="text" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Cari NPM atau nama...">
            <button type="submit" class="btn btn-primary btn-sm">Cari</button>
            <?php if ($q !== ''): ?>
                <a href="mahasiswa.php" class="btn btn-outline btn-sm">Reset</a>
            <?php endif; ?>
        </form>

        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th width="60">No.</th>
                        <th width="130">NPM</th>
                        <th>Nama</th>
                        <th width="50">L/P</th>
                        <th>Program Studi</th>
                        <th width="120">Tgl. Masuk</th>
                        <th width="130">Status</th>
                        <th width="150">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php $no = 1; ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><span class="badge"><?= htmlspecialchars($row['npm']) ?></span></td>
                            <td><strong><?= htmlspecialchars($row['nama_mahasiswa']) ?></strong></td>
                            <td><?= htmlspecialchars($row['jenis_kelamin']) ?></td>
                            <td><?= htmlspecialchars($row['nama_program_studi']) ?></td>
                            <td><?= htmlspecialchars($row['tanggal_masuk']) ?></td>
                            <td><?= htmlspecialchars($row['status_mahasiswa']) ?></td>
                            <td>
                                <div class="action-group">
                                    <a class="btn btn-sm btn-outline" href="mahasiswa_form.php?id=<?= (int) $row['id_mahasiswa'] ?>">Edit</a>

                                    <form action="mahasiswa_hapus.php" method="post" onsubmit="return confirm('Hapus data mahasiswa ini?');">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="id_mahasiswa" value="<?= (int) $row['id_mahasiswa'] ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="empty-state">Belum ada data mahasiswa.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('show');
}
</script>
</body>
</html>
<?php mysqli_stmt_close($stmt); ?>
