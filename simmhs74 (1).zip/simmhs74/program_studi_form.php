<?php
require_once 'auth_check.php';
require_once 'koneksi.php';
require_once 'audit.php';

wajib_role(['ADMIN']);

$id     = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$isEdit = $id > 0;

$jenjangList = ['D3', 'D4', 'S1', 'S2', 'S3', 'Profesi'];

$fakList = mysqli_fetch_all(
    mysqli_query($koneksi, "SELECT id_fakultas, nama_fakultas FROM fakultas ORDER BY nama_fakultas"),
    MYSQLI_ASSOC
);

$data = [
    'id_fakultas' => '', 'kode_program_studi' => '', 'nama_program_studi' => '',
    'jenjang' => 'S1', 'status_aktif' => 'Aktif',
];

if ($isEdit) {
    $stmt = mysqli_prepare($koneksi, "SELECT id_fakultas, kode_program_studi, nama_program_studi, jenjang, status_aktif FROM program_studi WHERE id_program_studi = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $lama = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if (!$lama) {
        $_SESSION['error'] = 'Program studi tidak ditemukan.';
        header('Location: program_studi.php');
        exit;
    }
    $data = $lama;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $data['id_fakultas']        = (int) ($_POST['id_fakultas'] ?? 0);
    $data['kode_program_studi'] = strtoupper(trim($_POST['kode_program_studi'] ?? ''));
    $data['nama_program_studi'] = trim($_POST['nama_program_studi'] ?? '');
    $data['jenjang']            = $_POST['jenjang'] ?? '';
    $data['status_aktif']       = $_POST['status_aktif'] ?? '';

    $fakValid = false;
    foreach ($fakList as $f) {
        if ((int) $f['id_fakultas'] === $data['id_fakultas']) {
            $fakValid = true;
        }
    }

    if ($data['kode_program_studi'] === '' || $data['nama_program_studi'] === '') {
        $error = 'Kode dan nama program studi wajib diisi.';
    } elseif (!preg_match('/^[A-Z0-9_]+$/', $data['kode_program_studi'])) {
        $error = 'Kode hanya boleh berisi huruf kapital, angka, dan underscore.';
    } elseif (!$fakValid) {
        $error = 'Fakultas tidak valid.';
    } elseif (!in_array($data['jenjang'], $jenjangList, true)) {
        $error = 'Jenjang tidak valid.';
    } elseif (!in_array($data['status_aktif'], ['Aktif', 'Tidak Aktif'], true)) {
        $error = 'Status tidak valid.';
    } else {
        $stmt = mysqli_prepare($koneksi, "SELECT id_program_studi FROM program_studi WHERE kode_program_studi = ? AND id_program_studi <> ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, 'si', $data['kode_program_studi'], $id);
        mysqli_stmt_execute($stmt);
        $ada = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        mysqli_stmt_close($stmt);
        if ($ada) {
            $error = 'Kode program studi sudah digunakan.';
        }
    }

    if ($error === '') {
        try {
            if ($isEdit) {
                $stmt = mysqli_prepare($koneksi, "UPDATE program_studi SET id_fakultas = ?, kode_program_studi = ?, nama_program_studi = ?, jenjang = ?, status_aktif = ? WHERE id_program_studi = ?");
                mysqli_stmt_bind_param($stmt, 'issssi', $data['id_fakultas'], $data['kode_program_studi'], $data['nama_program_studi'], $data['jenjang'], $data['status_aktif'], $id);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
                catat_audit($koneksi, 'program_studi', $id, 'UPDATE', $lama, $data);
                $_SESSION['success'] = 'Program studi berhasil diperbarui.';
            } else {
                $stmt = mysqli_prepare($koneksi, "INSERT INTO program_studi (id_fakultas, kode_program_studi, nama_program_studi, jenjang, status_aktif) VALUES (?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt, 'issss', $data['id_fakultas'], $data['kode_program_studi'], $data['nama_program_studi'], $data['jenjang'], $data['status_aktif']);
                mysqli_stmt_execute($stmt);
                $newId = mysqli_insert_id($koneksi);
                mysqli_stmt_close($stmt);
                catat_audit($koneksi, 'program_studi', $newId, 'INSERT', null, $data);
                $_SESSION['success'] = 'Program studi berhasil ditambahkan.';
            }
            header('Location: program_studi.php');
            exit;
        } catch (Throwable $e) {
            $error = 'Gagal menyimpan data program studi.';
        }
    }
}

$judul = $isEdit ? 'Edit Program Studi' : 'Tambah Program Studi';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $judul ?> - SIM Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="app-body">

<?php include 'topbar.php'; ?>
<?php include 'sideleftbar.php'; ?>

<main class="main-content">
    <div class="page-heading">
        <span class="eyebrow">MASTER DATA</span>
        <h1><?= $judul ?></h1>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="dashboard-panel form-panel">
        <form method="post">
            <?= csrf_field() ?>

            <div class="form-group">
                <label for="id_fakultas">Fakultas</label>
                <select id="id_fakultas" name="id_fakultas" required>
                    <option value="">-- Pilih fakultas --</option>
                    <?php foreach ($fakList as $f): ?>
                        <option value="<?= (int) $f['id_fakultas'] ?>" <?= (int) $f['id_fakultas'] === (int) $data['id_fakultas'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($f['nama_fakultas']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="kode_program_studi">Kode Program Studi</label>
                <input type="text" id="kode_program_studi" name="kode_program_studi" maxlength="20" required value="<?= htmlspecialchars($data['kode_program_studi']) ?>" placeholder="Contoh: TI">
            </div>

            <div class="form-group">
                <label for="nama_program_studi">Nama Program Studi</label>
                <input type="text" id="nama_program_studi" name="nama_program_studi" maxlength="200" required value="<?= htmlspecialchars($data['nama_program_studi']) ?>" placeholder="Contoh: Teknik Informatika">
            </div>

            <div class="form-group">
                <label for="jenjang">Jenjang</label>
                <select id="jenjang" name="jenjang">
                    <?php foreach ($jenjangList as $j): ?>
                        <option value="<?= $j ?>" <?= $data['jenjang'] === $j ? 'selected' : '' ?>><?= $j ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="status_aktif">Status</label>
                <select id="status_aktif" name="status_aktif">
                    <option value="Aktif" <?= $data['status_aktif'] === 'Aktif' ? 'selected' : '' ?>>Aktif</option>
                    <option value="Tidak Aktif" <?= $data['status_aktif'] === 'Tidak Aktif' ? 'selected' : '' ?>>Tidak Aktif</option>
                </select>
            </div>

            <div class="form-actions">
                <a href="program_studi.php" class="btn btn-outline">Batal</a>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</main>

<script>
function toggleSidebar() { document.getElementById('sidebar').classList.toggle('show'); }
</script>
</body>
</html>
