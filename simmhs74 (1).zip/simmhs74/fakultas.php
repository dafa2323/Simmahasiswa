<?php
require_once 'auth_check.php';
require_once 'koneksi.php';

wajib_role(['ADMIN']);

$result = mysqli_query(
    $koneksi,
    "SELECT f.id_fakultas, f.kode_fakultas, f.nama_fakultas,
            (SELECT COUNT(*) FROM program_studi ps WHERE ps.id_fakultas = f.id_fakultas) AS jml_prodi
     FROM fakultas f
     ORDER BY f.kode_fakultas ASC"
);
if (!$result) {
    die('Gagal mengambil data fakultas: ' . htmlspecialchars(mysqli_error($koneksi)));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fakultas - SIM Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="app-body">

<?php include 'topbar.php'; ?>
<?php include 'sideleftbar.php'; ?>

<main class="main-content">
    <div class="page-heading page-heading-flex">
        <div>
            <span class="eyebrow">MASTER DATA</span>
            <h1>Fakultas</h1>
            <p>Kelola data fakultas.</p>
        </div>
        <a href="fakultas_form.php" class="btn btn-primary">+ Tambah Fakultas</a>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_SESSION['success']) ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']) ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <div class="dashboard-panel">
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th width="60">No.</th>
                        <th width="140">Kode</th>
                        <th>Nama Fakultas</th>
                        <th width="130">Jumlah Prodi</th>
                        <th width="150">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php $no = 1; while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><span class="badge"><?= htmlspecialchars($row['kode_fakultas']) ?></span></td>
                            <td><strong><?= htmlspecialchars($row['nama_fakultas']) ?></strong></td>
                            <td><?= (int) $row['jml_prodi'] ?></td>
                            <td>
                                <div class="action-group">
                                    <a class="btn btn-sm btn-outline" href="fakultas_form.php?id=<?= (int) $row['id_fakultas'] ?>">Edit</a>
                                    <form action="fakultas_hapus.php" method="post" onsubmit="return confirm('Hapus fakultas ini?');">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="id_fakultas" value="<?= (int) $row['id_fakultas'] ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="empty-state">Belum ada data fakultas.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<script>
function toggleSidebar() { document.getElementById('sidebar').classList.toggle('show'); }
</script>
</body>
</html>
