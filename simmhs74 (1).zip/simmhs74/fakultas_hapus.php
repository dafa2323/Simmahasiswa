<?php
require_once 'auth_check.php';
require_once 'koneksi.php';
require_once 'audit.php';

wajib_role(['ADMIN']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: fakultas.php');
    exit;
}
csrf_verify();

$id = filter_input(INPUT_POST, 'id_fakultas', FILTER_VALIDATE_INT);
if (!$id) {
    $_SESSION['error'] = 'ID fakultas tidak valid.';
    header('Location: fakultas.php');
    exit;
}

$stmt = mysqli_prepare($koneksi, "SELECT kode_fakultas, nama_fakultas FROM fakultas WHERE id_fakultas = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$fak = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$fak) {
    $_SESSION['error'] = 'Fakultas tidak ditemukan.';
    header('Location: fakultas.php');
    exit;
}

/* Tidak boleh dihapus bila masih dipakai */
$cek = [
    'program studi' => "SELECT COUNT(*) AS total FROM program_studi WHERE id_fakultas = ?",
    'pengguna'      => "SELECT COUNT(*) AS total FROM pengguna WHERE id_fakultas = ?",
];
foreach ($cek as $label => $sql) {
    $stmt = mysqli_prepare($koneksi, $sql);
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
    if ((int) $row['total'] > 0) {
        $_SESSION['error'] = 'Fakultas tidak dapat dihapus karena masih digunakan oleh ' . $label . '.';
        header('Location: fakultas.php');
        exit;
    }
}

try {
    $stmt = mysqli_prepare($koneksi, "DELETE FROM fakultas WHERE id_fakultas = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    catat_audit($koneksi, 'fakultas', $id, 'DELETE', $fak, null);
    $_SESSION['success'] = 'Fakultas berhasil dihapus.';
} catch (Throwable $e) {
    $_SESSION['error'] = 'Gagal menghapus fakultas.';
}

header('Location: fakultas.php');
exit;
