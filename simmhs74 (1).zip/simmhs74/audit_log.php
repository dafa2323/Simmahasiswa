<?php
require_once 'auth_check.php';
require_once 'koneksi.php';

wajib_role(['ADMIN', 'OPERATOR_PRODI']);

$role   = $_SESSION['kode_role'];
$idSaya = (int) $_SESSION['id_pengguna'];

$aksiList = ['LOGIN', 'LOGOUT', 'INSERT', 'UPDATE', 'DELETE', 'VIEW'];
$aksi = $_GET['aksi'] ?? '';
if (!in_array($aksi, $aksiList, true)) {
    $aksi = '';
}

$sql = "SELECT a.id_audit, a.tabel_nama, a.record_id, a.aksi, a.data_lama, a.data_baru,
               a.ip_address, a.waktu, p.username
        FROM audit_log a
        LEFT JOIN pengguna p ON a.id_pengguna = p.id_pengguna
        WHERE 1=1";
$types = '';
$params = [];

/* Operator Prodi hanya melihat aktivitas akunnya sendiri */
if ($role === 'OPERATOR_PRODI') {
    $sql .= " AND a.id_pengguna = ?";
    $types .= 'i';
    $params[] = $idSaya;
}
if ($aksi !== '') {
    $sql .= " AND a.aksi = ?";
    $types .= 's';
    $params[] = $aksi;
}
$sql .= " ORDER BY a.waktu DESC LIMIT 200";

$stmt = mysqli_prepare($koneksi, $sql);
if ($types !== '') {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);
$rows = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Log - SIM Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="app-body">

<?php include 'topbar.php'; ?>
<?php include 'sideleftbar.php'; ?>

<main class="main-content">
    <div class="page-heading">
        <span class="eyebrow">SISTEM</span>
        <h1>Audit Log</h1>
        <p>
            <?= $role === 'ADMIN' ? '200 aktivitas terbaru seluruh pengguna.' : '200 aktivitas terbaru akun Anda.' ?>
        </p>
    </div>

    <div class="dashboard-panel">
        <form method="get" class="search-form">
            <select name="aksi">
                <option value="">Semua aksi</option>
                <?php foreach ($aksiList as $a): ?>
                    <option value="<?= $a ?>" <?= $aksi === $a ? 'selected' : '' ?>><?= $a ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">Filter</button>
            <?php if ($aksi !== ''): ?>
                <a href="audit_log.php" class="btn btn-outline btn-sm">Reset</a>
            <?php endif; ?>
        </form>

        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th width="160">Waktu</th>
                        <th>Pengguna</th>
                        <th width="100">Aksi</th>
                        <th>Tabel</th>
                        <th>Record</th>
                        <th>IP</th>
                        <th>Detail</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($rows): ?>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td><?= htmlspecialchars($r['waktu']) ?></td>
                            <td><?= htmlspecialchars($r['username'] ?? '-') ?></td>
                            <td><span class="badge"><?= htmlspecialchars($r['aksi']) ?></span></td>
                            <td><?= htmlspecialchars($r['tabel_nama']) ?></td>
                            <td><?= htmlspecialchars($r['record_id'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($r['ip_address'] ?? '-') ?></td>
                            <td>
                                <?php if ($r['data_lama'] !== null || $r['data_baru'] !== null): ?>
                                    <details>
                                        <summary>Lihat</summary>
                                        <?php if ($r['data_lama'] !== null): ?>
                                            <div class="log-detail"><strong>Lama:</strong> <?= htmlspecialchars($r['data_lama']) ?></div>
                                        <?php endif; ?>
                                        <?php if ($r['data_baru'] !== null): ?>
                                            <div class="log-detail"><strong>Baru:</strong> <?= htmlspecialchars($r['data_baru']) ?></div>
                                        <?php endif; ?>
                                    </details>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="7" class="empty-state">Belum ada aktivitas.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<script>
function toggleSidebar() { document.getElementById('sidebar').classList.toggle('show'); }
</script>
</body>
</html>
