<?php
require_once 'auth_check.php';
require_once 'koneksi.php';
require_once 'audit.php';

wajib_role(['ADMIN', 'OPERATOR_PRODI']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: mahasiswa.php');
    exit;
}

csrf_verify();

$id = filter_input(INPUT_POST, 'id_mahasiswa', FILTER_VALIDATE_INT);

if (!$id) {
    $_SESSION['error'] = 'ID mahasiswa tidak valid.';
    header('Location: mahasiswa.php');
    exit;
}

$role = $_SESSION['kode_role'];
$idProdi = (int) ($_SESSION['id_program_studi'] ?? 0);

/* Operator Prodi hanya boleh menghapus mahasiswa prodinya sendiri */
$stmt = mysqli_prepare($koneksi, "SELECT id_program_studi, npm, nama_mahasiswa FROM mahasiswa WHERE id_mahasiswa = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$mhs = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$mhs) {
    $_SESSION['error'] = 'Data mahasiswa tidak ditemukan.';
    header('Location: mahasiswa.php');
    exit;
}

if ($role === 'OPERATOR_PRODI' && (int) $mhs['id_program_studi'] !== $idProdi) {
    http_response_code(403);
    die('403 - Anda tidak memiliki hak akses ke data mahasiswa ini.');
}

try {
    $stmt = mysqli_prepare($koneksi, "DELETE FROM mahasiswa WHERE id_mahasiswa = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    catat_audit($koneksi, 'mahasiswa', $id, 'DELETE', $mhs, null);
    $_SESSION['success'] = 'Data mahasiswa berhasil dihapus.';
} catch (mysqli_sql_exception $e) {
    $_SESSION['error'] = 'Gagal menghapus data mahasiswa.';
}

header('Location: mahasiswa.php');
exit;
