<?php
require_once 'auth_check.php';
require_once 'koneksi.php';
require_once 'audit.php';

wajib_role(['ADMIN', 'OPERATOR_PRODI']);

$role    = $_SESSION['kode_role'];
$idProdiSession = (int) ($_SESSION['id_program_studi'] ?? 0);

$idMhs  = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$isEdit = $idMhs > 0;

$statusList = ['Aktif', 'Cuti', 'Lulus', 'Mengundurkan Diri', 'Drop Out', 'Tidak Aktif'];

function tanggal_valid(string $v): bool
{
    $d = DateTime::createFromFormat('Y-m-d', $v);
    return $d && $d->format('Y-m-d') === $v;
}

/* Daftar prodi untuk dropdown (Operator hanya prodinya sendiri) */
if ($role === 'OPERATOR_PRODI') {
    $stmt = mysqli_prepare($koneksi, "SELECT id_program_studi, nama_program_studi FROM program_studi WHERE id_program_studi = ? AND status_aktif = 'Aktif'");
    mysqli_stmt_bind_param($stmt, 'i', $idProdiSession);
} else {
    $stmt = mysqli_prepare($koneksi, "SELECT id_program_studi, nama_program_studi FROM program_studi WHERE status_aktif = 'Aktif' ORDER BY nama_program_studi");
}
mysqli_stmt_execute($stmt);
$prodiList = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
mysqli_stmt_close($stmt);

$data = [
    'id_program_studi' => $role === 'OPERATOR_PRODI' ? $idProdiSession : '',
    'npm' => '', 'nama_mahasiswa' => '', 'jenis_kelamin' => 'L',
    'tempat_lahir' => '', 'tanggal_lahir' => '', 'tanggal_masuk' => date('Y-m-d'),
    'alamat' => '', 'status_mahasiswa' => 'Aktif',
];

/* Mode edit: ambil data lama + cek kewenangan */
if ($isEdit) {
    $stmt = mysqli_prepare($koneksi, "SELECT * FROM mahasiswa WHERE id_mahasiswa = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'i', $idMhs);
    mysqli_stmt_execute($stmt);
    $lama = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if (!$lama) {
        $_SESSION['error'] = 'Data mahasiswa tidak ditemukan.';
        header('Location: mahasiswa.php');
        exit;
    }
    if ($role === 'OPERATOR_PRODI' && (int) $lama['id_program_studi'] !== $idProdiSession) {
        http_response_code(403);
        die('403 - Anda tidak memiliki hak akses ke data mahasiswa ini.');
    }
    foreach ($data as $k => $_) {
        $data[$k] = $lama[$k] ?? '';
    }
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $data['npm']              = trim($_POST['npm'] ?? '');
    $data['nama_mahasiswa']   = trim($_POST['nama_mahasiswa'] ?? '');
    $data['jenis_kelamin']    = $_POST['jenis_kelamin'] ?? '';
    $data['tempat_lahir']     = trim($_POST['tempat_lahir'] ?? '');
    $data['tanggal_lahir']    = trim($_POST['tanggal_lahir'] ?? '');
    $data['tanggal_masuk']    = trim($_POST['tanggal_masuk'] ?? '');
    $data['alamat']           = trim($_POST['alamat'] ?? '');
    $data['status_mahasiswa'] = $_POST['status_mahasiswa'] ?? '';
    $data['id_program_studi'] = $role === 'OPERATOR_PRODI'
        ? $idProdiSession
        : (int) ($_POST['id_program_studi'] ?? 0);

    $prodiValid = false;
    foreach ($prodiList as $p) {
        if ((int) $p['id_program_studi'] === (int) $data['id_program_studi']) {
            $prodiValid = true;
        }
    }

    if ($data['npm'] === '' || $data['nama_mahasiswa'] === '') {
        $error = 'NPM dan nama mahasiswa wajib diisi.';
    } elseif (!preg_match('/^[0-9A-Za-z]+$/', $data['npm'])) {
        $error = 'NPM hanya boleh berisi huruf dan angka.';
    } elseif (!$prodiValid) {
        $error = 'Program studi tidak valid.';
    } elseif (!in_array($data['jenis_kelamin'], ['L', 'P'], true)) {
        $error = 'Jenis kelamin tidak valid.';
    } elseif (!in_array($data['status_mahasiswa'], $statusList, true)) {
        $error = 'Status mahasiswa tidak valid.';
    } elseif (!tanggal_valid($data['tanggal_masuk'])) {
        $error = 'Tanggal masuk tidak valid.';
    } elseif ($data['tanggal_lahir'] !== '' && !tanggal_valid($data['tanggal_lahir'])) {
        $error = 'Tanggal lahir tidak valid.';
    } else {
        /* Cek NPM unik */
        $stmt = mysqli_prepare($koneksi, "SELECT id_mahasiswa FROM mahasiswa WHERE npm = ? AND id_mahasiswa <> ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, 'si', $data['npm'], $idMhs);
        mysqli_stmt_execute($stmt);
        $ada = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        mysqli_stmt_close($stmt);
        if ($ada) {
            $error = 'NPM sudah digunakan.';
        }
    }

    if ($error === '') {
        $prodi = (int) $data['id_program_studi'];

        if ($isEdit) {
            $stmt = mysqli_prepare(
                $koneksi,
                "UPDATE mahasiswa
                 SET id_program_studi = ?, npm = ?, nama_mahasiswa = ?, jenis_kelamin = ?,
                     tempat_lahir = NULLIF(?, ''), tanggal_lahir = NULLIF(?, ''),
                     tanggal_masuk = ?, alamat = NULLIF(?, ''), status_mahasiswa = ?
                 WHERE id_mahasiswa = ?"
            );
            mysqli_stmt_bind_param(
                $stmt, 'issssssssi',
                $prodi, $data['npm'], $data['nama_mahasiswa'], $data['jenis_kelamin'],
                $data['tempat_lahir'], $data['tanggal_lahir'], $data['tanggal_masuk'],
                $data['alamat'], $data['status_mahasiswa'], $idMhs
            );
            $pesan = 'Data mahasiswa berhasil diperbarui.';
        } else {
            $stmt = mysqli_prepare(
                $koneksi,
                "INSERT INTO mahasiswa
                    (id_program_studi, npm, nama_mahasiswa, jenis_kelamin, tempat_lahir,
                     tanggal_lahir, tanggal_masuk, alamat, status_mahasiswa)
                 VALUES (?, ?, ?, ?, NULLIF(?, ''), NULLIF(?, ''), ?, NULLIF(?, ''), ?)"
            );
            mysqli_stmt_bind_param(
                $stmt, 'issssssss',
                $prodi, $data['npm'], $data['nama_mahasiswa'], $data['jenis_kelamin'],
                $data['tempat_lahir'], $data['tanggal_lahir'], $data['tanggal_masuk'],
                $data['alamat'], $data['status_mahasiswa']
            );
            $pesan = 'Mahasiswa berhasil ditambahkan.';
        }

        if (mysqli_stmt_execute($stmt)) {
            $rid = $isEdit ? $idMhs : mysqli_insert_id($koneksi);
            mysqli_stmt_close($stmt);
            catat_audit($koneksi, 'mahasiswa', $rid, $isEdit ? 'UPDATE' : 'INSERT', $isEdit ? $lama : null, $data);
            $_SESSION['success'] = $pesan;
            header('Location: mahasiswa.php');
            exit;
        }
        $error = 'Gagal menyimpan data: ' . mysqli_stmt_error($stmt);
        mysqli_stmt_close($stmt);
    }
}

$judul = $isEdit ? 'Edit Mahasiswa' : 'Tambah Mahasiswa';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $judul ?> - SIM Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="app-body">

<?php include 'topbar.php'; ?>
<?php include 'sideleftbar.php'; ?>

<main class="main-content">
    <div class="page-heading">
        <span class="eyebrow">DATA AKADEMIK</span>
        <h1><?= $judul ?></h1>
        <p>Lengkapi data mahasiswa di bawah ini.</p>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="dashboard-panel form-panel">
        <form method="post">
            <?= csrf_field() ?>

            <div class="form-group">
                <label for="id_program_studi">Program Studi</label>
                <select id="id_program_studi" name="id_program_studi" required <?= $role === 'OPERATOR_PRODI' ? 'disabled' : '' ?>>
                    <?php foreach ($prodiList as $p): ?>
                        <option value="<?= (int) $p['id_program_studi'] ?>"
                            <?= (int) $p['id_program_studi'] === (int) $data['id_program_studi'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($p['nama_program_studi']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="npm">NPM</label>
                <input type="text" id="npm" name="npm" maxlength="30" required value="<?= htmlspecialchars($data['npm']) ?>">
            </div>

            <div class="form-group">
                <label for="nama_mahasiswa">Nama Mahasiswa</label>
                <input type="text" id="nama_mahasiswa" name="nama_mahasiswa" maxlength="200" required value="<?= htmlspecialchars($data['nama_mahasiswa']) ?>">
            </div>

            <div class="form-group">
                <label for="jenis_kelamin">Jenis Kelamin</label>
                <select id="jenis_kelamin" name="jenis_kelamin">
                    <option value="L" <?= $data['jenis_kelamin'] === 'L' ? 'selected' : '' ?>>Laki-laki</option>
                    <option value="P" <?= $data['jenis_kelamin'] === 'P' ? 'selected' : '' ?>>Perempuan</option>
                </select>
            </div>

            <div class="form-group">
                <label for="tempat_lahir">Tempat Lahir</label>
                <input type="text" id="tempat_lahir" name="tempat_lahir" maxlength="100" value="<?= htmlspecialchars($data['tempat_lahir']) ?>">
            </div>

            <div class="form-group">
                <label for="tanggal_lahir">Tanggal Lahir</label>
                <input type="date" id="tanggal_lahir" name="tanggal_lahir" value="<?= htmlspecialchars($data['tanggal_lahir']) ?>">
            </div>

            <div class="form-group">
                <label for="tanggal_masuk">Tanggal Masuk</label>
                <input type="date" id="tanggal_masuk" name="tanggal_masuk" required value="<?= htmlspecialchars($data['tanggal_masuk']) ?>">
            </div>

            <div class="form-group">
                <label for="alamat">Alamat</label>
                <textarea id="alamat" name="alamat" rows="3"><?= htmlspecialchars($data['alamat']) ?></textarea>
            </div>

            <div class="form-group">
                <label for="status_mahasiswa">Status</label>
                <select id="status_mahasiswa" name="status_mahasiswa">
                    <?php foreach ($statusList as $s): ?>
                        <option value="<?= htmlspecialchars($s) ?>" <?= $data['status_mahasiswa'] === $s ? 'selected' : '' ?>><?= htmlspecialchars($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-actions">
                <a href="mahasiswa.php" class="btn btn-outline">Batal</a>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</main>

<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('show');
}
</script>
</body>
</html>
