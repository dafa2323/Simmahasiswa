<?php
require_once 'auth_check.php';
require_once 'koneksi.php';
require_once 'audit.php';

wajib_role(['ADMIN']);

$id     = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$isEdit = $id > 0;
$isSelf = $isEdit && $id === (int) $_SESSION['id_pengguna'];

$roles = mysqli_fetch_all(
    mysqli_query($koneksi, "SELECT id_role, kode_role, nama_role FROM roles ORDER BY id_role"),
    MYSQLI_ASSOC
);
$fakList = mysqli_fetch_all(
    mysqli_query($koneksi, "SELECT id_fakultas, nama_fakultas FROM fakultas ORDER BY nama_fakultas"),
    MYSQLI_ASSOC
);
$prodiList = mysqli_fetch_all(
    mysqli_query($koneksi, "SELECT id_program_studi, id_fakultas, nama_program_studi FROM program_studi ORDER BY nama_program_studi"),
    MYSQLI_ASSOC
);

$data = [
    'id_role' => '', 'id_fakultas' => '', 'id_program_studi' => '',
    'username' => '', 'nama_lengkap' => '', 'email' => '', 'no_hp' => '',
    'status_aktif' => 'Aktif',
];

if ($isEdit) {
    $stmt = mysqli_prepare($koneksi, "SELECT id_role, id_fakultas, id_program_studi, username, nama_lengkap, email, no_hp, status_aktif FROM pengguna WHERE id_pengguna = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $lama = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if (!$lama) {
        $_SESSION['error'] = 'Pengguna tidak ditemukan.';
        header('Location: pengguna.php');
        exit;
    }
    $data = array_map(fn($v) => $v ?? '', $lama);
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $password = $_POST['password'] ?? '';

    $data['username']     = trim($_POST['username'] ?? '');
    $data['nama_lengkap'] = trim($_POST['nama_lengkap'] ?? '');
    $data['email']        = trim($_POST['email'] ?? '');
    $data['no_hp']        = trim($_POST['no_hp'] ?? '');
    $data['id_fakultas']       = (int) ($_POST['id_fakultas'] ?? 0);
    $data['id_program_studi']  = (int) ($_POST['id_program_studi'] ?? 0);

    /* Admin tidak boleh mengubah role/status akunnya sendiri (cegah terkunci) */
    if ($isSelf) {
        $data['id_role']      = $lama['id_role'];
        $data['status_aktif'] = 'Aktif';
    } else {
        $data['id_role']      = (int) ($_POST['id_role'] ?? 0);
        $data['status_aktif'] = $_POST['status_aktif'] ?? '';
    }

    $kodeRole = '';
    foreach ($roles as $r) {
        if ((int) $r['id_role'] === (int) $data['id_role']) {
            $kodeRole = $r['kode_role'];
        }
    }

    $prodiDipilih = null;
    foreach ($prodiList as $p) {
        if ((int) $p['id_program_studi'] === $data['id_program_studi']) {
            $prodiDipilih = $p;
        }
    }
    $fakValid = false;
    foreach ($fakList as $f) {
        if ((int) $f['id_fakultas'] === $data['id_fakultas']) {
            $fakValid = true;
        }
    }

    if ($data['username'] === '' || $data['nama_lengkap'] === '') {
        $error = 'Username dan nama lengkap wajib diisi.';
    } elseif (!preg_match('/^[A-Za-z0-9._-]{3,100}$/', $data['username'])) {
        $error = 'Username 3-100 karakter, hanya huruf, angka, titik, underscore, dan strip.';
    } elseif ($kodeRole === '') {
        $error = 'Role tidak valid.';
    } elseif (!in_array($data['status_aktif'], ['Aktif', 'Tidak Aktif'], true)) {
        $error = 'Status tidak valid.';
    } elseif ($data['email'] !== '' && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid.';
    } elseif (!$isEdit && strlen($password) < 8) {
        $error = 'Password wajib diisi minimal 8 karakter.';
    } elseif ($isEdit && $password !== '' && strlen($password) < 8) {
        $error = 'Password baru minimal 8 karakter.';
    } elseif ($kodeRole === 'DEKANAT' && !$fakValid) {
        $error = 'Role Dekanat wajib memilih fakultas.';
    } elseif ($kodeRole === 'OPERATOR_PRODI' && !$prodiDipilih) {
        $error = 'Role Operator Program Studi wajib memilih program studi.';
    } else {
        $stmt = mysqli_prepare($koneksi, "SELECT id_pengguna FROM pengguna WHERE username = ? AND id_pengguna <> ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, 'si', $data['username'], $id);
        mysqli_stmt_execute($stmt);
        $ada = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        mysqli_stmt_close($stmt);
        if ($ada) {
            $error = 'Username sudah digunakan.';
        }
    }

    if ($error === '') {
        /* Tentukan lingkup sesuai role */
        $fak = null;
        $prodi = null;
        if (in_array($kodeRole, ['ADMIN', 'REKTORAT'], true)) {
            /* tanpa lingkup */
        } elseif ($kodeRole === 'DEKANAT') {
            $fak = $data['id_fakultas'];
        } else {
            if ($prodiDipilih) {
                $prodi = (int) $prodiDipilih['id_program_studi'];
                $fak   = (int) $prodiDipilih['id_fakultas'];
            } elseif ($fakValid) {
                $fak = $data['id_fakultas'];
            }
        }

        $email = $data['email'] === '' ? null : $data['email'];
        $hp    = $data['no_hp'] === '' ? null : $data['no_hp'];
        $idRole = (int) $data['id_role'];
        $log = [
            'id_role' => $idRole, 'id_fakultas' => $fak, 'id_program_studi' => $prodi,
            'username' => $data['username'], 'nama_lengkap' => $data['nama_lengkap'],
            'email' => $email, 'no_hp' => $hp, 'status_aktif' => $data['status_aktif'],
        ];

        try {
            if ($isEdit) {
                if ($password !== '') {
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = mysqli_prepare($koneksi, "UPDATE pengguna SET id_role = ?, id_fakultas = ?, id_program_studi = ?, username = ?, password_hash = ?, nama_lengkap = ?, email = ?, no_hp = ?, status_aktif = ? WHERE id_pengguna = ?");
                    mysqli_stmt_bind_param($stmt, 'iiissssssi', $idRole, $fak, $prodi, $data['username'], $hash, $data['nama_lengkap'], $email, $hp, $data['status_aktif'], $id);
                    $log['password'] = 'diubah';
                } else {
                    $stmt = mysqli_prepare($koneksi, "UPDATE pengguna SET id_role = ?, id_fakultas = ?, id_program_studi = ?, username = ?, nama_lengkap = ?, email = ?, no_hp = ?, status_aktif = ? WHERE id_pengguna = ?");
                    mysqli_stmt_bind_param($stmt, 'iiisssssi', $idRole, $fak, $prodi, $data['username'], $data['nama_lengkap'], $email, $hp, $data['status_aktif'], $id);
                }
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
                catat_audit($koneksi, 'pengguna', $id, 'UPDATE', $lama, $log);
                $_SESSION['success'] = 'Pengguna berhasil diperbarui.';
            } else {
                $res = mysqli_query($koneksi, "SELECT id_universitas FROM universitas ORDER BY id_universitas ASC LIMIT 1");
                $uni = $res ? mysqli_fetch_assoc($res) : null;
                $idUni = $uni ? (int) $uni['id_universitas'] : null;
                $hash = password_hash($password, PASSWORD_DEFAULT);

                $stmt = mysqli_prepare($koneksi, "INSERT INTO pengguna (id_role, id_universitas, id_fakultas, id_program_studi, username, password_hash, nama_lengkap, email, no_hp, status_aktif) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt, 'iiiissssss', $idRole, $idUni, $fak, $prodi, $data['username'], $hash, $data['nama_lengkap'], $email, $hp, $data['status_aktif']);
                mysqli_stmt_execute($stmt);
                $newId = mysqli_insert_id($koneksi);
                mysqli_stmt_close($stmt);
                catat_audit($koneksi, 'pengguna', $newId, 'INSERT', null, $log);
                $_SESSION['success'] = 'Pengguna berhasil ditambahkan.';
            }
            header('Location: pengguna.php');
            exit;
        } catch (Throwable $e) {
            $error = 'Gagal menyimpan data pengguna.';
        }
    }
}

$judul = $isEdit ? 'Edit Pengguna' : 'Tambah Pengguna';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $judul ?> - SIM Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="app-body">

<?php include 'topbar.php'; ?>
<?php include 'sideleftbar.php'; ?>

<main class="main-content">
    <div class="page-heading">
        <span class="eyebrow">MASTER DATA</span>
        <h1><?= $judul ?></h1>
        <p>Role Admin dan Rektorat tidak memerlukan lingkup. Dekanat wajib memilih fakultas. Operator Prodi wajib memilih program studi.</p>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="dashboard-panel form-panel">
        <form method="post" autocomplete="off">
            <?= csrf_field() ?>

            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" maxlength="100" required value="<?= htmlspecialchars($data['username']) ?>">
            </div>

            <div class="form-group">
                <label for="password"><?= $isEdit ? 'Password Baru' : 'Password' ?></label>
                <input type="password" id="password" name="password" minlength="8" autocomplete="new-password" <?= $isEdit ? '' : 'required' ?>>
                <small class="form-help"><?= $isEdit ? 'Kosongkan jika tidak ingin mengubah password.' : 'Minimal 8 karakter.' ?></small>
            </div>

            <div class="form-group">
                <label for="nama_lengkap">Nama Lengkap</label>
                <input type="text" id="nama_lengkap" name="nama_lengkap" maxlength="200" required value="<?= htmlspecialchars($data['nama_lengkap']) ?>">
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" maxlength="150" value="<?= htmlspecialchars($data['email']) ?>">
            </div>

            <div class="form-group">
                <label for="no_hp">No. HP</label>
                <input type="text" id="no_hp" name="no_hp" maxlength="30" value="<?= htmlspecialchars($data['no_hp']) ?>">
            </div>

            <div class="form-group">
                <label for="id_role">Role</label>
                <select id="id_role" name="id_role" required <?= $isSelf ? 'disabled' : '' ?>>
                    <option value="">-- Pilih role --</option>
                    <?php foreach ($roles as $r): ?>
                        <option value="<?= (int) $r['id_role'] ?>" <?= (int) $r['id_role'] === (int) $data['id_role'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($r['nama_role']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if ($isSelf): ?><small class="form-help">Role akun Anda sendiri tidak dapat diubah.</small><?php endif; ?>
            </div>

            <div class="form-group">
                <label for="id_fakultas">Fakultas (untuk Dekanat)</label>
                <select id="id_fakultas" name="id_fakultas">
                    <option value="0">-- Tidak ada --</option>
                    <?php foreach ($fakList as $f): ?>
                        <option value="<?= (int) $f['id_fakultas'] ?>" <?= (int) $f['id_fakultas'] === (int) $data['id_fakultas'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($f['nama_fakultas']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="id_program_studi">Program Studi (untuk Operator Prodi)</label>
                <select id="id_program_studi" name="id_program_studi">
                    <option value="0">-- Tidak ada --</option>
                    <?php foreach ($prodiList as $p): ?>
                        <option value="<?= (int) $p['id_program_studi'] ?>" <?= (int) $p['id_program_studi'] === (int) $data['id_program_studi'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($p['nama_program_studi']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="status_aktif">Status</label>
                <select id="status_aktif" name="status_aktif" <?= $isSelf ? 'disabled' : '' ?>>
                    <option value="Aktif" <?= $data['status_aktif'] === 'Aktif' ? 'selected' : '' ?>>Aktif</option>
                    <option value="Tidak Aktif" <?= $data['status_aktif'] === 'Tidak Aktif' ? 'selected' : '' ?>>Tidak Aktif</option>
                </select>
            </div>

            <div class="form-actions">
                <a href="pengguna.php" class="btn btn-outline">Batal</a>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</main>

<script>
function toggleSidebar() { document.getElementById('sidebar').classList.toggle('show'); }
</script>
</body>
</html>
