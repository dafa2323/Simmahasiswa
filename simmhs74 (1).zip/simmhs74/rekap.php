<?php
require_once 'auth_check.php';
require_once 'koneksi.php';

wajib_role(['ADMIN', 'DEKANAT', 'REKTORAT']);

$role = $_SESSION['kode_role'];
$idFakultas = (int) ($_SESSION['id_fakultas'] ?? 0);

$sql = "SELECT f.nama_fakultas, ps.nama_program_studi, ps.jenjang,
               COUNT(m.id_mahasiswa) AS total,
               SUM(m.status_mahasiswa = 'Aktif') AS aktif,
               SUM(m.status_mahasiswa = 'Cuti') AS cuti,
               SUM(m.status_mahasiswa = 'Lulus') AS lulus,
               SUM(m.status_mahasiswa IN ('Mengundurkan Diri', 'Drop Out', 'Tidak Aktif')) AS lainnya,
               SUM(m.jenis_kelamin = 'L') AS laki,
               SUM(m.jenis_kelamin = 'P') AS perempuan
        FROM program_studi ps
        INNER JOIN fakultas f ON ps.id_fakultas = f.id_fakultas
        LEFT JOIN mahasiswa m ON m.id_program_studi = ps.id_program_studi";

/* Dekanat hanya melihat fakultasnya sendiri */
if ($role === 'DEKANAT') {
    $sql .= " WHERE ps.id_fakultas = ?";
}
$sql .= " GROUP BY ps.id_program_studi, f.nama_fakultas, ps.nama_program_studi, ps.jenjang
          ORDER BY f.nama_fakultas ASC, ps.nama_program_studi ASC";

$stmt = mysqli_prepare($koneksi, $sql);
if ($role === 'DEKANAT') {
    mysqli_stmt_bind_param($stmt, 'i', $idFakultas);
}
mysqli_stmt_execute($stmt);
$rows = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
mysqli_stmt_close($stmt);

$kolom = ['total', 'aktif', 'cuti', 'lulus', 'lainnya', 'laki', 'perempuan'];
$jumlah = array_fill_keys($kolom, 0);
foreach ($rows as $r) {
    foreach ($kolom as $k) {
        $jumlah[$k] += (int) $r[$k];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Mahasiswa - SIM Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="app-body">

<?php include 'topbar.php'; ?>
<?php include 'sideleftbar.php'; ?>

<main class="main-content">
    <div class="page-heading">
        <span class="eyebrow">LAPORAN</span>
        <h1>Rekap Mahasiswa</h1>
        <p><?= $role === 'DEKANAT' ? 'Rekap mahasiswa pada fakultas Anda.' : 'Rekap mahasiswa seluruh program studi.' ?></p>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon">👨‍🎓</div>
            <div><span>Total Mahasiswa</span><strong><?= number_format($jumlah['total'], 0, ',', '.') ?></strong></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">✅</div>
            <div><span>Mahasiswa Aktif</span><strong><?= number_format($jumlah['aktif'], 0, ',', '.') ?></strong></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">🎓</div>
            <div><span>Lulus</span><strong><?= number_format($jumlah['lulus'], 0, ',', '.') ?></strong></div>
        </div>
    </div>

    <div class="dashboard-panel">
        <div class="panel-heading"><h2>Rekap per Program Studi</h2></div>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Fakultas</th>
                        <th>Program Studi</th>
                        <th>Jenjang</th>
                        <th>Total</th>
                        <th>Aktif</th>
                        <th>Cuti</th>
                        <th>Lulus</th>
                        <th>Lainnya</th>
                        <th>L</th>
                        <th>P</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($rows): ?>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td><?= htmlspecialchars($r['nama_fakultas']) ?></td>
                            <td><strong><?= htmlspecialchars($r['nama_program_studi']) ?></strong></td>
                            <td><?= htmlspecialchars($r['jenjang']) ?></td>
                            <td><strong><?= (int) $r['total'] ?></strong></td>
                            <td><?= (int) $r['aktif'] ?></td>
                            <td><?= (int) $r['cuti'] ?></td>
                            <td><?= (int) $r['lulus'] ?></td>
                            <td><?= (int) $r['lainnya'] ?></td>
                            <td><?= (int) $r['laki'] ?></td>
                            <td><?= (int) $r['perempuan'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr class="total-row">
                        <td colspan="3"><strong>Jumlah</strong></td>
                        <?php foreach ($kolom as $k): ?>
                            <td><strong><?= $jumlah[$k] ?></strong></td>
                        <?php endforeach; ?>
                    </tr>
                <?php else: ?>
                    <tr><td colspan="10" class="empty-state">Belum ada data.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<script>
function toggleSidebar() { document.getElementById('sidebar').classList.toggle('show'); }
</script>
</body>
</html>
